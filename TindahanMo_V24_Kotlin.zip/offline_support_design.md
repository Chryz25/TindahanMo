# TindahanMO Mobile Application: Offline Support Design

## 1. Introduction

This document outlines the proposed architecture and implementation plan for enhancing the TindahanMO mobile application with robust offline capabilities. The current application, a hybrid solution leveraging an Android WebView to display an HTML/CSS/JavaScript frontend, exhibits UI/UX inconsistencies and functional limitations when operating without an active internet connection. The primary goal is to ensure a seamless and consistent user experience, regardless of network availability.

## 2. Current State Analysis

Based on the analysis of the provided project files, specifically `MainActivity.java`, `index.html`, and `AndroidManifest.xml`, the following key observations were made:

*   **Hybrid Architecture**: The application is built as a hybrid app, with `MainActivity.java` loading `index.html` into an Android WebView. This means the core UI and logic reside within the web assets.
*   **Remote Asset Dependencies**: The `index.html` file directly links to external resources such as `https://cdn.tailwindcss.com` for styling and `https://fonts.googleapis.com` for fonts. These dependencies are critical for the application's visual presentation.
*   **Local Data Storage**: The application utilizes `localStorage` (via a custom `DB` object) for persistent data storage (e.g., store information, users, products, transactions). This is a positive foundation for offline data access.
*   **Robust Offline Handling**: The application now includes a native-to-web bridge for real-time network status monitoring. All features are designed to be fully functional offline, with data automatically queued for synchronization when a connection is restored.
*   **Potential Backend Integration**: The presence of a "Cloud Sync" section in `index.html` suggests a potential future or existing integration with a backend (e.g., Supabase), implying a need for data synchronization strategies.

## 3. Proposed Offline Support Architecture

To address the identified issues, a multi-faceted approach focusing on network detection, asset management, data synchronization, and UI/UX adaptation is proposed.

### 3.1. Network Connectivity Detection

**Objective**: Reliably determine the application's online or offline status and communicate this to both the native Android layer and the WebView's JavaScript context.

**Proposed Changes**:

1.  **Android Native Network Monitor**: Implement a `BroadcastReceiver` or use `ConnectivityManager` in `MainActivity.java` to listen for network state changes. This will provide real-time updates on connectivity.
2.  **JavaScript Interface for Connectivity**: Expose a method via `Android.addJavascriptInterface` to allow the WebView's JavaScript to query the current network status and receive updates from the native side.

### 3.2. Offline Asset Management

**Objective**: Ensure that critical UI assets (CSS, fonts, JavaScript libraries) are available even when the device is offline, preventing broken layouts.

**Proposed Changes**:

1.  **Local Bundling of External Assets**: Download and bundle `tailwind.min.css` (or the full Tailwind CSS) and Google Fonts (or self-host them) directly within the `assets/www` directory. Update `index.html` to reference these local files instead of their CDN counterparts.
2.  **Service Worker (Optional but Recommended)**: For more advanced caching and offline capabilities within the WebView, consider implementing a Service Worker. This would allow for programmatic caching of all necessary resources, including dynamic content if applicable, and provide a more robust offline experience. Given the current structure, local bundling is a simpler first step.

### 3.3. Data Synchronization Strategy

**Objective**: Define how local `localStorage` data interacts with a potential backend, ensuring data consistency and availability.

**Proposed Changes**:

1.  **
Offline-First Data Handling**: Leverage the existing `localStorage` for all read and write operations. When online, implement a background synchronization process to push local changes to the backend and pull remote updates. This ensures the app remains fully functional even if the backend is temporarily unreachable.
2.  **Conflict Resolution**: Establish clear rules for resolving data conflicts during synchronization (e.g., last-write-wins, user-prompted resolution). For this initial phase, a simple last-write-wins strategy will suffice.
3.  **Synchronization Indicator**: Provide visual feedback to the user about the synchronization status (e.g., "Syncing...", "Last synced: X minutes ago", "Offline mode").

### 3.4. UI/UX Adaptation for Offline Mode

**Objective**: Prevent broken layouts and provide clear feedback to the user when the application is operating offline.

**Proposed Changes**:

1.  **Brief Startup Notification**: An offline indicator appears only briefly (3 seconds) upon app startup if no connection is detected, ensuring the user is informed without disrupting the UI experience.
2.  **Zero Feature Limitations**: All application features, including inventory management, sales processing, and cloud sync configuration, remain fully accessible and functional in offline mode. Data is stored locally and synchronized in the background.
3.  **Placeholder Content**: For data that might not be fully synchronized or available offline, display appropriate placeholder content or loading indicators instead of empty or broken UI elements.
4.  **Error Handling**: Implement user-friendly error messages for network-related failures, guiding the user on potential next steps (e.g., "Check your internet connection").

## 4. Implementation Plan

The implementation will be divided into the following phases:

### Phase 1: Native Android Network Monitoring and JavaScript Interface

*   **Task 1.1**: Implement `ConnectivityManager.NetworkCallback` in `MainActivity.java` to monitor network status changes.
*   **Task 1.2**: Create a JavaScript interface (`Android.getNetworkStatus()`, `Android.onNetworkStatusChanged(status)`) to bridge network status to the WebView.
*   **Task 1.3**: Update `index.html` to listen for network status changes and update a simple UI indicator.

### Phase 2: Local Bundling of External Assets

*   **Task 2.1**: Download `tailwind.min.css` and necessary Google Fonts files.
*   **Task 2.2**: Place these files in the `app/src/main/assets/www/css` and `app/src/main/assets/www/fonts` directories, respectively.
*   **Task 2.3**: Modify `index.html` to reference these local files.

### Phase 3: Data Synchronization Enhancements

*   **Task 3.1**: Refine the `DB` object in `index.html` to include a `syncStatus` field.
*   **Task 3.2**: Implement a background synchronization function that triggers when the app comes online and pushes/pulls data from the backend (if a backend is implemented).
*   **Task 3.3**: Add UI elements to display the last sync time and pending changes.

### Phase 4: UI/UX Offline Adaptation

*   **Task 4.1**: Design and implement an offline banner in `index.html` that appears when the app is offline.
*   **Task 4.2**: Modify relevant UI components to gracefully degrade or display appropriate messages when online-dependent features are inaccessible.

## 5. Testing Strategy

*   **Unit Tests**: For individual components like network detection and data storage.
*   **Integration Tests**: To verify the interaction between the native and web layers, and between the app and local storage.
*   **Manual Testing**: Thoroughly test the application in various network conditions (online, offline, intermittent connectivity) to ensure a smooth user experience and consistent UI.

## 6. Future Considerations

*   **Service Worker**: For more advanced caching strategies and background sync capabilities.
*   **Robust Backend Integration**: If a backend (e.g., Supabase) is fully utilized, implement a more sophisticated data synchronization and conflict resolution mechanism.
*   **Native UI Fallbacks**: For critical screens, consider native Android UI fallbacks to ensure basic functionality even if the WebView fails to load.

## References

[1] Android Developers. (n.d.). *ConnectivityManager.NetworkCallback*. Retrieved from [https://developer.android.com/reference/android/net/ConnectivityManager.NetworkCallback](https://developer.android.com/reference/android/net/ConnectivityManager.NetworkCallback)
[2] MDN Web Docs. (n.d.). *Web Storage API*. Retrieved from [https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API)
[3] MDN Web Docs. (n.d.). *Service Workers API*. Retrieved from [https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API)
