import os
import sys
from PIL import Image

def resize_icon(source_path, output_path, size):
    with Image.open(source_path) as img:
        # Convert to RGBA if not already
        img = img.convert("RGBA")
        # Resize with high-quality resampling
        resized_img = img.resize((size, size), Image.Resampling.LANCZOS)
        # Ensure directory exists
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        # Save
        resized_img.save(output_path, "PNG")
        print(f"Generated: {output_path} ({size}x{size})")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 update_icon.py <path_to_png>")
        sys.exit(1)

    source_png = sys.argv[1]
    if not os.path.exists(source_png):
        print(f"Error: File {source_png} not found.")
        sys.exit(1)

    res_dir = "/home/seth/Downloads/TindahanMO_V16_Upgraded/app/src/main/res"
    
    # Standard icon sizes for different densities
    # mdpi: 48x48
    # hdpi: 72x72
    # xhdpi: 96x96
    # xxhdpi: 144x144
    # xxxhdpi: 192x192
    
    densities = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192
    }

    for folder, size in densities.items():
        # Regular icon
        resize_icon(source_png, os.path.join(res_dir, folder, "ic_launcher.png"), size)
        # Round icon
        resize_icon(source_png, os.path.join(res_dir, folder, "ic_launcher_round.png"), size)

    # Also create adaptive icon support for Android 8.0+ (API 26)
    anydpi_dir = os.path.join(res_dir, "mipmap-anydpi-v26")
    os.makedirs(anydpi_dir, exist_ok=True)
    
    # Create ic_launcher.xml for adaptive icons
    with open(os.path.join(anydpi_dir, "ic_launcher.xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n')
        f.write('<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n')
        f.write('    <background android:drawable="@color/ic_launcher_background"/>\n')
        f.write('    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n')
        f.write('</adaptive-icon>')

    # Create ic_launcher_round.xml for adaptive icons
    with open(os.path.join(anydpi_dir, "ic_launcher_round.xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n')
        f.write('<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n')
        f.write('    <background android:drawable="@color/ic_launcher_background"/>\n')
        f.write('    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n')
        f.write('</adaptive-icon>')

    # Create colors.xml if it doesn't exist to define background color
    values_dir = os.path.join(res_dir, "values")
    os.makedirs(values_dir, exist_ok=True)
    colors_path = os.path.join(values_dir, "colors.xml")
    
    # We'll use white as default background for the adaptive icon
    with open(colors_path, "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n')
        f.write('<resources>\n')
        f.write('    <color name="ic_launcher_background">#FFFFFF</color>\n')
        f.write('</resources>')

    # Generate foreground icons (108dp equivalent)
    # For adaptive icons, the foreground should be 108x108dp, but the visible area is 72x72dp
    # We'll scale the source icon to fit within the safe zone (approx 66% of 108dp)
    
    # 108dp in pixels:
    # mdpi: 108
    # hdpi: 162
    # xhdpi: 216
    # xxhdpi: 324
    # xxxhdpi: 432
    
    foreground_densities = {
        "mipmap-mdpi": 108,
        "mipmap-hdpi": 162,
        "mipmap-xhdpi": 216,
        "mipmap-xxhdpi": 324,
        "mipmap-xxxhdpi": 432
    }

    for folder, size in foreground_densities.items():
        # For foreground, we want the icon to be centered and slightly smaller to fit safe zone
        with Image.open(source_png) as img:
            img = img.convert("RGBA")
            # Calculate safe size (approx 60% of total size to be safe)
            safe_size = int(size * 0.6)
            img = img.resize((safe_size, safe_size), Image.Resampling.LANCZOS)
            
            # Create a transparent canvas of full size
            canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
            # Paste icon in center
            offset = (size - safe_size) // 2
            canvas.paste(img, (offset, offset), img)
            
            output_path = os.path.join(res_dir, folder, "ic_launcher_foreground.png")
            canvas.save(output_path, "PNG")
            print(f"Generated Foreground: {output_path} ({size}x{size})")

    print("\nIcon update complete! All densities and adaptive icon configurations have been generated.")

if __name__ == "__main__":
    main()
