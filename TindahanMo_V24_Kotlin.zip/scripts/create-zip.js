import archiver from 'archiver';
import { createWriteStream, existsSync, statSync, readdirSync } from 'fs';
import path from 'path';

const projectDir = '/vercel/share/v0-project';
const zipName = 'TindahanMoFixed_v1.2.0.zip';
const zipPath = `/tmp/${zipName}`;

console.log('Creating ZIP file for TindahanMo v1.2.0...');
console.log('Project directory:', projectDir);

// List what's actually in the directory
console.log('\nFiles in project directory:');
try {
  const files = readdirSync(projectDir);
  files.forEach(f => console.log('  -', f));
} catch (e) {
  console.log('Error reading directory:', e.message);
}

// Create output stream
const output = createWriteStream(zipPath);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`\nZIP file created successfully: ${zipPath}`);
  console.log(`Total bytes: ${archive.pointer()}`);
  console.log(`\nChanges in this version (v1.2.0):`);
  console.log(`- EMBEDDED Barcode Scanner: Uses device camera directly via ML Kit`);
  console.log(`- NO external barcode scanner app required`);
  console.log(`- Beautiful scanner UI with scan frame overlay`);
  console.log(`- Flash/torch toggle support`);
  console.log(`- Supports all common barcode formats (UPC, EAN, Code128, QR, etc.)`);
  console.log(`- Fixed receipt printing: Opens Android print dialog`);
  console.log(`- Fixed receipt sharing: Opens Android share sheet`);
  console.log(`- Added Save as PDF: Saves receipt to Downloads folder`);
});

archive.on('error', (err) => {
  console.error('Archive error:', err);
  throw err;
});

archive.pipe(output);

// Files and directories to include
const includeItems = [
  'app',
  'gradle',
  'build.gradle',
  'gradle.properties',
  'gradlew',
  'local.properties.template',
  'settings.gradle'
];

// Add files using glob pattern for the entire project
console.log('\nAdding files to archive...');

for (const item of includeItems) {
  const fullPath = path.join(projectDir, item);
  console.log(`Checking: ${fullPath}`);
  
  if (existsSync(fullPath)) {
    const stat = statSync(fullPath);
    if (stat.isDirectory()) {
      archive.directory(fullPath, item);
      console.log(`  Added directory: ${item}`);
    } else {
      archive.file(fullPath, { name: item });
      console.log(`  Added file: ${item}`);
    }
  } else {
    console.log(`  Not found: ${item}`);
  }
}

await archive.finalize();
