package com.tindahanmo.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {

    companion object {
        private const val TAG = "TindahanMo"
        private const val REQUEST_CAMERA_PERMISSION = 100
        private const val REQUEST_IMAGE_CAPTURE     = 101
        private const val REQUEST_IMAGE_PICK        = 102
        private const val REQUEST_BARCODE_SCAN      = 103
        private const val REQUEST_WRITE_STORAGE     = 104
        private const val REQUEST_BT_PERMISSIONS    = 105
        private const val REQUEST_ENABLE_BT         = 106
        // Standard SPP UUID for ESC/POS Bluetooth thermal printers
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private lateinit var webView: WebView
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isNetworkAvailable = false

    private var pendingReceiptHtml:   String? = null
    private var pendingReceiptNumber: String? = null
    private var pendingCameraAction:  String  = "barcode"

    // Bluetooth
    private var bluetoothAdapter:  BluetoothAdapter? = null
    private var pendingBtPrintText: String? = null
    private var pendingBtAddress:   String? = null

    // ─── Lifecycle ────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        val settings = webView.settings
        settings.javaScriptEnabled    = true
        settings.domStorageEnabled    = true
        settings.allowFileAccess      = true
        settings.allowContentAccess   = true
        settings.mixedContentMode     = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode            = WebSettings.LOAD_DEFAULT
        settings.loadWithOverviewMode = true
        settings.useWideViewPort      = true
        settings.databaseEnabled      = true

        webView.addJavascriptInterface(WebAppInterface(), "Android")
        setupNetworkMonitoring()
        initBluetooth()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("file://") || url.startsWith("about:")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (e: Exception) { Log.e(TAG, "URL error: ${e.message}") }
                return true
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onDestroy() {
        networkCallback?.let { connectivityManager.unregisterNetworkCallback(it) }
        webView.destroy()
        super.onDestroy()
    }

    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onPause()  { super.onPause();  webView.onPause()  }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else { @Suppress("DEPRECATION") super.onBackPressed() }
    }

    // ─── Network ─────────────────────────────────────────────────

    private fun setupNetworkMonitoring() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        isNetworkAvailable  = isCurrentlyConnected()
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(@NonNull n: Network) { isNetworkAvailable = true;  updateWebNetworkStatus(true)  }
            override fun onLost(@NonNull n: Network)      { isNetworkAvailable = false; updateWebNetworkStatus(false) }
        }
        val req = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        connectivityManager.registerNetworkCallback(req, networkCallback!!)
    }

    private fun isCurrentlyConnected(): Boolean {
        val net  = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(net)
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateWebNetworkStatus(available: Boolean) {
        runOnUiThread {
            webView.evaluateJavascript(
                "if(window.onNetworkStatusChanged) window.onNetworkStatusChanged($available);", null)
        }
    }

    // ─── Bluetooth init ───────────────────────────────────────────

    private fun initBluetooth() {
        val btMgr = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        bluetoothAdapter = btMgr?.adapter
    }

    private fun hasBtPermissions(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)    == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH)       == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestBtPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else
            arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN)
        ActivityCompat.requestPermissions(this, perms, REQUEST_BT_PERMISSIONS)
    }

    // ─── JS Interface ─────────────────────────────────────────────

    inner class WebAppInterface {

        @JavascriptInterface
        fun isNetworkAvailable(): Boolean = this@MainActivity.isNetworkAvailable

        // Camera / Barcode

        @JavascriptInterface
        fun scanBarcode() = runOnUiThread {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                pendingCameraAction = "barcode"
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
            } else startEmbeddedBarcodeScanner()
        }

        @JavascriptInterface
        fun pickImage() = runOnUiThread {
            startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), REQUEST_IMAGE_PICK)
        }

        @JavascriptInterface
        fun takePhoto() = runOnUiThread {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                pendingCameraAction = "photo"
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
            } else launchCamera()
        }

        // System (WiFi) print

        @JavascriptInterface
        fun printReceipt(receiptHtml: String, receiptNumber: String) = runOnUiThread {
            try {
                val pm = getSystemService(PRINT_SERVICE) as? PrintManager ?: run {
                    Toast.makeText(this@MainActivity, "Print service not available", Toast.LENGTH_SHORT).show(); return@runOnUiThread
                }
                val pv = WebView(this@MainActivity)
                pv.settings.javaScriptEnabled = true
                val html = """<!DOCTYPE html><html><head><meta charset='utf-8'>
                    <style>body{font-family:'Courier New',monospace;padding:20px;max-width:300px;margin:0 auto;}
                    .center{text-align:center;}.bold{font-weight:bold;}
                    .row{display:flex;justify-content:space-between;margin:5px 0;}
                    .divider{border-top:1px dashed #000;margin:10px 0;}</style></head><body>$receiptHtml</body></html>"""
                pv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                pv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        val job = "Receipt_$receiptNumber"
                        pm.print(job, pv.createPrintDocumentAdapter(job),
                            PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A7).build())
                    }
                }
                Toast.makeText(this@MainActivity, "Opening print dialog…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Print error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        // Bluetooth thermal print

        @JavascriptInterface
        fun scanBluetoothPrinters() = runOnUiThread {
            if (!hasBtPermissions()) { requestBtPermissions(); return@runOnUiThread }
            val adapter = bluetoothAdapter ?: run {
                Toast.makeText(this@MainActivity, "Bluetooth not supported on this device", Toast.LENGTH_SHORT).show(); return@runOnUiThread
            }
            if (!adapter.isEnabled) {
                startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT)
                return@runOnUiThread
            }
            sendPairedDevicesToWeb()
        }

        @JavascriptInterface
        fun bluetoothPrintReceipt(receiptText: String, printerAddress: String) {
            if (!hasBtPermissions()) {
                pendingBtPrintText = receiptText
                pendingBtAddress   = printerAddress
                runOnUiThread { requestBtPermissions() }
                return
            }
            Thread { doBtPrint(receiptText, printerAddress) }.start()
        }

        // Share / PDF

        @JavascriptInterface
        fun shareReceipt(receiptText: String, receiptNumber: String) = runOnUiThread {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Receipt #$receiptNumber - Tindahan Mo")
                    putExtra(Intent.EXTRA_TEXT, receiptText)
                }
                if (intent.resolveActivity(packageManager) != null)
                    startActivity(Intent.createChooser(intent, "Share Receipt via"))
                else Toast.makeText(this@MainActivity, "No apps to share with", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Share error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        @JavascriptInterface
        fun saveReceiptAsPdf(receiptHtml: String, receiptNumber: String) = runOnUiThread {
            pendingReceiptHtml   = receiptHtml
            pendingReceiptNumber = receiptNumber
            generateAndSavePdf()
        }
    }

    // ─── Bluetooth helpers ────────────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun sendPairedDevicesToWeb() {
        val adapter = bluetoothAdapter ?: return
        try {
            val paired: Set<BluetoothDevice> = adapter.bondedDevices ?: emptySet()
            val arr = JSONArray()
            for (dev in paired) {
                arr.put(JSONObject().apply {
                    put("name",    dev.name    ?: "Unknown")
                    put("address", dev.address ?: "")
                })
            }
            val escaped = arr.toString().replace("\\", "\\\\").replace("'", "\\'")
            runOnUiThread { webView.evaluateJavascript("onBluetoothDevicesFound('$escaped')", null) }
            if (paired.isEmpty()) runOnUiThread {
                Toast.makeText(this, "No paired devices found. Pair your printer in Android Settings → Bluetooth first.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "BT list error: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun doBtPrint(text: String, address: String) {
        var socket: BluetoothSocket? = null
        var out: OutputStream? = null
        try {
            val adapter = bluetoothAdapter ?: throw IOException("Bluetooth not available")
            if (!adapter.isEnabled) throw IOException("Bluetooth is turned off")

            val device = adapter.getRemoteDevice(address)
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            adapter.cancelDiscovery()
            socket.connect()
            out = socket.outputStream

            // ESC/POS: Initialize printer
            out.write(byteArrayOf(0x1B, 0x40))
            // 2 blank lines at top
            out.write(byteArrayOf(0x1B, 0x64, 0x02))
            // Print receipt text
            out.write(text.toByteArray(Charsets.UTF_8))
            // Feed 4 lines then full cut
            out.write(byteArrayOf(0x1B, 0x64, 0x04))
            out.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00))
            out.flush()

            runOnUiThread { Toast.makeText(this, "✓ Receipt sent to printer!", Toast.LENGTH_SHORT).show() }

        } catch (e: Exception) {
            Log.e(TAG, "BT print error: ${e.message}")
            runOnUiThread {
                Toast.makeText(this, "Bluetooth print failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } finally {
            try { out?.close() }    catch (_: Exception) {}
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    // ─── Camera helpers ───────────────────────────────────────────

    private fun startEmbeddedBarcodeScanner() =
        startActivityForResult(Intent(this, BarcodeScannerActivity::class.java), REQUEST_BARCODE_SCAN)

    private fun launchCamera() =
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), REQUEST_IMAGE_CAPTURE)

    // ─── PDF ──────────────────────────────────────────────────────

    private fun generateAndSavePdf() {
        val html   = pendingReceiptHtml   ?: return
        val number = pendingReceiptNumber ?: return
        try {
            val doc  = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(300, 500, 1).create())
            page.canvas.drawColor(Color.WHITE)
            val pv = WebView(this)
            pv.settings.javaScriptEnabled = false
            pv.setBackgroundColor(Color.WHITE)
            val content = """<!DOCTYPE html><html><head><meta charset='utf-8'>
                <style>body{font-family:Arial,sans-serif;padding:10px;font-size:10px;}
                .center{text-align:center;}.bold{font-weight:bold;}
                .row{display:flex;justify-content:space-between;margin:3px 0;}
                .divider{border-top:1px dashed #000;margin:8px 0;}</style></head><body>$html</body></html>"""
            pv.layout(0, 0, 300, 500)
            pv.loadDataWithBaseURL(null, content, "text/html", "UTF-8", null)
            pv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    view.draw(page.canvas)
                    doc.finishPage(page)
                    try {
                        val ts   = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        val name = "Receipt_${number}_$ts.pdf"
                        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name)
                        FileOutputStream(file).use { doc.writeTo(it) }
                        doc.close()
                        Toast.makeText(this@MainActivity, "PDF saved: $name", Toast.LENGTH_LONG).show()
                        val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "application/pdf")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            })
                        } catch (_: ActivityNotFoundException) {
                            Toast.makeText(this@MainActivity, "PDF saved. Install a PDF viewer to open it.", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: IOException) {
                        Toast.makeText(this@MainActivity, "PDF save error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                    pendingReceiptHtml   = null
                    pendingReceiptNumber = null
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "PDF generation error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ─── Activity results ─────────────────────────────────────────

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                REQUEST_IMAGE_PICK -> {
                    data?.data?.let { uri ->
                        try { sendImageToWeb(MediaStore.Images.Media.getBitmap(contentResolver, uri)) }
                        catch (e: IOException) { Log.e(TAG, "Image load error: ${e.message}") }
                    }
                }
                REQUEST_IMAGE_CAPTURE -> {
                    (data?.extras?.get("data") as? Bitmap)?.let { sendImageToWeb(it) }
                }
                REQUEST_BARCODE_SCAN -> {
                    val barcode = data?.getStringExtra(BarcodeScannerActivity.EXTRA_BARCODE_RESULT)
                    if (!barcode.isNullOrEmpty()) {
                        webView.post { webView.evaluateJavascript("onBarcodeScanned('$barcode')", null) }
                        Toast.makeText(this, "Scanned: $barcode", Toast.LENGTH_SHORT).show()
                    }
                }
                REQUEST_ENABLE_BT -> sendPairedDevicesToWeb()
            }
        } else if (resultCode == RESULT_CANCELED && requestCode == REQUEST_BARCODE_SCAN) {
            Toast.makeText(this, "Scan cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    // ─── Permissions ──────────────────────────────────────────────

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_CAMERA_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (pendingCameraAction == "photo") launchCamera() else startEmbeddedBarcodeScanner()
                } else {
                    Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
                    if (pendingCameraAction == "barcode") webView.evaluateJavascript("openManualBarcodeInput()", null)
                }
            }
            REQUEST_WRITE_STORAGE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) generateAndSavePdf()
                else Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
            }
            REQUEST_BT_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                    val txt  = pendingBtPrintText
                    val addr = pendingBtAddress
                    if (txt != null && addr != null) {
                        pendingBtPrintText = null; pendingBtAddress = null
                        Thread { doBtPrint(txt, addr) }.start()
                    } else {
                        sendPairedDevicesToWeb()
                    }
                } else {
                    Toast.makeText(this, "Bluetooth permission required to use printer", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ─── Image helper ─────────────────────────────────────────────

    private fun sendImageToWeb(bitmap: Bitmap) {
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        val encoded = Base64.encodeToString(bos.toByteArray(), Base64.DEFAULT)
        webView.post {
            webView.evaluateJavascript(
                "onImageUploaded('data:image/jpeg;base64,${encoded.replace("\n", "")}')", null)
        }
    }
}
