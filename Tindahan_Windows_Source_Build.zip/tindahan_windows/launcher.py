"""
Tindahan Mo — Windows Desktop Launcher
========================================
• WebView  : pywebview with Microsoft Edge WebView2 (built into Win 10/11)
• Backend  : Django + wsgiref on a free localhost port
• Database : SQLCipher via sqlcipher3 (pre-built Windows wheel)
• Data dir : %APPDATA%\\TindahanMo
• Printing : os.startfile() → default browser → Ctrl+P
"""
import os, sys, threading, time, socket, shutil, tempfile
from pathlib import Path

# ── User data directory ───────────────────────────────────────────────────────
APP_DATA_DIR = Path(os.environ.get("APPDATA", Path.home())) / "TindahanMo"
VERSION      = "2.1.0"    # bump this → app files refresh on next launch

# ── Splash screen shown while Django boots ────────────────────────────────────
LOADING_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Tindahan Mo</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
  display:flex;align-items:center;justify-content:center;height:100vh;
  font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;color:#fff;
  user-select:none;-webkit-user-select:none}
.card{text-align:center;animation:fadeIn .6s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.logo{font-size:72px;margin-bottom:18px}
h1{font-size:38px;font-weight:900;color:#f5c518;letter-spacing:1px}
p{margin-top:12px;font-size:15px;opacity:.7;color:#ccc}
.sub{font-size:12px;opacity:.5;margin-top:6px}
.dots span{display:inline-block;width:8px;height:8px;border-radius:50%;
  background:#f5c518;margin:0 3px;animation:bounce 1.2s infinite}
.dots span:nth-child(2){animation-delay:.2s}
.dots span:nth-child(3){animation-delay:.4s}
@keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-12px)}}
</style></head>
<body><div class="card">
  <div class="logo">&#127978;</div>
  <h1>Tindahan Mo</h1>
  <p>Loading your store&nbsp;<span class="dots">
    <span></span><span></span><span></span></span></p>
  <p class="sub">Windows Edition v2.1</p>
</div></body></html>"""


# ── JavaScript API (callable from the webpage) ────────────────────────────────
class TindahanAPI:
    """
    Exposed to JS as:  pywebview.api.method_name(args)
    """

    def print_receipt(self, html: str) -> dict:
        """
        Write a receipt to a temp .html file and open it in the default
        browser. The browser's built-in print dialog then handles printing.
        """
        try:
            fd, tmp = tempfile.mkstemp(
                suffix=".html", prefix="tindahan_rcpt_",
                dir=tempfile.gettempdir()
            )
            os.close(fd)
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(html)
            os.startfile(tmp)           # opens in default browser on Windows

            def _cleanup():
                time.sleep(300)         # 5 min grace period for slow printers
                try: os.unlink(tmp)
                except: pass
            threading.Thread(target=_cleanup, daemon=True).start()
            return {"ok": True}
        except Exception as exc:
            import traceback; traceback.print_exc()
            return {"ok": False, "err": str(exc)}

    def open_data_folder(self) -> dict:
        """Open the TindahanMo data folder in Windows Explorer."""
        try:
            os.startfile(str(APP_DATA_DIR))
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "err": str(exc)}

    def get_app_version(self) -> str:
        return VERSION


# ── Internals ─────────────────────────────────────────────────────────────────
def _bundle_dir() -> Path:
    """PyInstaller extracts to _MEIPASS; in dev mode use the script dir."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _setup_data_dir() -> bool:
    """
    On first launch (or after a version update) copy app source from the bundle
    into %APPDATA%\\TindahanMo so the app can update its own files later.
    Returns True on a completely fresh install (no database exists yet).
    """
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    bundle = _bundle_dir()
    stamp  = APP_DATA_DIR / ".version"

    # Refresh app source when version changes
    if not stamp.exists() or stamp.read_text(encoding="utf-8").strip() != VERSION:
        print(f"🔄  Installing / updating app to v{VERSION}…")
        for pkg in ("store", "tindahan_project"):
            src, dst = bundle / pkg, APP_DATA_DIR / pkg
            if src.exists():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
        for fname in ("manage.py",):
            s = bundle / fname
            if s.exists():
                shutil.copy2(s, APP_DATA_DIR / fname)
        stamp.write_text(VERSION, encoding="utf-8")
        print("✅  App files updated")

    is_fresh = not (APP_DATA_DIR / "tindahan_secure.db").exists()

    # Ensure media directories exist
    for sub in ("products", "avatars", "logos"):
        (APP_DATA_DIR / "media" / sub).mkdir(parents=True, exist_ok=True)

    # On first install copy bundled sample media if present
    msrc = bundle / "media"
    if msrc.exists() and is_fresh:
        shutil.copytree(msrc, APP_DATA_DIR / "media", dirs_exist_ok=True)

    return is_fresh


# ── Django server thread ──────────────────────────────────────────────────────
_httpd = None

def _run_django(port: int) -> None:
    global _httpd

    os.environ["DJANGO_SETTINGS_MODULE"] = "tindahan_project.settings"
    os.environ["TINDAHAN_BASE_DIR"]       = str(APP_DATA_DIR)
    sys.path.insert(0, str(APP_DATA_DIR))

    import django
    django.setup()

    from django.core.management import call_command
    call_command("migrate", "--run-syncdb", verbosity=0)

    from store.db import init_db
    init_db()
    print("✅  Database ready")

    # Start background cloud sync
    try:
        from store.sync import get_engine
        from django.conf import settings as djsettings
        eng = get_engine()
        eng.configure(
            djsettings.TINDAHAN_DB_PATH,
            djsettings.TINDAHAN_DB_KEY,
            str(djsettings.MEDIA_ROOT),
        )
        eng.start()
        print("☁️   Cloud sync engine started")
    except Exception as exc:
        print(f"⚠️   Sync engine skipped: {exc}")

    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler

    class _Silent(WSGIRequestHandler):
        def log_message(self, *_): pass   # suppress request logging

    app    = get_wsgi_application()
    _httpd = make_server("127.0.0.1", port, app, handler_class=_Silent)
    print(f"🌐  Django running → http://127.0.0.1:{port}")
    _httpd.serve_forever()


def _wait_server(port: int, timeout: float = 30.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.2)
    return False


def _shutdown():
    global _httpd
    print("🛑  Stopping sync engine…")
    try:
        from store.sync import get_engine
        get_engine().stop()
    except Exception:
        pass
    if _httpd:
        try: _httpd.shutdown()
        except Exception: pass
    time.sleep(0.3)


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    print("=" * 55)
    print("  Tindahan Mo  ·  Windows Edition  ·  v" + VERSION)
    print("=" * 55)

    is_fresh = _setup_data_dir()
    print("🌟  Fresh install → will show setup wizard" if is_fresh
          else f"✅  Data directory: {APP_DATA_DIR}")

    port = _free_port()
    print(f"🔌  Port: {port}")

    # Start Django in a background thread
    t = threading.Thread(
        target=_run_django, args=(port,),
        daemon=False, name="django"
    )
    t.start()

    import webview

    api    = TindahanAPI()
    window = webview.create_window(
        title     = "Tindahan Mo",
        html      = LOADING_HTML,
        width     = 1366,
        height    = 868,
        min_size  = (1024, 640),
        resizable = True,
        js_api    = api,
    )

    def _load():
        if _wait_server(port):
            window.load_url(f"http://127.0.0.1:{port}")
        else:
            window.load_html(
                "<body style='background:#1a1a2e;color:#f5c518;"
                "font-family:Segoe UI,sans-serif;display:flex;"
                "flex-direction:column;align-items:center;"
                "justify-content:center;height:100vh;gap:16px'>"
                "<h2>&#10060; Server failed to start</h2>"
                "<p style='opacity:.6'>Close the window and relaunch Tindahan Mo.</p>"
                "</body>"
            )

    threading.Thread(target=_load, daemon=True).start()

    # gui='edgechromium' = Microsoft Edge WebView2 (built into Windows 10/11)
    # No extra install needed on any modern Windows machine.
    webview.start(gui="edgechromium", debug=False)

    print("🛑  Window closed")
    _shutdown()
    print("👋  Goodbye.")


if __name__ == "__main__":
    main()
