# tindahan_windows.spec
# PyInstaller spec for Tindahan Mo — Windows 10/11
# Run from project root:
#   pyinstaller tindahan_windows.spec --noconfirm --clean
#
# Output: dist\TindahanMo\TindahanMo.exe  (one-folder bundle)
#         dist\TindahanMo.zip             (created by build.bat)

from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_submodules

PROJECT = Path(SPECPATH)

datas, binaries, hiddenimports = [], [], []

# ── Collect full packages ─────────────────────────────────────────────────────
for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

# ── App source folders ────────────────────────────────────────────────────────
for folder in ("store", "tindahan_project"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

# ── Loose files ───────────────────────────────────────────────────────────────
for fname in ("manage.py", "tindahan.ico"):
    p = PROJECT / fname
    if p.is_file():
        datas.append((str(p), "."))

if (PROJECT / "store" / "favicon.ico").is_file():
    datas.append((str(PROJECT / "store" / "favicon.ico"), "store"))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

# ── sqlcipher3 DLL (Windows pre-built wheel bundles a .pyd + sqlcipher.dll) ──
try:
    import sqlcipher3
    import os
    sc_dir = Path(sqlcipher3.__file__).parent
    for dll in sc_dir.glob("*.dll"):
        binaries.append((str(dll), "."))
    for pyd in sc_dir.glob("*.pyd"):
        datas.append((str(pyd), "."))
except ImportError:
    pass

a = Analysis(
    [str(PROJECT / "launcher.py")],
    pathex        = [str(PROJECT)],
    binaries      = binaries,
    datas         = datas,
    hiddenimports = list(set(hiddenimports)) + [
        # Django internals
        "django.template.defaulttags",
        "django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security",
        "django.middleware.common",
        # App modules
        "store",
        "store.views",
        "store.db",
        "store.sync",
        "store.apps",
        "store.urls",
        "tindahan_project.settings",
        "tindahan_project.urls",
        "tindahan_project.wsgi",
        # SQLCipher (Windows)
        "sqlcipher3",
        "sqlcipher3.dbapi2",
        # pywebview Windows backend
        "webview.platforms.winforms",
        "webview.platforms.edgechromium",
        "clr",
        # Crypto
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes",
        "cryptography.fernet",
        # stdlib
        "wsgiref.simple_server",
        "wsgiref.handlers",
        "urllib.request",
        "urllib.parse",
        "importlib.metadata",
        "email.mime.text",
        "json",
        "threading",
        "socket",
    ],
    excludes = [
        "tkinter", "PyQt5", "PyQt6", "PySide2", "PySide6",
        "wx", "gi", "matplotlib", "numpy", "pandas",
        "IPython", "notebook", "pytest",
    ],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

# Windows .exe — no console window
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries = True,
    name    = "TindahanMo",
    debug   = False,
    strip   = False,
    upx     = True,
    console = False,                    # no black console window
    icon    = str(PROJECT / "tindahan.ico") if (PROJECT / "tindahan.ico").exists() else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    strip = False,
    upx   = True,
    name  = "TindahanMo",   # → dist\TindahanMo\
)
