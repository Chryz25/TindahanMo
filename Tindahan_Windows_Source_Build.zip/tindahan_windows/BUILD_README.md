# Tindahan Mo — Windows Build Guide
## Complete step-by-step for Windows 10 / 11

---

## What You Get

After building, you get **`dist\TindahanMo\TindahanMo.exe`** — a standalone
Windows desktop app. No Python installation is needed on the machine that
*runs* the app. Just copy the `TindahanMo` folder (or the `.zip`) anywhere and
run it.

---

## Requirements (Build Machine Only)

| Requirement | Version | Download |
|-------------|---------|----------|
| Windows | 10 or 11 (64-bit) | — |
| Python | **3.10 or 3.11** ✅ | [python.org/downloads](https://www.python.org/downloads/) |
| Git (optional) | any | [git-scm.com](https://git-scm.com) |

> **Important during Python install:**  
> ☑ Check **"Add Python to PATH"**  
> ☑ Check **"Install for all users"** (recommended)

---

## Step-by-Step Build Instructions

### Step 1 — Extract the project

Unzip `TindahanMo-Windows-Source.zip` to any folder, e.g.:
```
C:\Users\YourName\Desktop\TindahanMo\
```

### Step 2 — Run the build script

**Option A — Double-click** (easiest):
```
Double-click  build.bat
```

**Option B — Command Prompt**:
```cmd
cd C:\Users\YourName\Desktop\TindahanMo
build.bat
```

**Option C — PowerShell**:
```powershell
cd C:\Users\YourName\Desktop\TindahanMo
.\build.bat
```

### Step 3 — Wait (3–10 minutes first time)

The script will:
1. ✅ Check Python version
2. ✅ Create a virtual environment (`.venv\`)
3. ✅ Download and install all Python packages (~200 MB)
4. ✅ Generate the app icon (`tindahan.ico`)
5. ✅ Build the `.exe` with PyInstaller
6. ✅ Create `dist\TindahanMo.zip` for distribution

### Step 4 — Run the app

```
dist\TindahanMo\TindahanMo.exe
```

Or press any key when build.bat asks — it launches automatically.

---

## What Gets Installed (Python Packages)

| Package | Purpose |
|---------|---------|
| `Django 4.x` | Web framework serving the local UI |
| `pywebview 5.x` | Desktop window using Edge WebView2 |
| `sqlcipher3-wheels` | Encrypted SQLite database (pre-built, no C compiler needed) |
| `cryptography` | Key derivation and encryption utilities |
| `Pillow` | Icon generation only (not shipped with the app) |
| `PyInstaller` | Bundles everything into a single `.exe` |

---

## Where User Data Is Stored

All store data is saved in:
```
C:\Users\YourName\AppData\Roaming\TindahanMo\
```

This folder contains:
- `tindahan_secure.db` — encrypted SQLite (AES-256 via SQLCipher)
- `django_sessions.db` — login sessions
- `media\` — product images, avatars, logos

> **To back up your store**, just copy this entire folder.

---

## Distributing to Another Windows Computer

### Option A — Copy the folder
Copy `dist\TindahanMo\` to the other computer. Run `TindahanMo.exe`.
No Python or any other software needed.

### Option B — Use the ZIP
Send `dist\TindahanMo.zip`. Extract → run `TindahanMo.exe`.

### Notes on distribution:
- Works on any Windows 10 / 11 64-bit machine
- Edge WebView2 is built into Windows 10 (v1803+) and Windows 11
- If a very old Windows 10 doesn't have WebView2:
  download the runtime from https://go.microsoft.com/fwlink/p/?LinkId=2124703

---

## Cloud Sync Setup (Supabase)

1. Create a free account at [supabase.com](https://supabase.com)
2. Create a new project
3. Go to **SQL Editor** → paste contents of `supabase_schema.sql` → **Run**
4. Get your **Project URL** and **anon key** from Project Settings → API
5. In the app: go to **Cloud Sync** → **Register Store** (first computer)
6. On other computers: use **Connect Existing Store** with the same credentials

---

## Troubleshooting

### "Python not found"
Reinstall Python and check **"Add Python to PATH"** during setup.

### "sqlcipher3 install failed"
```cmd
pip install sqlcipher3-wheels --force-reinstall
```
If still failing, try: `pip install sqlcipher3` (requires Visual C++ Build Tools).

### "pywebview import error" or blank window
Make sure you're on Windows 10 version 1803 or later. Check Windows Update.

### App opens but shows white screen
Edge WebView2 may not be current. Run Windows Update, or manually install:
https://go.microsoft.com/fwlink/p/?LinkId=2124703

### "Access denied" writing to AppData
Run the `.exe` as your normal user (not as Administrator).

### Build takes very long / seems stuck
Normal on first run — PyInstaller is collecting ~300 MB of dependencies.
Wait 10–15 minutes. Subsequent builds take 1–2 minutes.

### antivirus flags TindahanMo.exe
PyInstaller executables are sometimes flagged as false positives.
Add an exclusion in Windows Defender for the `dist\TindahanMo\` folder.

---

## Dev Mode (Testing Without Building)

After running `build.bat` once (to set up `.venv` and packages):

```cmd
dev_run.bat
```

This launches the app directly with Python — no .exe needed, useful for
development and testing.

---

## Project Structure

```
TindahanMo-Windows-Source\
├── launcher.py              ← Windows app entry point
├── build.bat                ← Double-click to build
├── dev_run.bat              ← Run without building (dev mode)
├── tindahan_windows.spec    ← PyInstaller config
├── make_icon_windows.py     ← Generates tindahan.ico
├── requirements_windows.txt ← Python packages list
├── supabase_schema.sql      ← Cloud database setup (run in Supabase)
├── manage.py                ← Django management
├── store\                   ← Main app (views, models, sync, templates)
├── tindahan_project\        ← Django project config
└── media\                   ← Default images
```

---

## Version History

| Version | Changes |
|---------|---------|
| 2.1.0 | Full cloud sync: products, users, categories, sales |
| 2.0.0 | Hybrid cloud architecture with Supabase |
| 1.0.0 | Local-only encrypted desktop app |
