@echo off
REM ============================================================
REM  Tindahan Mo — Windows Build Script
REM  Double-click OR run from Command Prompt / PowerShell
REM
REM  Prerequisites (installed automatically if missing):
REM    • Python 3.10 or 3.11  (from python.org)
REM    • pip packages: see requirements_windows.txt
REM
REM  Output:
REM    dist\TindahanMo\TindahanMo.exe    (run this)
REM    dist\TindahanMo.zip               (share/distribute this)
REM ============================================================

setlocal EnableDelayedExpansion
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo.
echo   ============================================================
echo    Tindahan Mo  .  Windows Build  .  v2.1
echo   ============================================================
echo.

REM ── 1. Check Python ──────────────────────────────────────────
echo [1/6] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo   ERROR: Python not found in PATH.
    echo.
    echo   Please install Python 3.10 or 3.11 from:
    echo   https://www.python.org/downloads/
    echo.
    echo   IMPORTANT: Check "Add Python to PATH" during install!
    echo.
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo   Python found: %PYVER%

REM Check for Python 3.10 or 3.11 (most compatible for pywebview + sqlcipher3)
python -c "import sys; exit(0 if sys.version_info[:2] in [(3,10),(3,11),(3,12)] else 1)" 2>nul
if errorlevel 1 (
    echo.
    echo   WARNING: Python %PYVER% may have issues.
    echo   Recommended: Python 3.10 or 3.11
    echo   Continuing anyway...
    echo.
)
echo.

REM ── 2. Virtual environment ───────────────────────────────────
echo [2/6] Setting up virtual environment...
if not exist ".venv" (
    python -m venv .venv
    echo   Created new virtual environment.
) else (
    echo   Virtual environment found.
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo   ERROR: Could not activate virtual environment.
    pause
    exit /b 1
)

python -m pip install --upgrade pip --quiet
echo   pip upgraded.
echo.

REM ── 3. Install dependencies ──────────────────────────────────
echo [3/6] Installing Python packages (first run: ~5 min)...
echo   Installing: Django, pywebview, sqlcipher3, cryptography, pyinstaller...
echo.

pip install "Django>=4.2,<6.0" --quiet
pip install "pywebview>=5.0" --quiet
pip install "sqlcipher3-wheels" --quiet
pip install "cryptography>=41.0" --quiet
pip install "pyinstaller>=6.0" --quiet
pip install "Pillow>=10.0" --quiet

REM Verify critical imports
echo.
echo   Verifying installations...
python -c "import django; print('   django        : OK  (', django.__version__, ')')"
python -c "import webview; print('   pywebview     : OK')"
python -c "import sqlcipher3; print('   sqlcipher3    : OK')"
python -c "import cryptography; print('   cryptography  : OK')"
python -c "import PyInstaller; print('   pyinstaller   : OK')"

echo.

REM ── 4. Generate icon ─────────────────────────────────────────
echo [4/6] Generating application icon...
python make_icon_windows.py
if exist "tindahan.ico" (
    echo   tindahan.ico  : OK
) else (
    echo   WARNING: Icon not generated - build will continue without it.
)
echo.

REM ── 5. Build with PyInstaller ────────────────────────────────
echo [5/6] Building executable with PyInstaller (3-10 minutes)...
echo   This may look like it hangs - please wait...
echo.

REM Clean previous build
if exist "build" rmdir /s /q "build"
if exist "dist\TindahanMo" rmdir /s /q "dist\TindahanMo"

REM Clean .pyc files
for /r /d %%d in (__pycache__) do if exist "%%d" rmdir /s /q "%%d" 2>nul
del /s /q "*.pyc" >nul 2>&1

pyinstaller tindahan_windows.spec --noconfirm --clean
if errorlevel 1 (
    echo.
    echo   ERROR: PyInstaller failed.
    echo   Check the output above for details.
    echo.
    pause
    exit /b 1
)

REM Verify output
if not exist "dist\TindahanMo\TindahanMo.exe" (
    echo   ERROR: TindahanMo.exe not found after build.
    pause
    exit /b 1
)
echo.
echo   PyInstaller build complete.
echo.

REM ── 6. Create ZIP for distribution ───────────────────────────
echo [6/6] Creating distribution ZIP...
if exist "dist\TindahanMo.zip" del /q "dist\TindahanMo.zip"

powershell -command "Compress-Archive -Path 'dist\TindahanMo' -DestinationPath 'dist\TindahanMo.zip' -Force"
if exist "dist\TindahanMo.zip" (
    echo   ZIP created: dist\TindahanMo.zip
) else (
    echo   WARNING: ZIP creation failed (app still works without it).
)

REM ── Done! ─────────────────────────────────────────────────────
echo.
echo   ============================================================
echo    BUILD SUCCESSFUL
echo   ============================================================
echo.
echo   Executable : dist\TindahanMo\TindahanMo.exe
echo   Distribute : dist\TindahanMo.zip
echo.
echo   To run now, press any key (or double-click the .exe later).
echo.
pause

REM Launch the app after build
start "" "dist\TindahanMo\TindahanMo.exe"
