"""
store/sync.py — Tindahan Mo Hybrid Sync Engine  (v4 — image sync + full upsert)
================================================================================
LOCAL → CLOUD  (push, every 15s via queue)
  categories, products (with image upload), users (with avatar upload),
  sales, store_settings (with logo upload)

CLOUD → LOCAL  (pull, every 30s)
  store_settings (name, tagline, logo download)
  categories      — UPSERT
  products        — UPSERT + image download
  users           — UPSERT + avatar download (owner never overwritten)

Images:
  Push: read local file → PUT to Supabase Storage → store public URL in cloud row
  Pull: if cloud image_url differs from local → download to /media/ → update local DB
"""

import json
import os
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

_engine: "SyncEngine | None" = None

def get_engine() -> "SyncEngine":
    global _engine
    if _engine is None:
        _engine = SyncEngine()
    return _engine


class SyncEngine:
    PUSH_INTERVAL = 15
    PULL_INTERVAL = 30
    MAX_ATTEMPTS  = 5
    BATCH_SIZE    = 50

    def __init__(self):
        self._db_path: str | None = None
        self._db_key:  str | None = None
        self._media_root: str | None = None
        self._stop     = threading.Event()
        self._thread:  threading.Thread | None = None
        self._lock     = threading.Lock()
        self.enabled   = False
        self.status    = "unconfigured"
        self.last_sync = None
        self.last_error = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def configure(self, db_path: str, db_key: str, media_root: str = "") -> None:
        self._db_path   = db_path
        self._db_key    = db_key
        self._media_root = media_root
        cfg = self._load_config()
        with self._lock:
            self.enabled = bool(
                cfg and cfg["enabled"] and
                cfg["supabase_url"] and cfg["supabase_key"]
            )
            self.status = "offline" if self.enabled else "unconfigured"

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="tindahan-sync"
        )
        self._thread.start()
        print("☁️   Sync engine started")

    def stop(self) -> None:
        self._stop.set()

    # ── Main loop ─────────────────────────────────────────────────────────────

    def _loop(self) -> None:
        last_push = 0.0
        last_pull = 0.0
        while not self._stop.is_set():
            try:
                cfg = self._load_config()
                is_on = bool(
                    cfg and cfg["enabled"] and
                    cfg["supabase_url"] and cfg["supabase_key"]
                )
                with self._lock:
                    self.enabled = is_on
                    if not is_on:
                        self.status = "unconfigured"

                if is_on:
                    now = time.monotonic()
                    if now - last_push >= self.PUSH_INTERVAL:
                        self._push(cfg)
                        last_push = now
                    if now - last_pull >= self.PULL_INTERVAL:
                        self._pull(cfg)
                        last_pull = now
            except Exception as exc:
                with self._lock:
                    self.status     = "error"
                    self.last_error = str(exc)[:300]
            self._stop.wait(timeout=5)

    # ══════════════════════════════════════════════════════════════════════════
    # PUSH  (local → cloud)
    # ══════════════════════════════════════════════════════════════════════════

    def _push(self, cfg: dict) -> None:
        conn = self._get_db()
        try:
            rows = conn.execute(
                "SELECT * FROM sync_queue WHERE attempts < ? ORDER BY id LIMIT ?",
                (self.MAX_ATTEMPTS, self.BATCH_SIZE)
            ).fetchall()
        finally:
            conn.close()

        if not rows:
            with self._lock:
                if self.status == "syncing":
                    self.status = "synced"
            return

        with self._lock:
            self.status = "syncing"

        ok_ids:  list[int]    = []
        err_ids: list[tuple]  = []

        for row in rows:
            try:
                payload             = json.loads(row["payload"])
                payload["store_id"] = cfg["store_id"]

                # ── Upload image file to Supabase Storage before pushing ──
                if row["table_name"] in ("products", "users", "store_settings"):
                    payload = self._upload_image_if_needed(cfg, row["table_name"], payload)

                if row["operation"] == "upsert":
                    self._sb_upsert(cfg, row["table_name"], payload)
                elif row["operation"] == "delete":
                    self._sb_delete(cfg, row["table_name"],
                                    row["record_id"], cfg["store_id"])
                ok_ids.append(row["id"])
            except urllib.error.URLError:
                break
            except Exception as exc:
                err_ids.append((row["id"], str(exc)[:200]))

        conn = self._get_db()
        try:
            for qid in ok_ids:
                conn.execute("DELETE FROM sync_queue WHERE id=?", (qid,))
            for qid, err in err_ids:
                conn.execute(
                    "UPDATE sync_queue SET attempts=attempts+1, last_error=? WHERE id=?",
                    (err, qid)
                )
            conn.commit()
        finally:
            conn.close()

        with self._lock:
            if err_ids and not ok_ids:
                self.status     = "error"
                self.last_error = err_ids[0][1]
            elif ok_ids:
                self.status     = "synced"
                self.last_sync  = datetime.now().strftime("%H:%M:%S")
                self.last_error = None

        if ok_ids:
            self._write_config_field(
                "last_pushed_at",
                datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            )

    def _upload_image_if_needed(self, cfg: dict, table: str, payload: dict) -> dict:
        """
        If payload has a local image path (starts with /media/), upload it to
        Supabase Storage and replace the path with a public cloud URL.
        """
        # Determine which field holds the image path
        img_field = "image_url" if table in ("products", "store_settings") else "avatar_url"
        local_path = payload.get(img_field) or payload.get("logo_url")
        if not local_path:
            return payload

        # Skip if already a remote URL
        if local_path.startswith("http"):
            return payload

        # Resolve local file
        if self._media_root:
            # local_path is like /media/products/abc.jpg
            relative = local_path.lstrip("/").replace("media/", "", 1)
            full_path = Path(self._media_root) / relative
        else:
            return payload

        if not full_path.exists():
            return payload

        try:
            with open(full_path, "rb") as f:
                data = f.read()

            ext      = full_path.suffix.lower()
            filename = f"{cfg['store_id']}/{full_path.name}"
            folder   = "products" if table == "products" else "avatars"
            obj_path = f"{folder}/{filename}"

            url = (cfg["supabase_url"].rstrip("/") +
                   f"/storage/v1/object/tindahan-images/{obj_path}")
            headers = {
                "apikey":        cfg["supabase_key"],
                "Authorization": "Bearer " + cfg["supabase_key"],
                "Content-Type":  "image/jpeg" if ext in (".jpg", ".jpeg") else
                                 "image/png"  if ext == ".png" else
                                 "image/gif"  if ext == ".gif" else
                                 "image/webp",
                "x-upsert":     "true",
            }
            req = urllib.request.Request(url, data=data, headers=headers, method="PUT")
            with urllib.request.urlopen(req, timeout=15):
                pass

            public_url = (cfg["supabase_url"].rstrip("/") +
                          f"/storage/v1/object/public/tindahan-images/{obj_path}")
            # Replace local path with cloud URL in payload
            payload = dict(payload)
            if img_field in payload:
                payload[img_field] = public_url
            if "logo_url" in payload:
                payload["logo_url"] = public_url

        except Exception as exc:
            print(f"[sync] image upload failed ({local_path}): {exc}")

        return payload

    # ══════════════════════════════════════════════════════════════════════════
    # PULL  (cloud → local)
    # ══════════════════════════════════════════════════════════════════════════

    def _pull(self, cfg: dict) -> None:
        if not cfg.get("store_id"):
            return

        last_pulled = cfg.get("last_pulled_at") or "1970-01-01T00:00:00Z"

        try:
            with self._lock:
                self.status = "syncing"

            total_pulled = 0

            # ── 0. Store settings (name, tagline, logo) ───────────────────────
            ss_rows = self._sb_get(cfg, "store_settings", {
                "store_id": f"eq.{cfg['store_id']}",
                "select":   "store_name,tagline,logo_url,updated_at",
                "limit":    "1",
            })
            if ss_rows:
                ss = ss_rows[0]
                conn = self._get_db()
                try:
                    logo_local = self._download_image_if_needed(
                        ss.get("logo_url"), "logos", cfg["store_id"]
                    )
                    conn.execute(
                        "UPDATE store_settings SET store_name=?, tagline=?"
                        + (", logo_url=?" if logo_local else "") +
                        " WHERE id=1",
                        (ss["store_name"], ss.get("tagline", ""), logo_local)
                        if logo_local else
                        (ss["store_name"], ss.get("tagline", ""))
                    )
                    conn.commit()
                    total_pulled += 1
                finally:
                    conn.close()

            # ── 1. Categories ─────────────────────────────────────────────────
            cats = self._sb_get(cfg, "categories", {
                "store_id":   f"eq.{cfg['store_id']}",
                "updated_at": f"gt.{last_pulled}",
                "order":      "updated_at.asc",
                "select":     "local_id,name,deleted,updated_at",
            })
            if cats:
                conn = self._get_db()
                try:
                    for c in cats:
                        lid = c.get("local_id")
                        if lid is None:
                            continue
                        if c.get("deleted"):
                            conn.execute("DELETE FROM categories WHERE id=?", (lid,))
                        else:
                            conn.execute(
                                "INSERT OR IGNORE INTO categories (id, name) VALUES (?, ?)",
                                (lid, c["name"])
                            )
                            conn.execute(
                                "UPDATE categories SET name=? WHERE id=?",
                                (c["name"], lid)
                            )
                    conn.commit()
                    total_pulled += len(cats)
                finally:
                    conn.close()

            # ── 2. Products ───────────────────────────────────────────────────
            prods = self._sb_get(cfg, "products", {
                "store_id":   f"eq.{cfg['store_id']}",
                "updated_at": f"gt.{last_pulled}",
                "order":      "updated_at.asc",
                "select":     "local_id,name,category,price,reorder_level,image_url,deleted,updated_at",
            })
            if prods:
                conn = self._get_db()
                try:
                    for p in prods:
                        lid = p.get("local_id")
                        if lid is None:
                            continue
                        if p.get("deleted"):
                            conn.execute("DELETE FROM products WHERE id=?", (lid,))
                        else:
                            # Download image if cloud has one and local doesn't
                            cloud_img = p.get("image_url") or ""
                            local_img = self._get_local_image_for_product(conn, lid)
                            if cloud_img and (not local_img or local_img.startswith("http")):
                                local_img = self._download_image_if_needed(
                                    cloud_img, "products", cfg["store_id"]
                                ) or local_img
                            # UPSERT: insert with stock=0 if product is new on this machine
                            conn.execute(
                                "INSERT OR IGNORE INTO products "
                                "(id, name, category, price, stock, reorder_level, image) "
                                "VALUES (?, ?, ?, ?, 0, ?, ?)",
                                (lid, p["name"], p["category"],
                                 float(p["price"]), int(p["reorder_level"]), local_img)
                            )
                            # Update all metadata fields (never touches stock)
                            conn.execute(
                                "UPDATE products SET "
                                "name=?, category=?, price=?, reorder_level=?"
                                + (", image=?" if local_img else "") +
                                " WHERE id=?",
                                (p["name"], p["category"],
                                 float(p["price"]), int(p["reorder_level"]),
                                 local_img, lid)
                                if local_img else
                                (p["name"], p["category"],
                                 float(p["price"]), int(p["reorder_level"]), lid)
                            )
                    conn.commit()
                    total_pulled += len(prods)
                finally:
                    conn.close()

            # ── 3. Users / cashiers ───────────────────────────────────────────
            users = self._sb_get(cfg, "users", {
                "store_id":   f"eq.{cfg['store_id']}",
                "updated_at": f"gt.{last_pulled}",
                "order":      "updated_at.asc",
                "select":     "local_id,username,password,full_name,role,active,avatar_url,deleted,updated_at",
            })
            if users:
                conn = self._get_db()
                try:
                    for u in users:
                        lid = u.get("local_id")
                        if lid is None:
                            continue
                        if u.get("role") == "Store Owner":
                            continue   # Never overwrite local owner
                        if u.get("deleted"):
                            conn.execute("DELETE FROM users WHERE id=?", (lid,))
                        else:
                            active = 1 if u.get("active") else 0
                            cloud_av = u.get("avatar_url") or ""
                            local_av = self._get_local_avatar_for_user(conn, lid)
                            if cloud_av and (not local_av or local_av.startswith("http")):
                                local_av = self._download_image_if_needed(
                                    cloud_av, "avatars", cfg["store_id"]
                                ) or local_av
                            conn.execute(
                                "INSERT OR IGNORE INTO users "
                                "(id, username, password, full_name, role, active, avatar) "
                                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                                (lid, u["username"], u["password"],
                                 u["full_name"], u.get("role", "Cashier"), active, local_av)
                            )
                            conn.execute(
                                "UPDATE users SET "
                                "username=?, password=?, full_name=?, role=?, active=?"
                                + (", avatar=?" if local_av else "") +
                                " WHERE id=?",
                                (u["username"], u["password"], u["full_name"],
                                 u.get("role", "Cashier"), active, local_av, lid)
                                if local_av else
                                (u["username"], u["password"], u["full_name"],
                                 u.get("role", "Cashier"), active, lid)
                            )
                    conn.commit()
                    total_pulled += len(users)
                finally:
                    conn.close()

            # ── 4. Sales ──────────────────────────────────────────────────────
            sales_rows = self._sb_get(cfg, "sales", {
                "store_id":   f"eq.{cfg['store_id']}",
                "updated_at": f"gt.{last_pulled}",
                "order":      "updated_at.asc",
                "select":     "local_id,product_name,qty,total,sale_date,cashier,"
                              "sale_time,receipt_no,amount_tendered,change_given,updated_at",
            })
            if sales_rows:
                conn = self._get_db()
                try:
                    for s in sales_rows:
                        lid = s.get("local_id")
                        if lid is None:
                            continue
                        conn.execute(
                            "INSERT OR IGNORE INTO sales "
                            "(id, product_name, qty, total, date, cashier, "
                            " time, receipt_no, amount_tendered, change_given) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            (lid,
                             s.get("product_name", ""),
                             int(s.get("qty") or 0),
                             float(s.get("total") or 0),
                             s.get("sale_date", ""),
                             s.get("cashier", ""),
                             s.get("sale_time") or "",
                             s.get("receipt_no") or "",
                             float(s["amount_tendered"]) if s.get("amount_tendered") is not None else None,
                             float(s["change_given"])    if s.get("change_given")    is not None else None)
                        )
                    conn.commit()
                    total_pulled += len(sales_rows)
                finally:
                    conn.close()

            if total_pulled > 0:
                print(f"☁️   Pulled {total_pulled} item(s): "
                      f"prods={len(prods or [])}, "
                      f"users={len(users or [])}, "
                      f"cats={len(cats or [])}, "
                      f"sales={len(sales_rows or [])}")

            now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            self._write_config_field("last_pulled_at", now_iso)

            with self._lock:
                self.status     = "synced"
                self.last_sync  = datetime.now().strftime("%H:%M:%S")
                self.last_error = None

        except urllib.error.URLError:
            with self._lock:
                self.status = "offline"
        except Exception as exc:
            import traceback; traceback.print_exc()
            with self._lock:
                self.status     = "error"
                self.last_error = str(exc)[:300]

    # ── Image helpers ─────────────────────────────────────────────────────────

    def _download_image_if_needed(self, cloud_url: str, subfolder: str,
                                   store_id: str) -> str | None:
        """Download a remote image URL to local /media/<subfolder>/ and return local path."""
        if not cloud_url or not cloud_url.startswith("http"):
            return None
        if not self._media_root:
            return None
        try:
            dest_dir = Path(self._media_root) / subfolder
            dest_dir.mkdir(parents=True, exist_ok=True)

            # Use last segment of URL path as filename
            filename = cloud_url.split("/")[-1].split("?")[0]
            if not filename:
                return None
            dest = dest_dir / filename
            if not dest.exists():
                req = urllib.request.Request(cloud_url, headers={"User-Agent": "TindahanSync"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    with open(dest, "wb") as f:
                        f.write(resp.read())
            return f"/media/{subfolder}/{filename}"
        except Exception as exc:
            print(f"[sync] image download failed ({cloud_url}): {exc}")
            return None

    def _get_local_image_for_product(self, conn, lid: int) -> str | None:
        row = conn.execute("SELECT image FROM products WHERE id=?", (lid,)).fetchone()
        return row["image"] if row else None

    def _get_local_avatar_for_user(self, conn, lid: int) -> str | None:
        row = conn.execute("SELECT avatar FROM users WHERE id=?", (lid,)).fetchone()
        return row["avatar"] if row else None

    # ══════════════════════════════════════════════════════════════════════════
    # Supabase REST helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _sb_req(self, cfg: dict, method: str, table: str,
                data=None, params: dict | None = None):
        url = cfg["supabase_url"].rstrip("/") + "/rest/v1/" + table
        if params:
            url += "?" + urllib.parse.urlencode(params)
        headers = {
            "apikey":        cfg["supabase_key"],
            "Authorization": "Bearer " + cfg["supabase_key"],
            "Content-Type":  "application/json",
            "Prefer":        "resolution=merge-duplicates,return=representation",
        }
        body = json.dumps(data).encode("utf-8") if data is not None else None
        req  = urllib.request.Request(url, data=body, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as resp:
            rb = resp.read()
            return json.loads(rb) if rb.strip() else None

    def _sb_upsert(self, cfg, table, data):
        self._sb_req(cfg, "POST", table, data)

    def _sb_delete(self, cfg, table, local_id, store_id):
        self._sb_req(cfg, "DELETE", table, params={
            "local_id": f"eq.{local_id}",
            "store_id": f"eq.{store_id}",
        })

    def _sb_get(self, cfg, table, params) -> list:
        result = self._sb_req(cfg, "GET", table, params=params)
        return result if isinstance(result, list) else []

    # ── Store registration ────────────────────────────────────────────────────

    def register_store(self, supabase_url: str, supabase_key: str,
                       store_name: str, tagline: str) -> str:
        cfg  = {"supabase_url": supabase_url, "supabase_key": supabase_key}
        data = {"store_name": store_name, "tagline": tagline}
        result = self._sb_req(cfg, "POST", "stores", data)
        if result and isinstance(result, list) and result[0].get("id"):
            return result[0]["id"]
        rows = self._sb_get(cfg, "stores", {
            "store_name": f"eq.{store_name}",
            "order":      "created_at.desc",
            "limit":      "1",
            "select":     "id",
        })
        if rows:
            return rows[0]["id"]
        raise RuntimeError("Could not register store in Supabase")

    def test_connection(self, supabase_url: str, supabase_key: str) -> bool:
        try:
            cfg = {"supabase_url": supabase_url, "supabase_key": supabase_key}
            self._sb_get(cfg, "stores", {"limit": "1"})
            return True
        except Exception:
            return False

    def fetch_store_snapshot(self, supabase_url: str, supabase_key: str,
                             store_id: str) -> dict:
        """
        Fetch ALL cloud data for a store_id in one shot.
        Used by the Connect flow to populate a fresh install.
        Returns: {store, settings, categories, products, users}
        """
        cfg = {"supabase_url": supabase_url, "supabase_key": supabase_key,
               "store_id": store_id}

        stores = self._sb_get(cfg, "stores", {
            "id":    f"eq.{store_id}",
            "limit": "1",
        })
        if not stores:
            raise ValueError("Store ID not found in Supabase")

        settings = self._sb_get(cfg, "store_settings", {
            "store_id": f"eq.{store_id}",
            "limit":    "1",
        })
        categories = self._sb_get(cfg, "categories", {
            "store_id": f"eq.{store_id}",
            "deleted":  "eq.false",
            "select":   "local_id,name",
        })
        products = self._sb_get(cfg, "products", {
            "store_id": f"eq.{store_id}",
            "deleted":  "eq.false",
            "select":   "local_id,name,category,price,stock,reorder_level,image_url",
        })
        users = self._sb_get(cfg, "users", {
            "store_id": f"eq.{store_id}",
            "select":   "local_id,username,password,full_name,role,active,avatar_url",
        })

        # Paginate sales — may be large
        sales: list = []
        offset = 0
        page_size = 1000
        while True:
            page = self._sb_get(cfg, "sales", {
                "store_id": f"eq.{store_id}",
                "select":   "local_id,product_name,qty,total,sale_date,cashier,"
                            "sale_time,receipt_no,amount_tendered,change_given",
                "order":    "local_id.asc",
                "limit":    str(page_size),
                "offset":   str(offset),
            })
            sales.extend(page)
            if len(page) < page_size:
                break
            offset += page_size

        return {
            "store":      stores[0],
            "settings":   settings[0] if settings else {},
            "categories": categories,
            "products":   products,
            "users":      users,
            "sales":      sales,
        }

    # ── Enqueue ───────────────────────────────────────────────────────────────

    def enqueue(self, table: str, operation: str,
                record_id: str, payload: dict) -> None:
        if not self._db_path:
            return
        try:
            conn = self._get_db()
            now  = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            conn.execute(
                "DELETE FROM sync_queue "
                "WHERE table_name=? AND record_id=? AND operation=?",
                (table, str(record_id), operation)
            )
            conn.execute(
                "INSERT INTO sync_queue "
                "(table_name, operation, record_id, payload, created_at, attempts) "
                "VALUES (?, ?, ?, ?, ?, 0)",
                (table, operation, str(record_id), json.dumps(payload), now)
            )
            conn.commit()
            conn.close()
        except Exception as exc:
            print(f"[sync] enqueue failed: {exc}")

    # ── Status ────────────────────────────────────────────────────────────────

    def status_dict(self) -> dict:
        q_count = 0
        try:
            conn    = self._get_db()
            q_count = conn.execute("SELECT COUNT(*) FROM sync_queue").fetchone()[0]
            conn.close()
        except Exception:
            pass
        with self._lock:
            return {
                "enabled":  self.enabled,
                "status":   self.status,
                "lastSync": self.last_sync,
                "error":    self.last_error,
                "pending":  q_count,
            }

    # ── Internals ─────────────────────────────────────────────────────────────

    def _get_db(self):
        try:
            from sqlcipher3 import dbapi2 as sqlite    # Windows
        except ImportError:
            from pysqlcipher3 import dbapi2 as sqlite  # Linux
        conn = sqlite.connect(self._db_path)
        conn.execute(f"PRAGMA key='{self._db_key}'")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite.Row
        return conn

    def _load_config(self) -> dict | None:
        if not self._db_path:
            return None
        try:
            conn = self._get_db()
            row  = conn.execute("SELECT * FROM cloud_config WHERE id=1").fetchone()
            conn.close()
            return dict(row) if row else None
        except Exception:
            return None

    def _write_config_field(self, field: str, value: str) -> None:
        try:
            conn = self._get_db()
            conn.execute(f"UPDATE cloud_config SET {field}=? WHERE id=1", (value,))
            conn.commit()
            conn.close()
        except Exception:
            pass
