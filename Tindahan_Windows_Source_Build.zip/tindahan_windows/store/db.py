"""
store/db.py — Database helpers (local encrypted DB + sync queue)
"""
import os, sys
from django.conf import settings

_base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _base not in sys.path:
    sys.path.insert(0, _base)

try:
    from sqlcipher3 import dbapi2 as sqlite        # Windows pre-built wheel
except ImportError:
    from pysqlcipher3 import dbapi2 as sqlite      # Linux fallback


def get_db():
    conn = sqlite.connect(settings.TINDAHAN_DB_PATH)
    conn.execute(f"PRAGMA key='{settings.TINDAHAN_DB_KEY}'")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


# ── Row → dict helpers ────────────────────────────────────────────────────────

def p2d(r):
    return {
        "id":           r["id"],
        "name":         r["name"],
        "category":     r["category"],
        "price":        r["price"],
        "stock":        r["stock"],
        "reorderLevel": r["reorder_level"],
        "image":        r["image"] if r["image"] else None,
    }

def u2d(r):
    return {
        "id":       r["id"],
        "username": r["username"],
        "fullName": r["full_name"],
        "role":     r["role"],
        "active":   bool(r["active"]),
        "password": r["password"],
        "avatar":   r["avatar"] if r["avatar"] else None,
    }

def s2d(r):
    return {
        "id":             r["id"],
        "productId":      r["product_id"],
        "productName":    r["product_name"],
        "qty":            r["qty"],
        "total":          r["total"],
        "date":           r["date"],
        "cashier":        r["cashier"],
        "time":           r["time"],
        "receiptNo":      r["receipt_no"],
        "amountTendered": r["amount_tendered"] if r["amount_tendered"] is not None else None,
        "changeGiven":    r["change_given"]    if r["change_given"]    is not None else None,
    }

def c2d(r):
    return {"id": r["id"], "name": r["name"]}

def ss2d(r):
    if not r:
        return {"storeName": "Tindahan Mo", "tagline": "", "logoUrl": None, "setupDone": False}
    return {
        "storeName": r["store_name"],
        "tagline":   r["tagline"] or "",
        "logoUrl":   r["logo_url"] if r["logo_url"] else None,
        "setupDone": bool(r["setup_done"]),
    }


# ── DB initialisation ─────────────────────────────────────────────────────────

def init_db():
    """Create all tables and seed data on first run."""
    conn = get_db()

    # ── users ─────────────────────────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            username  TEXT UNIQUE NOT NULL,
            password  TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role      TEXT NOT NULL DEFAULT 'Cashier',
            active    INTEGER NOT NULL DEFAULT 1,
            avatar    TEXT DEFAULT NULL
        )""")
    try:
        conn.execute("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT NULL")
        conn.commit()
    except Exception:
        pass

    # ── products ──────────────────────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT NOT NULL,
            category      TEXT NOT NULL,
            price         REAL NOT NULL,
            stock         INTEGER NOT NULL DEFAULT 0,
            reorder_level INTEGER NOT NULL DEFAULT 10,
            image         TEXT DEFAULT NULL
        )""")
    try:
        conn.execute("ALTER TABLE products ADD COLUMN image TEXT DEFAULT NULL")
        conn.commit()
    except Exception:
        pass

    # ── categories ────────────────────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )""")

    # No default categories — owner creates their own via the app

    # ── sales ─────────────────────────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id      INTEGER,
            product_name    TEXT NOT NULL,
            qty             INTEGER NOT NULL,
            total           REAL NOT NULL,
            date            TEXT NOT NULL,
            cashier         TEXT NOT NULL,
            cashier_id      INTEGER REFERENCES users(id) ON DELETE CASCADE,
            time            TEXT NOT NULL,
            receipt_no      TEXT NOT NULL,
            amount_tendered REAL DEFAULT NULL,
            change_given    REAL DEFAULT NULL
        )""")
    for col, dflt in [("amount_tendered","NULL"),("change_given","NULL")]:
        try:
            conn.execute(f"ALTER TABLE sales ADD COLUMN {col} REAL DEFAULT {dflt}")
            conn.commit()
        except Exception:
            pass

    # ── store_settings ────────────────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS store_settings (
            id         INTEGER PRIMARY KEY CHECK (id = 1),
            store_name TEXT NOT NULL DEFAULT 'Tindahan Mo',
            tagline    TEXT DEFAULT '',
            logo_url   TEXT DEFAULT NULL,
            setup_done INTEGER NOT NULL DEFAULT 0
        )""")
    conn.execute("""
        INSERT OR IGNORE INTO store_settings (id, store_name, tagline, logo_url, setup_done)
        VALUES (1, 'Tindahan Mo', '', NULL, 0)
    """)

    # ── cloud_config ──────────────────────────────────────────────────────────
    # Stores Supabase credentials + sync state.
    # store_id: UUID assigned by Supabase when this store registers.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cloud_config (
            id              INTEGER PRIMARY KEY CHECK (id = 1),
            supabase_url    TEXT NOT NULL DEFAULT '',
            supabase_key    TEXT NOT NULL DEFAULT '',
            store_id        TEXT DEFAULT NULL,
            enabled         INTEGER NOT NULL DEFAULT 0,
            last_pushed_at  TEXT DEFAULT NULL,
            last_pulled_at  TEXT DEFAULT NULL
        )""")
    conn.execute("""
        INSERT OR IGNORE INTO cloud_config
            (id, supabase_url, supabase_key, store_id, enabled)
        VALUES (1, '', '', NULL, 0)
    """)

    # ── sync_queue ────────────────────────────────────────────────────────────
    # Offline-first queue: every local write is enqueued here.
    # The background SyncEngine drains this to Supabase when online.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sync_queue (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name  TEXT NOT NULL,
            operation   TEXT NOT NULL,
            record_id   TEXT NOT NULL,
            payload     TEXT NOT NULL,
            created_at  TEXT NOT NULL,
            attempts    INTEGER NOT NULL DEFAULT 0,
            last_error  TEXT DEFAULT NULL
        )""")

    # ── seed owner account only ───────────────────────────────────────────────
    # Placeholder row — wizard will update with real name/username/password.
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        conn.execute(
            "INSERT INTO users (username,password,full_name,role,active) VALUES (?,?,?,?,?)",
            ("__pending__", "__pending__", "Store Owner", "Store Owner", 1),
        )

    # No default products or sales — owner adds their own inventory

    conn.commit()
    conn.close()
    print(f"✅  Database ready → {settings.TINDAHAN_DB_PATH}")
