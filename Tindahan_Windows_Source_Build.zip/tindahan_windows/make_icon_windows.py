"""
make_icon_windows.py
Generates tindahan.ico (multi-size Windows icon) and tindahan.png.
Run before building:  python make_icon_windows.py

Requires Pillow:  pip install Pillow
"""
import sys
from pathlib import Path

def make_icon(out_dir: Path = None):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("Pillow not found — skipping icon generation.")
        print("Install it with:  pip install Pillow")
        return

    if out_dir is None:
        out_dir = Path(__file__).resolve().parent

    sizes = [16, 24, 32, 48, 64, 128, 256]
    frames = []

    for sz in sizes:
        img  = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Background circle
        pad = max(1, sz // 16)
        draw.ellipse([pad, pad, sz - pad, sz - pad],
                     fill=(26, 26, 46, 255))

        # Inner circle accent
        p2 = max(2, sz // 8)
        draw.ellipse([p2, p2, sz - p2, sz - p2],
                     outline=(245, 197, 24, 200), width=max(1, sz // 32))

        # Store emoji / letter
        if sz >= 32:
            fsize = max(10, int(sz * 0.46))
            try:
                font = ImageFont.truetype("arial.ttf", fsize)
            except Exception:
                font = ImageFont.load_default()
            text = "🏪" if sz >= 64 else "T"
            try:
                bbox = draw.textbbox((0, 0), text, font=font)
                tw   = bbox[2] - bbox[0]
                th   = bbox[3] - bbox[1]
            except Exception:
                tw = th = fsize
            tx = (sz - tw) // 2 - (bbox[0] if sz >= 64 else 0)
            ty = (sz - th) // 2 - (bbox[1] if sz >= 64 else 0)
            draw.text((tx, ty), text, font=font, fill=(245, 197, 24, 255))

        frames.append(img)

    # Save .ico (multi-size)
    ico_path = out_dir / "tindahan.ico"
    frames[0].save(
        ico_path,
        format="ICO",
        sizes=[(s, s) for s in sizes],
        append_images=frames[1:],
    )
    print(f"✅  tindahan.ico  → {ico_path}")

    # Save 256×256 PNG too
    png_path = out_dir / "tindahan.png"
    frames[-1].save(png_path, "PNG")
    print(f"✅  tindahan.png  → {png_path}")


if __name__ == "__main__":
    make_icon(Path(sys.argv[1]) if len(sys.argv) > 1 else None)
