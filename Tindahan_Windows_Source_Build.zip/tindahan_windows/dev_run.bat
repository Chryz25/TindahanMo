@echo off
REM ============================================================
REM  Tindahan Mo — Quick Dev Run (no build needed)
REM  Double-click to start the app directly for testing.
REM  Requires build.bat to have been run at least once
REM  (so the .venv and packages are installed).
REM ============================================================
setlocal
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

if not exist ".venv\Scripts\activate.bat" (
    echo Virtual environment not found.
    echo Please run build.bat first to set everything up.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat
echo Starting Tindahan Mo in dev mode...
python launcher.py
