"""
Tindahan Mo — Django Settings (Windows)
"""
import os
from pathlib import Path

# Launcher sets TINDAHAN_BASE_DIR = %APPDATA%\TindahanMo
# Dev mode falls back to the project folder
BASE_DIR = Path(
    os.environ.get("TINDAHAN_BASE_DIR",
                   Path(__file__).resolve().parent.parent)
)

SECRET_KEY    = os.environ.get("SECRET_KEY", "tindahan-mo-windows-2026!")
DEBUG         = os.environ.get("DEBUG", "True") == "True"
ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "store",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
]

ROOT_URLCONF     = "tindahan_project.urls"
WSGI_APPLICATION = "tindahan_project.wsgi.application"

TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [],
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
    ]},
}]

# Django uses this plain SQLite only for sessions
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME":   BASE_DIR / "django_sessions.db",
    }
}

SESSION_ENGINE     = "django.contrib.sessions.backends.db"
SESSION_COOKIE_AGE = 60 * 60 * 8   # 8 hours

LANGUAGE_CODE = "en-us"
TIME_ZONE     = "Asia/Manila"
USE_I18N      = True
USE_TZ        = True

STATIC_URL         = "/static/"
MEDIA_URL          = "/media/"
MEDIA_ROOT         = BASE_DIR / "media"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
APPEND_SLASH       = False

# Encrypted business database (sqlcipher3 on Windows)
TINDAHAN_DB_PATH = os.environ.get("DB_PATH", str(BASE_DIR / "tindahan_secure.db"))
TINDAHAN_DB_KEY  = os.environ.get("DB_KEY",  "TindahanMo@Cebu2026#Secure!")
