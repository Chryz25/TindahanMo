#!/usr/bin/env python3
"""
make_icon.py — Generate a 256x256 RGBA PNG for Tindahan Mo.
Usage: python3 make_icon.py /path/to/output.png
No external dependencies — pure stdlib only.
"""
import struct, zlib, sys

def pack_chunk(tag: bytes, data: bytes) -> bytes:
    crc = zlib.crc32(tag + data) & 0xFFFFFFFF
    return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', crc)

def make_png(out_path: str) -> None:
    W = H = 256

    # Colours (R,G,B,A)
    BG    = (15,  23,  42,  255)  # dark navy  #0f172a
    RING  = (26,  35,  60,  255)  # mid navy
    GOLD  = (245,197,  24,  255)  # gold       #f5c518
    DARK  = (10,  15,  28,  255)  # window dark

    px = [BG] * (W * H)

    def rect(x0, y0, x1, y1, col):
        for y in range(max(0, y0), min(H, y1)):
            for x in range(max(0, x0), min(W, x1)):
                px[y * W + x] = col

    def circle(cx, cy, r, col):
        for y in range(max(0, cy - r), min(H, cy + r + 1)):
            for x in range(max(0, cx - r), min(W, cx + r + 1)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    px[y * W + x] = col

    circle(128, 128, 118, RING)          # background disc
    rect(70, 120, 186, 195, GOLD)        # building body
    for i in range(50):                  # roof triangle
        w2 = int(58 * (50 - i) / 50)
        rect(128 - w2, 70 + i, 128 + w2, 71 + i, GOLD)
    rect(150, 90, 168, 122, GOLD)        # chimney
    rect(85,  132, 108, 153, DARK)       # left window
    rect(148, 132, 171, 153, DARK)       # right window
    rect(112, 158, 144, 195, DARK)       # door

    # Encode scanlines (PNG filter 0 = None)
    raw = bytearray()
    for y in range(H):
        raw += b'\x00'
        for x in range(W):
            raw += bytes(px[y * W + x])

    ihdr = struct.pack('>IIBBBBB', W, H, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)

    png = (
        b'\x89PNG\r\n\x1a\n'
        + pack_chunk(b'IHDR', ihdr)
        + pack_chunk(b'IDAT', idat)
        + pack_chunk(b'IEND', b'')
    )

    with open(out_path, 'wb') as f:
        f.write(png)
    print(f"    Icon written: {out_path}  ({len(png):,} bytes, 256×256 RGBA)")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} OUTPUT.png", file=sys.stderr)
        sys.exit(1)
    make_png(sys.argv[1])
