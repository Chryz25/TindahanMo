@echo off
:: ============================================================
::  Tindahan Mo - Quick Dev Run (no build needed)
::  Runs the app directly for testing without compiling.
::  Requires build.bat to have run at least once.
:: ============================================================
setlocal
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found.
    echo Please run build.bat first to set everything up.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat
echo Starting Tindahan Mo in dev mode...
echo Close this window to stop the app.
echo.
python launcher_windows.py
