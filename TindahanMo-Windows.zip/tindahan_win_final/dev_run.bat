@echo off
:: ============================================================
::  Tindahan Mo — Quick Dev Run (no build needed)
::  Run this to start the app directly for testing.
::  Requires build.bat to have been run at least once
::  (so .venv and packages are installed).
:: ============================================================
setlocal
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

if not exist ".venv\Scripts\activate.bat" (
    echo Virtual environment not found.
    echo Please run build.bat first to set everything up.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat
echo Starting Tindahan Mo in dev mode...
echo (Close this window to stop the app)
echo.
python launcher_windows.py
