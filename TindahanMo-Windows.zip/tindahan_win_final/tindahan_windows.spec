# tindahan_windows.spec — PyInstaller spec for Windows 10/11
# Run: pyinstaller tindahan_windows.spec
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

PROJECT = Path(SPECPATH)
datas, binaries, hiddenimports = [], [], []

for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

for folder in ("store", "tindahan_project", "pysqlcipher3"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

if (PROJECT / "store" / "favicon.ico").is_file():
    datas.append((str(PROJECT / "store" / "favicon.ico"), "store"))

if (PROJECT / "manage.py").is_file():
    datas.append((str(PROJECT / "manage.py"), "."))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

_icon_png = PROJECT / "tindahan_icon.png"
_icon_ico = PROJECT / "tindahan_icon.ico"

if not _icon_png.is_file() or not _icon_ico.is_file():
    import subprocess as _sp, sys as _sys
    _sp.run([_sys.executable, str(PROJECT / "make_icon.py"), str(_icon_png), "256"], check=False)
    _sp.run([_sys.executable, str(PROJECT / "make_icon.py"), str(_icon_ico), "256"], check=False)

if _icon_png.is_file():
    datas.append((str(_icon_png), "."))

a = Analysis(
    [str(PROJECT / "launcher_windows.py")],
    pathex        = [str(PROJECT)],
    binaries      = binaries,
    datas         = datas,
    hiddenimports = list(set(hiddenimports)) + [
        "django.template.defaulttags","django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security","django.middleware.common",
        "store","store.views","store.db","store.sync","store.apps","store.urls","store.config",
        "tindahan_project.settings","tindahan_project.urls","tindahan_project.wsgi",
        "pysqlcipher3","pysqlcipher3.dbapi2",
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes","cryptography.fernet",
        "webview.platforms.qt",
        "wsgiref.simple_server","wsgiref.handlers",
        "urllib.request","urllib.parse","email.mime.text","importlib.metadata",
        "winreg","ctypes","ctypes.wintypes",
    ],
    excludes   = ["tkinter","PyQt5","PyQt6","PySide2","wx","matplotlib","gi","gtk"],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

_exe_icon = str(_icon_ico) if _icon_ico.is_file() else (str(_icon_png) if _icon_png.is_file() else None)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries = True,
    name             = "TindahanMo",
    debug            = False,
    strip            = False,
    upx              = True,
    console          = False,
    icon             = _exe_icon,
    version_file     = None,
    uac_admin        = False,
)

coll = COLLECT(
    exe, a.binaries, a.zipfiles, a.datas, [],
    strip = False,
    upx   = True,
    name  = "TindahanMo",
)
