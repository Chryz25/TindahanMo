#!/usr/bin/env python3
"""
make_icon.py — Tindahan Mo icon generator (cross-platform)
===========================================================
Usage:
    python make_icon.py OUTPUT.png [SIZE]      → PNG at SIZE x SIZE
    python make_icon.py OUTPUT.ico [SIZE]      → Windows ICO (multi-size)
    python make_icon.py OUTPUT.png             → 256x256 PNG (default)

Custom logo (highest priority):
    Drop logo.png / logo.jpg / logo.jpeg / icon.png next to this script.
    Pillow will resize it to every requested size.
    build.bat installs Pillow automatically.

No logo file found → built-in store illustration drawn with stdlib only.
"""
import struct, zlib, sys, os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# ── 1. Find custom logo ───────────────────────────────────────────────────────
def _find_logo():
    for name in ("logo.png", "logo.jpg", "logo.jpeg", "icon.png"):
        p = os.path.join(SCRIPT_DIR, name)
        if os.path.isfile(p):
            return p
    return None


# ── 2. Pillow resize (PNG or ICO) ─────────────────────────────────────────────
def _pillow_png(src, dst, size):
    try:
        from PIL import Image
        img = Image.open(src).convert("RGBA")
        img = img.resize((size, size), Image.LANCZOS)
        img.save(dst, "PNG", optimize=True)
        print(f"    PNG from {os.path.basename(src)} -> {dst}  ({size}x{size})")
        return True
    except ImportError:
        print("    Pillow not installed — using built-in icon")
        return False
    except Exception as e:
        print(f"    Logo resize failed ({e}) — using built-in icon")
        return False


def _pillow_ico(src, dst):
    """Create a proper multi-size Windows ICO from a source image."""
    try:
        from PIL import Image
        img = Image.open(src).convert("RGBA")
        sizes = [(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)]
        frames = [img.resize(s, Image.LANCZOS) for s in sizes]
        frames[0].save(
            dst, format="ICO",
            sizes=sizes,
            append_images=frames[1:],
        )
        print(f"    ICO from {os.path.basename(src)} -> {dst}  ({len(sizes)} sizes)")
        return True
    except ImportError:
        print("    Pillow not installed — generating fallback ICO")
        return False
    except Exception as e:
        print(f"    ICO generation failed ({e}) — generating fallback ICO")
        return False


# ── 3. Built-in PNG icon (stdlib only) ───────────────────────────────────────
def _pack(tag, data):
    crc = zlib.crc32(tag + data) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)


def _draw_builtin(W):
    """Draw the Tindahan Mo sari-sari store icon at W x W. Returns flat RGBA list."""
    H  = W
    sc = lambda v: int(round(v * W / 256))

    TRANSP=(0,0,0,0); DISC=(26,35,60,255); WALL=(245,245,230,255)
    ROOF=(180,75,15,255); GOLD=(245,197,24,255); GDARK=(200,155,10,255)
    WIN=(26,79,168,220); WFR=(200,190,170,255); DOOR=(139,90,40,255)
    STR1=(200,70,10,255); STR2=(245,245,230,255)

    px = [TRANSP]*(W*H)

    def rect(x0,y0,x1,y1,c):
        for y in range(max(0,sc(y0)),min(H,sc(y1))):
            for x in range(max(0,sc(x0)),min(W,sc(x1))):
                px[y*W+x]=c

    def circle(cx,cy,r,c,hole=0):
        cs,ys,rs,hs=sc(cx),sc(cy),sc(r),sc(hole)
        for y in range(max(0,ys-rs-1),min(H,ys+rs+2)):
            for x in range(max(0,cs-rs-1),min(W,cs+rs+2)):
                d=(x-cs)**2+(y-ys)**2
                if d<=rs*rs and (not hole or d>hs*hs): px[y*W+x]=c

    def tri(tx,ty,by,hw,c):
        for y in range(sc(ty),sc(by)+1):
            t2=(y-sc(ty))/max(1,sc(by)-sc(ty))
            w=int(hw*W/256*t2); cx=sc(tx)
            for x in range(cx-w,cx+w+1):
                if 0<=x<W and 0<=y<H: px[y*W+x]=c

    circle(128,128,122,DISC)
    rect(65,122,193,196,WALL)
    tri(128,58,126,72,ROOF)
    rect(57,120,201,130,ROOF)
    for dy in range(sc(130),sc(140)):
        col=STR1 if ((dy-sc(130))//max(1,sc(2)))%2==0 else STR2
        for x in range(sc(60),sc(198)):
            if 0<=x<W and 0<=dy<H: px[dy*W+x]=col
    rect(74,140,184,155,GOLD)
    rect(76,142,182,148,GDARK)
    for wx in (82,150):
        rect(wx,160,wx+25,184,WFR); rect(wx+2,162,wx+23,182,WIN)
        rect(wx+13,161,wx+14,183,WFR); rect(wx+1,171,wx+24,173,WFR)
    rect(111,163,147,196,DOOR)
    rect(114,165,144,182,(160,110,60,140))
    rect(114,184,144,195,(160,110,60,110))
    circle(143,179,2,GOLD)
    rect(156,78,166,120,(210,200,185,255))
    circle(128,128,122,(60,80,120,90),hole=119)
    return px


def _save_png_raw(px, W, dst):
    raw = bytearray()
    for y in range(W):
        raw += b"\x00"
        for x in range(W): raw += bytes(px[y*W+x])
    ihdr = struct.pack(">IIBBBBB", W, W, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)
    png  = (b"\x89PNG\r\n\x1a\n"
            + _pack(b"IHDR", ihdr)
            + _pack(b"IDAT", idat)
            + _pack(b"IEND", b""))
    with open(dst, "wb") as f: f.write(png)
    print(f"    Built-in PNG -> {dst}  ({len(png):,} bytes, {W}x{W})")
    return png


def _save_builtin_png(dst, size=256):
    _save_png_raw(_draw_builtin(size), size, dst)


def _save_builtin_ico(dst):
    """
    Build a minimal multi-size Windows ICO from the built-in icon.
    Sizes: 16, 32, 48, 64, 128, 256
    """
    import io
    sizes = [16, 32, 48, 64, 128, 256]
    png_blobs = []
    for s in sizes:
        px  = _draw_builtin(s)
        raw = bytearray()
        for y in range(s):
            raw += b"\x00"
            for x in range(s): raw += bytes(px[y*s+x])
        ihdr = struct.pack(">IIBBBBB", s, s, 8, 6, 0, 0, 0)
        idat = zlib.compress(bytes(raw), 9)
        blob = (b"\x89PNG\r\n\x1a\n"
                + _pack(b"IHDR", ihdr)
                + _pack(b"IDAT", idat)
                + _pack(b"IEND", b""))
        png_blobs.append(blob)

    n = len(sizes)
    header_size = 6 + n * 16
    offsets = []
    off = header_size
    for b in png_blobs:
        offsets.append(off)
        off += len(b)

    ico = bytearray()
    ico += struct.pack("<HHH", 0, 1, n)   # ICONDIR
    for i, (s, blob) in enumerate(zip(sizes, png_blobs)):
        w = 0 if s == 256 else s          # ICO uses 0 to mean 256
        ico += struct.pack("<BBBBHHII",
                           w, w,          # width, height
                           0, 0,          # color count, reserved
                           1, 32,         # planes, bit count
                           len(blob),
                           offsets[i])
    for blob in png_blobs:
        ico += blob

    with open(dst, "wb") as f: f.write(bytes(ico))
    print(f"    Built-in ICO -> {dst}  ({len(ico):,} bytes, {n} sizes)")


# ── 4. Public entry points ────────────────────────────────────────────────────
def make_png(dst, size=256):
    logo = _find_logo()
    if logo and _pillow_png(logo, dst, size):
        return
    _save_builtin_png(dst, size)


def make_ico(dst):
    logo = _find_logo()
    if logo and _pillow_ico(logo, dst):
        return
    _save_builtin_ico(dst)


def make_icon(dst, size=256):
    """Auto-detect output format from extension."""
    ext = os.path.splitext(dst)[1].lower()
    if ext == ".ico":
        make_ico(dst)
    else:
        make_png(dst, size)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} OUTPUT.png|OUTPUT.ico [SIZE]", file=sys.stderr)
        sys.exit(1)
    make_icon(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 256)
