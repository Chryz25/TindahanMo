@echo off
setlocal EnableDelayedExpansion

:: ============================================================
::  Tindahan Mo — Inno Setup Installer Builder
::  Run AFTER build.bat has succeeded.
::  Requires: Inno Setup 6  (https://jrsoftware.org/isinfo.php)
::  Output: dist\TindahanMo-Setup.exe
:: ============================================================

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "DIST_DIR=%SCRIPT_DIR%\dist"
set "APP_FOLDER=%DIST_DIR%\TindahanMo"
set "ISS_FILE=%SCRIPT_DIR%\installer.iss"
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"

echo.
echo   ╔══════════════════════════════════════════════════════════╗
echo   ║  Tindahan Mo — Building Windows Installer (.exe)         ║
echo   ╚══════════════════════════════════════════════════════════╝
echo.

if not exist "%APP_FOLDER%\TindahanMo.exe" (
    echo ERROR: dist\TindahanMo\TindahanMo.exe not found.
    echo Run build.bat first.
    pause
    exit /b 1
)

:: Check for Inno Setup
if not exist "%ISCC%" (
    :: Try default 64-bit path too
    set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
)
if not exist "%ISCC%" (
    echo Inno Setup 6 not found. Download from:
    echo   https://jrsoftware.org/isdl.php
    echo.
    echo Alternatively, just ZIP the dist\TindahanMo\ folder and share it.
    pause
    exit /b 1
)

:: Generate installer.iss
python "%SCRIPT_DIR%\make_installer_iss.py" "%ISS_FILE%"
if errorlevel 1 (
    echo ERROR: Failed to generate installer.iss
    pause
    exit /b 1
)

:: Build installer
echo Building installer...
"%ISCC%" "%ISS_FILE%"
if errorlevel 1 (
    echo ERROR: Inno Setup build failed
    pause
    exit /b 1
)

if exist "%DIST_DIR%\TindahanMo-Setup.exe" (
    echo.
    echo   ╔══════════════════════════════════════════════════════════╗
    echo   ║  Installer ready: dist\TindahanMo-Setup.exe             ║
    echo   ╚══════════════════════════════════════════════════════════╝
    echo.
    set /p OPEN="Open dist folder? [Y/n]: "
    if /i not "!OPEN!"=="n" explorer "%DIST_DIR%"
)
pause
