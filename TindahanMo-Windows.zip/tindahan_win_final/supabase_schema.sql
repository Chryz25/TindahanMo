-- ============================================================
-- Tindahan Mo — Supabase Schema  (v4 — complete, re-runnable)
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New query)
-- Safe to re-run: all statements use IF NOT EXISTS / OR REPLACE
-- ============================================================

create extension if not exists "pgcrypto";

-- ── stores ───────────────────────────────────────────────────
create table if not exists stores (
    id          uuid primary key default gen_random_uuid(),
    store_name  text not null,
    tagline     text default '',
    logo_url    text default null,
    created_at  timestamptz default now(),
    updated_at  timestamptz default now()
);

-- ── store_settings ────────────────────────────────────────────
create table if not exists store_settings (
    id          uuid primary key default gen_random_uuid(),
    store_id    uuid references stores(id) on delete cascade,
    store_name  text not null default 'Tindahan Mo',
    tagline     text default '',
    logo_url    text default null,
    updated_at  timestamptz default now(),
    unique(store_id)
);

-- ── categories ───────────────────────────────────────────────
create table if not exists categories (
    id         uuid primary key default gen_random_uuid(),
    store_id   uuid references stores(id) on delete cascade,
    local_id   integer not null,
    name       text not null,
    deleted    boolean not null default false,
    updated_at timestamptz default now(),
    unique(store_id, local_id)
);

-- ── products ─────────────────────────────────────────────────
create table if not exists products (
    id            uuid primary key default gen_random_uuid(),
    store_id      uuid references stores(id) on delete cascade,
    local_id      integer not null,
    name          text not null,
    category      text not null default '',
    price         numeric(10,2) not null default 0,
    stock         integer not null default 0,
    reorder_level integer not null default 10,
    image_url     text default null,
    deleted       boolean not null default false,
    created_at    timestamptz default now(),
    updated_at    timestamptz default now(),
    unique(store_id, local_id)
);

-- ── users (cashiers + owner) ──────────────────────────────────
create table if not exists users (
    id         uuid primary key default gen_random_uuid(),
    store_id   uuid references stores(id) on delete cascade,
    local_id   integer not null,
    username   text not null,
    password   text not null,
    full_name  text not null,
    role       text not null default 'Cashier',
    active     boolean not null default true,
    avatar_url text default null,
    deleted    boolean not null default false,
    updated_at timestamptz default now(),
    unique(store_id, local_id)
);

-- ── sales ─────────────────────────────────────────────────────
create table if not exists sales (
    id              uuid primary key default gen_random_uuid(),
    store_id        uuid references stores(id) on delete cascade,
    local_id        integer not null,          -- local SQLite autoincrement id
    product_name    text not null,
    qty             integer not null,
    total           numeric(10,2) not null,
    sale_date       date not null,
    cashier         text not null default '',
    sale_time       text default '',
    receipt_no      text default '',
    amount_tendered numeric(10,2) default null,
    change_given    numeric(10,2) default null,
    created_at      timestamptz default now(),
    updated_at      timestamptz default now(),
    unique(store_id, local_id)                 -- enables upsert by store+local_id
);

-- ── Indexes ───────────────────────────────────────────────────
create index if not exists idx_categories_store   on categories(store_id);
create index if not exists idx_categories_updated on categories(updated_at);
create index if not exists idx_products_store     on products(store_id);
create index if not exists idx_products_updated   on products(updated_at);
create index if not exists idx_users_store        on users(store_id);
create index if not exists idx_users_updated      on users(updated_at);
create index if not exists idx_sales_store        on sales(store_id);
create index if not exists idx_sales_date         on sales(sale_date);
create index if not exists idx_sales_updated      on sales(updated_at);
create index if not exists idx_sales_receipt      on sales(receipt_no);

-- ── Row Level Security ────────────────────────────────────────
alter table stores         enable row level security;
alter table store_settings enable row level security;
alter table categories     enable row level security;
alter table products       enable row level security;
alter table users          enable row level security;
alter table sales          enable row level security;

do $$ begin create policy "svc_stores"    on stores         for all using (true); exception when duplicate_object then null; end $$;
do $$ begin create policy "svc_settings"  on store_settings for all using (true); exception when duplicate_object then null; end $$;
do $$ begin create policy "svc_cats"      on categories     for all using (true); exception when duplicate_object then null; end $$;
do $$ begin create policy "svc_products"  on products       for all using (true); exception when duplicate_object then null; end $$;
do $$ begin create policy "svc_users"     on users          for all using (true); exception when duplicate_object then null; end $$;
do $$ begin create policy "svc_sales"     on sales          for all using (true); exception when duplicate_object then null; end $$;

-- ── Auto updated_at triggers ──────────────────────────────────
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

do $$ begin create trigger trg_categories_updated before update on categories for each row execute function update_updated_at(); exception when duplicate_object then null; end $$;
do $$ begin create trigger trg_products_updated   before update on products   for each row execute function update_updated_at(); exception when duplicate_object then null; end $$;
do $$ begin create trigger trg_users_updated      before update on users      for each row execute function update_updated_at(); exception when duplicate_object then null; end $$;
do $$ begin create trigger trg_stores_updated     before update on stores     for each row execute function update_updated_at(); exception when duplicate_object then null; end $$;
do $$ begin create trigger trg_sales_updated      before update on sales      for each row execute function update_updated_at(); exception when duplicate_object then null; end $$;

-- ── Storage bucket for images ─────────────────────────────────
insert into storage.buckets (id, name, public)
values ('tindahan-images', 'tindahan-images', true)
on conflict (id) do nothing;

do $$ begin
  create policy "public_read_images"
    on storage.objects for select using (bucket_id = 'tindahan-images');
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "service_role_write_images"
    on storage.objects for all using (bucket_id = 'tindahan-images');
exception when duplicate_object then null; end $$;

-- ============================================================
-- Done! The unique(store_id, local_id) constraints on all tables
-- enable proper upsert from any device without duplicates.
-- ============================================================
