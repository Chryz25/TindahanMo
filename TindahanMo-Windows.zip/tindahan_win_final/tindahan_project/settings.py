"""
Tindahan Mo - Django Settings (Windows 10/11)
Data lives in %APPDATA%/TindahanMo/ (e.g. C:/Users/You/AppData/Roaming/TindahanMo)
"""
import os
from pathlib import Path

# launcher_windows.py sets TINDAHAN_BASE_DIR to %APPDATA%/TindahanMo
# Fall back to the project root when running directly (dev mode)
BASE_DIR = Path(
    os.environ.get("TINDAHAN_BASE_DIR",
                   Path(__file__).resolve().parent.parent)
)

# ── Security ────────────────────────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY", "tindahan-mo-django-2026!windows")
DEBUG      = os.environ.get("DEBUG", "True") == "True"
ALLOWED_HOSTS = ["*"]

# ── Applications ─────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "store",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
]

ROOT_URLCONF = "tindahan_project.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
            ],
        },
    },
]

WSGI_APPLICATION = "tindahan_project.wsgi.application"

# ── Database (sessions only) ─────────────────────────────────────────────────
# Django uses this lightweight SQLite only for session storage.
# ALL business data lives in tindahan_secure.db via our pysqlcipher3 shim.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "django_sessions.db",
    }
}

# ── Sessions ──────────────────────────────────────────────────────────────────
SESSION_ENGINE     = "django.contrib.sessions.backends.db"
SESSION_COOKIE_AGE = 60 * 60 * 8   # 8 hours

# ── Internationalisation ──────────────────────────────────────────────────────
LANGUAGE_CODE = "en-us"
TIME_ZONE     = "Asia/Manila"
USE_I18N      = True
USE_TZ        = True

# ── Static files ──────────────────────────────────────────────────────────────
STATIC_URL         = "/static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
APPEND_SLASH       = False

# ── Media files (product images, avatars, logos) ─────────────────────────────
MEDIA_URL  = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# ── Encrypted business DB config ─────────────────────────────────────────────
# DB file lands in %APPDATA%/TindahanMo/tindahan_secure.db
TINDAHAN_DB_PATH = os.environ.get("DB_PATH",  str(BASE_DIR / "tindahan_secure.db"))
TINDAHAN_DB_KEY  = os.environ.get("DB_KEY",   "TindahanMo@Cebu2026#Secure!")

# ── Windows: silence Django's "connection was reset" noise ───────────────────
import logging
logging.getLogger("django.request").setLevel(logging.CRITICAL)
