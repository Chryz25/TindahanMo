# Tindahan Mo — Cloud Sync Setup Guide

## Overview

```
Store 1 PC ──┐
Store 2 PC ──┼──► Supabase (PostgreSQL cloud DB) ◄── Owner Dashboard
Store 3 PC ──┘
```

Each store runs the app locally (works offline). Every 15 seconds, changes
upload to Supabase. Every 30 seconds, updates from the owner (prices,
promotions) pull down to all stores.

---

## Step 1 — Create a Free Supabase Account

1. Go to https://supabase.com → Sign Up (free)
2. Create a new project (choose a region close to you, e.g. Singapore)
3. Wait ~2 minutes for the project to initialize

---

## Step 2 — Run the Database Schema

1. In your Supabase dashboard: **SQL Editor → New Query**
2. Open `supabase_schema.sql` (included in this package)
3. Copy-paste the entire contents → click **Run**
4. You should see: `stores`, `products`, `sales`, `store_settings` tables created

---

## Step 3 — Get Your API Keys

In your Supabase dashboard:
- **Settings → API**
- Copy:
  - **Project URL** (looks like `https://abcdefgh.supabase.co`)
  - **service_role secret** key (starts with `eyJhbGci…`)

> ⚠️ Use the **service_role** key, NOT the anon key.
> Keep it secret — it has full database access.

---

## Step 4 — Configure Each Store

On each store's computer:

1. Launch `Tindahan-Mo-x86_64.AppImage`
2. Log in as **owner**
3. Go to **Cloud Sync** (in the left sidebar)
4. Enter:
   - Project URL
   - service_role key
   - ✅ Enable automatic background sync
5. Click **Save & Test Connection**
6. Click **Register This Store**
7. The store gets a unique ID (UUID) — this separates each store's data

---

## How Sync Works

### Local → Cloud (Push, every 15 seconds)
| Event | What syncs |
|-------|-----------|
| Sale completed | Receipt, items, cashier, amount |
| Product added | Name, price, category, stock |
| Product updated | All fields except stock (local stock stays) |
| Product deleted | Marked as deleted in cloud |

### Cloud → Local (Pull, every 30 seconds)
| Cloud change | Effect on stores |
|-------------|-----------------|
| Owner updates price | All stores get new price within 30 seconds |
| Owner changes product name | All stores updated automatically |
| New product added by owner | Appears in all stores |
| Product deleted in cloud | Removed from all stores |

> **Stock is never overwritten by a pull.**
> Each store manages its own stock levels.

---

## Offline Mode

The app works completely offline.

When you make a sale offline:
- Local DB updates immediately (no data loss)
- Sale is added to the **sync queue** (visible in Cloud Sync page)
- When internet returns, the queue drains automatically

---

## Multi-Store Owner Dashboard

To see all stores' sales in one place, use the Supabase dashboard:

**Table Editor → sales** — filter by `store_id` to see each store's data

Or run SQL queries:
```sql
-- Total sales today across all stores
SELECT store_id, SUM(total) as revenue, COUNT(*) as transactions
FROM sales
WHERE sale_date = CURRENT_DATE
GROUP BY store_id;

-- Which products are selling best this week
SELECT product_name, SUM(qty) as units_sold, SUM(total) as revenue
FROM sales
WHERE sale_date >= CURRENT_DATE - 7
GROUP BY product_name
ORDER BY revenue DESC;
```

---

## Reset Sync

To clear all cloud data and re-register:
1. In Supabase SQL Editor: `DELETE FROM stores; DELETE FROM products; DELETE FROM sales;`
2. In the app: Cloud Sync → Register This Store

To clear local sync queue only:
- Delete `~/.local/share/tindahan/tindahan_secure.db`
- Relaunch (Welcome wizard appears, re-setup the store)

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Cannot connect to Supabase" | Check URL format: `https://xxx.supabase.co` (no trailing slash) |
| Status stays "Offline" | Check internet. App works offline — will retry automatically |
| "Registration failed" | Make sure you ran `supabase_schema.sql` first |
| Sync status shows "Error" | Check Cloud Sync page for the exact error message |
| Old data showing after price update | Wait 30 seconds for pull cycle, or click Sync Now |
