"""
store/views.py — Django views (with hybrid sync triggers)
"""
import json, os, uuid
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from .db import get_db, p2d, u2d, s2d, c2d, ss2d
from .config import SUPABASE_URL, SUPABASE_KEY

# ── Import sync engine (lazy, never crashes if sync.py has issues) ────────────
def _sync():
    try:
        from .sync import get_engine
        return get_engine()
    except Exception:
        return None


def _body(request):
    try:
        return json.loads(request.body)
    except Exception:
        return {}

def _guard(request, owner=False):
    # ── Setup endpoints are always public (pre-auth first-launch) ──────────────
    # These paths must never require a session — they ARE the mechanism for
    # creating or connecting a store before any user exists.
    SETUP_PATHS = ("/api/setup/connect", "/api/setup/set-owner")
    if request.path in SETUP_PATHS:
        return None
    # ── Also bypass everything if setup hasn't been completed yet ─────────────
    try:
        conn = get_db()
        row  = conn.execute("SELECT setup_done FROM store_settings WHERE id=1").fetchone()
        conn.close()
        if not row or not row["setup_done"]:
            return None
    except Exception:
        pass
    # ── Normal session check ──────────────────────────────────────────────────
    if "uid" not in request.session:
        return JsonResponse({"error": "Unauthorized"}, status=401)
    if owner and request.session.get("role") != "Store Owner":
        return JsonResponse({"error": "Forbidden — Owner only"}, status=403)
    return None

def _save_image(image_file, old_url=None):
    if not image_file:
        return None
    if getattr(image_file,"content_type","") not in {"image/jpeg","image/png","image/gif","image/webp"}:
        return None
    ext      = Path(image_file.name).suffix.lower() or ".jpg"
    filename = uuid.uuid4().hex + ext
    dest_dir = Path(settings.MEDIA_ROOT) / "products"
    dest_dir.mkdir(parents=True, exist_ok=True)
    with open(dest_dir / filename, "wb") as f:
        for chunk in image_file.chunks():
            f.write(chunk)
    if old_url:
        try:
            p = Path(settings.MEDIA_ROOT) / old_url.replace("/media/","",1)
            if p.exists(): p.unlink()
        except Exception:
            pass
    return f"/media/products/{filename}"

def _save_avatar(image_file, old_url=None):
    if not image_file:
        return None
    if getattr(image_file,"content_type","") not in {"image/jpeg","image/png","image/gif","image/webp"}:
        return None
    ext      = Path(image_file.name).suffix.lower() or ".jpg"
    filename = uuid.uuid4().hex + ext
    dest_dir = Path(settings.MEDIA_ROOT) / "avatars"
    dest_dir.mkdir(parents=True, exist_ok=True)
    with open(dest_dir / filename, "wb") as f:
        for chunk in image_file.chunks():
            f.write(chunk)
    if old_url:
        try:
            p = Path(settings.MEDIA_ROOT) / old_url.replace("/media/","",1)
            if p.exists(): p.unlink()
        except Exception:
            pass
    return f"/media/avatars/{filename}"

def _parse_product_request(request):
    ct = request.content_type or ""
    if "multipart" in ct:
        if request.method == "POST":
            return request.POST, request.FILES.get("image")
        from django.http.multipartparser import MultiPartParser
        post_data, file_data = MultiPartParser(request.META, request, request.upload_handlers).parse()
        return post_data, file_data.get("image")
    return _body(request), None


# ── Frontend ──────────────────────────────────────────────────────────────────

def index(request):
    return render(request, "store/index.html")


# ── Auth ──────────────────────────────────────────────────────────────────────

@csrf_exempt
def me(request):
    if request.method == "GET":
        if "uid" not in request.session:
            return JsonResponse(None, safe=False)
        conn = get_db()
        row  = conn.execute("SELECT * FROM users WHERE id=?", (request.session["uid"],)).fetchone()
        conn.close()
        return JsonResponse(u2d(row) if row else None, safe=False)

    if request.method == "PUT":
        err = _guard(request)
        if err: return err
        d, avatar_file = _parse_product_request(request)
        full_name = (d.get("fullName") or "").strip()
        password  = (d.get("password") or "").strip()
        if not full_name or not password:
            return JsonResponse({"error":"Name and password required"}, status=400)
        conn     = get_db()
        old_row  = conn.execute("SELECT avatar FROM users WHERE id=?", (request.session["uid"],)).fetchone()
        new_av   = _save_avatar(avatar_file, old_row["avatar"] if old_row else None)
        if new_av:
            conn.execute("UPDATE users SET full_name=?,password=?,avatar=? WHERE id=?",
                         (full_name, password, new_av, request.session["uid"]))
        else:
            conn.execute("UPDATE users SET full_name=?,password=? WHERE id=?",
                         (full_name, password, request.session["uid"]))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (request.session["uid"],)).fetchone()
        conn.close()
        return JsonResponse(u2d(row))
    return JsonResponse({"error":"Method not allowed"}, status=405)

@csrf_exempt
@require_http_methods(["POST"])
def login(request):
    d   = _body(request)
    conn= get_db()
    row = conn.execute(
        "SELECT * FROM users WHERE username=? AND password=? AND active=1",
        (d.get("username",""), d.get("password",""))
    ).fetchone()
    conn.close()
    if not row:
        return JsonResponse({"error":"Invalid username or password"}, status=401)
    request.session["uid"]  = row["id"]
    request.session["role"] = row["role"]
    request.session.save()
    return JsonResponse(u2d(row))

@csrf_exempt
@require_http_methods(["POST"])
def logout(request):
    request.session.flush()
    return JsonResponse({"ok":True})


# ── Products ──────────────────────────────────────────────────────────────────

@csrf_exempt
def products(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
        conn.close()
        return JsonResponse([p2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d, image_file = _parse_product_request(request)
        image_url     = _save_image(image_file)
        conn = get_db()
        cur  = conn.execute(
            "INSERT INTO products (name,category,price,stock,reorder_level,image) VALUES (?,?,?,?,?,?)",
            (d.get("name",""), d.get("category",""), float(d.get("price",0)),
             int(d.get("stock",0)), int(d.get("reorderLevel",10)), image_url)
        )
        conn.commit()
        row = conn.execute("SELECT * FROM products WHERE id=?", (cur.lastrowid,)).fetchone()
        conn.close()
        prod = p2d(row)
        # ── sync enqueue ──────────────────────────────────────────────────────
        eng = _sync()
        if eng:
            eng.enqueue("products","upsert",prod["id"],{
                "local_id":      prod["id"],
                "name":          prod["name"],
                "category":      prod["category"],
                "price":         prod["price"],
                "stock":         prod["stock"],
                "reorder_level": prod["reorderLevel"],
                "deleted":       False,
                "updated_at":    datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse(prod, status=201)
    return JsonResponse({"error":"Method not allowed"}, status=405)

@csrf_exempt
def product_detail(request, pid):
    if request.method == "PUT":
        err = _guard(request, owner=True)
        if err: return err
        d, image_file = _parse_product_request(request)
        conn      = get_db()
        old_row   = conn.execute("SELECT image FROM products WHERE id=?", (pid,)).fetchone()
        new_image = _save_image(image_file, old_row["image"] if old_row else None)
        if new_image:
            conn.execute(
                "UPDATE products SET name=?,category=?,price=?,stock=?,reorder_level=?,image=? WHERE id=?",
                (d.get("name",""), d.get("category",""), float(d.get("price",0)),
                 int(d.get("stock",0)), int(d.get("reorderLevel",10)), new_image, pid))
        else:
            conn.execute(
                "UPDATE products SET name=?,category=?,price=?,stock=?,reorder_level=? WHERE id=?",
                (d.get("name",""), d.get("category",""), float(d.get("price",0)),
                 int(d.get("stock",0)), int(d.get("reorderLevel",10)), pid))
        conn.commit()
        row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        conn.close()
        prod = p2d(row)
        eng = _sync()
        if eng:
            eng.enqueue("products","upsert",prod["id"],{
                "local_id":      prod["id"],
                "name":          prod["name"],
                "category":      prod["category"],
                "price":         prod["price"],
                "stock":         prod["stock"],
                "reorder_level": prod["reorderLevel"],
                "deleted":       False,
                "updated_at":    datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse(prod)

    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        conn = get_db()
        row  = conn.execute("SELECT image FROM products WHERE id=?", (pid,)).fetchone()
        if row and row["image"]:
            try:
                p = Path(settings.MEDIA_ROOT) / row["image"].replace("/media/","",1)
                if p.exists(): p.unlink()
            except Exception:
                pass
        conn.execute("DELETE FROM products WHERE id=?", (pid,))
        conn.commit()
        conn.close()
        eng = _sync()
        if eng:
            eng.enqueue("products","delete",str(pid),{
                "local_id": pid,
                "deleted":  True,
                "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse({"ok":True})
    return JsonResponse({"error":"Method not allowed"}, status=405)


# ── Sales ─────────────────────────────────────────────────────────────────────

@csrf_exempt
def sales(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM sales ORDER BY date DESC, id DESC").fetchall()
        conn.close()
        return JsonResponse([s2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request)
        if err: return err
        d    = _body(request)
        now  = datetime.now()
        date_str, time_str = now.strftime("%Y-%m-%d"), now.strftime("%I:%M %p")
        receipt_no   = "RCP-" + uuid.uuid4().hex[:6].upper()
        cashier_name = d.get("cashier","")
        conn = get_db()
        cashier_row = conn.execute("SELECT id FROM users WHERE full_name=?", (cashier_name,)).fetchone()
        cashier_id  = cashier_row["id"] if cashier_row else None
        saved = []
        amt   = d.get("amountTendered")
        chg   = d.get("change")
        for item in d.get("items", []):
            conn.execute("UPDATE products SET stock=MAX(0,stock-?) WHERE id=?",
                         (item["qty"], item["productId"]))
            cur = conn.execute(
                "INSERT INTO sales (product_id,product_name,qty,total,date,cashier,cashier_id,time,receipt_no,amount_tendered,change_given) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (item["productId"], item["productName"], item["qty"], item["total"],
                 date_str, cashier_name, cashier_id, time_str, receipt_no, amt, chg)
            )
            row = conn.execute("SELECT * FROM sales WHERE id=?", (cur.lastrowid,)).fetchone()
            sale_dict = {**s2d(row), "price": item.get("price",0)}
            saved.append(sale_dict)
            # ── sync enqueue ──────────────────────────────────────────────────
            eng = _sync()
            if eng:
                _now = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
                eng.enqueue("sales","upsert",row["id"],{
                    "local_id":       row["id"],
                    "product_name":   item["productName"],
                    "qty":            item["qty"],
                    "total":          item["total"],
                    "sale_date":      date_str,
                    "cashier":        cashier_name,
                    "sale_time":      time_str,
                    "receipt_no":     receipt_no,
                    "amount_tendered": amt,
                    "change_given":   chg,
                    "created_at":     _now,
                    "updated_at":     _now,
                })
                # ── also push the updated stock level for this product ─────────
                prod_row = conn.execute("SELECT * FROM products WHERE id=?",
                                        (item["productId"],)).fetchone()
                if prod_row:
                    eng.enqueue("products","upsert",prod_row["id"],{
                        "local_id":      prod_row["id"],
                        "name":          prod_row["name"],
                        "category":      prod_row["category"],
                        "price":         float(prod_row["price"]),
                        "stock":         int(prod_row["stock"]),
                        "reorder_level": int(prod_row["reorder_level"]),
                        "image_url":     prod_row["image"] if prod_row["image"] and prod_row["image"].startswith("http") else None,
                        "deleted":       False,
                        "updated_at":    _now,
                    })
        conn.commit()
        all_products = [p2d(r) for r in conn.execute("SELECT * FROM products ORDER BY name").fetchall()]
        conn.close()
        return JsonResponse({"sales":saved,"products":all_products,
                             "receiptNo":receipt_no,"date":date_str,"time":time_str})
    return JsonResponse({"error":"Method not allowed"}, status=405)


# ── Users ─────────────────────────────────────────────────────────────────────

@csrf_exempt
def users(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM users ORDER BY role,full_name").fetchall()
        conn.close()
        return JsonResponse([u2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d = _body(request)
        conn = get_db()
        try:
            cur = conn.execute(
                "INSERT INTO users (username,password,full_name,role,active) VALUES (?,?,?,?,?)",
                (d["username"], d["password"], d["fullName"], "Cashier",
                 1 if d.get("active", True) else 0)
            )
            conn.commit()
            row = conn.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
            eng = _sync()
            if eng:
                eng.enqueue("users", "upsert", row["id"], {
                    "local_id":  row["id"],
                    "username":  row["username"],
                    "password":  row["password"],
                    "full_name": row["full_name"],
                    "role":      row["role"],
                    "active":    bool(row["active"]),
                    "deleted":   False,
                    "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                })
            conn.close()
            return JsonResponse(u2d(row), status=201)
        except Exception:
            conn.close()
            return JsonResponse({"error": "Username already taken"}, status=409)
    return JsonResponse({"error": "Method not allowed"}, status=405)

@csrf_exempt
def user_detail(request, uid):
    if request.method == "PUT":
        err = _guard(request, owner=True)
        if err: return err
        d, avatar_file = _parse_product_request(request)
        conn    = get_db()
        old_row = conn.execute("SELECT avatar FROM users WHERE id=?", (uid,)).fetchone()
        new_av  = _save_avatar(avatar_file, old_row["avatar"] if old_row else None)
        if new_av:
            conn.execute("UPDATE users SET full_name=?,password=?,active=?,avatar=? WHERE id=?",
                         (d.get("fullName",""), d.get("password",""),
                          1 if d.get("active",True) else 0, new_av, uid))
        else:
            conn.execute("UPDATE users SET full_name=?,password=?,active=? WHERE id=?",
                         (d.get("fullName",""), d.get("password",""),
                          1 if d.get("active",True) else 0, uid))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        eng = _sync()
        if eng:
            eng.enqueue("users","upsert",uid,{
                "local_id":  row["id"],
                "username":  row["username"],
                "password":  row["password"],
                "full_name": row["full_name"],
                "role":      row["role"],
                "active":    bool(row["active"]),
                "deleted":   False,
                "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        conn.close()
        return JsonResponse(u2d(row))

    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        if uid == request.session.get("uid"):
            return JsonResponse({"error":"Cannot delete your own account"}, status=400)
        conn = get_db()
        ur   = conn.execute("SELECT full_name FROM users WHERE id=?", (uid,)).fetchone()
        if ur:
            conn.execute("DELETE FROM sales WHERE cashier_id=? OR cashier=?", (uid, ur["full_name"]))
        conn.execute("DELETE FROM users WHERE id=?", (uid,))
        conn.commit()
        conn.close()
        eng = _sync()
        if eng:
            eng.enqueue("users","delete",str(uid),{
                "local_id": uid, "deleted": True,
                "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse({"ok":True})
    return JsonResponse({"error":"Method not allowed"}, status=405)

@csrf_exempt
@require_http_methods(["POST"])
def user_toggle(request, uid):
    err = _guard(request, owner=True)
    if err: return err
    conn = get_db()
    conn.execute("UPDATE users SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=?", (uid,))
    conn.commit()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    eng = _sync()
    if eng:
        eng.enqueue("users","upsert",uid,{
            "local_id":  row["id"],
            "username":  row["username"],
            "password":  row["password"],
            "full_name": row["full_name"],
            "role":      row["role"],
            "active":    bool(row["active"]),
            "deleted":   False,
            "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        })
    conn.close()
    return JsonResponse(u2d(row))


# ── Categories ────────────────────────────────────────────────────────────────

@csrf_exempt
def categories(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
        conn.close()
        return JsonResponse([c2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d    = _body(request)
        name = (d.get("name") or "").strip()
        if not name:
            return JsonResponse({"error":"Category name required"}, status=400)
        conn = get_db()
        try:
            cur = conn.execute("INSERT INTO categories (name) VALUES (?)", (name,))
            conn.commit()
            row = conn.execute("SELECT * FROM categories WHERE id=?", (cur.lastrowid,)).fetchone()
            eng = _sync()
            if eng:
                eng.enqueue("categories","upsert",row["id"],{
                    "local_id":  row["id"],
                    "name":      row["name"],
                    "deleted":   False,
                    "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                })
            conn.close()
            return JsonResponse(c2d(row), status=201)
        except Exception:
            conn.close()
            return JsonResponse({"error":"Category already exists"}, status=409)
    return JsonResponse({"error":"Method not allowed"}, status=405)

@csrf_exempt
def category_detail(request, cid):
    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        conn = get_db()
        row  = conn.execute("SELECT name FROM categories WHERE id=?", (cid,)).fetchone()
        if not row:
            conn.close()
            return JsonResponse({"error":"Not found"}, status=404)
        in_use = conn.execute("SELECT COUNT(*) FROM products WHERE category=?", (row["name"],)).fetchone()[0]
        if in_use:
            conn.close()
            return JsonResponse({"error":f"Cannot delete — {in_use} product(s) use this category"}, status=409)
        conn.execute("DELETE FROM categories WHERE id=?", (cid,))
        conn.commit()
        conn.close()
        eng = _sync()
        if eng:
            eng.enqueue("categories","delete",str(cid),{
                "local_id": cid, "deleted": True,
                "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse({"ok":True})
    return JsonResponse({"error":"Method not allowed"}, status=405)


# ── Store Settings ────────────────────────────────────────────────────────────

@csrf_exempt
def store_settings(request):
    if request.method == "GET":
        conn = get_db()
        row  = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()
        conn.close()
        return JsonResponse(ss2d(row))

    if request.method == "POST":
        d, logo_file = _parse_product_request(request)
        conn     = get_db()
        old_row  = conn.execute("SELECT logo_url FROM store_settings WHERE id=1").fetchone()
        old_logo = old_row["logo_url"] if old_row else None
        new_logo = _save_image(logo_file, old_logo) if logo_file else None

        store_name = (d.get("storeName") or "Tindahan Mo").strip()
        tagline    = (d.get("tagline") or "").strip()

        if new_logo:
            conn.execute("""
                INSERT INTO store_settings (id,store_name,tagline,logo_url,setup_done) VALUES (1,?,?,?,1)
                ON CONFLICT(id) DO UPDATE SET store_name=excluded.store_name,
                tagline=excluded.tagline, logo_url=excluded.logo_url, setup_done=1""",
                (store_name, tagline, new_logo))
        else:
            conn.execute("""
                INSERT INTO store_settings (id,store_name,tagline,logo_url,setup_done) VALUES (1,?,?,NULL,1)
                ON CONFLICT(id) DO UPDATE SET store_name=excluded.store_name,
                tagline=excluded.tagline, setup_done=1""",
                (store_name, tagline))
        conn.commit()
        row = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()
        conn.close()

        # ── sync: push store registration ─────────────────────────────────────
        eng = _sync()
        if eng:
            eng.enqueue("store_settings","upsert","1",{
                "store_name": store_name,
                "tagline":    tagline,
                "updated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
        return JsonResponse(ss2d(row))
    return JsonResponse({"error":"Method not allowed"}, status=405)


# ── Cloud Sync API ────────────────────────────────────────────────────────────

@csrf_exempt
def sync_status(request):
    """GET /api/sync/status — returns current sync engine state."""
    try:
        from .sync import get_engine
        return JsonResponse(get_engine().status_dict())
    except Exception as exc:
        return JsonResponse({"enabled":False,"status":"error","error":str(exc),"pending":0})


@csrf_exempt
def cloud_config(request):
    """
    GET  /api/cloud-config  — returns current cloud config (key shown to owner)
    POST /api/cloud-config  — save + enable/disable sync
    """
    err = _guard(request, owner=True)
    if err: return err

    if request.method == "GET":
        conn = get_db()
        row  = conn.execute("SELECT * FROM cloud_config WHERE id=1").fetchone()
        conn.close()
        if not row:
            return JsonResponse({"supabaseUrl":SUPABASE_URL,"supabaseKey":SUPABASE_KEY,"storeId":None,"enabled":False})
        key = row["supabase_key"] or SUPABASE_KEY
        return JsonResponse({
            "supabaseUrl": row["supabase_url"] or SUPABASE_URL,
            "supabaseKey": key,  # return real key — owner-only, local desktop app
            "storeId":     row["store_id"],
            "enabled":     bool(row["enabled"]),
            "lastPushed":  row["last_pushed_at"],
            "lastPulled":  row["last_pulled_at"],
        })

    if request.method == "POST":
        d   = _body(request)
        url = (d.get("supabaseUrl") or "").strip().rstrip("/")
        key = (d.get("supabaseKey") or "").strip()
        enabled = bool(d.get("enabled", False))

        conn      = get_db()
        old_row   = conn.execute("SELECT supabase_key, store_id FROM cloud_config WHERE id=1").fetchone()
        store_id  = old_row["store_id"] if old_row else None

        # If key is empty (user left it blank), keep existing key unchanged
        actual_key = key if key else (old_row["supabase_key"] if old_row else "")

        # Test connection before saving
        if url and actual_key:
            try:
                from .sync import get_engine
                ok = get_engine().test_connection(url, actual_key)
                if not ok:
                    conn.close()
                    return JsonResponse({"error":"Cannot connect to Supabase. Check URL and key."}, status=400)
            except Exception as exc:
                conn.close()
                return JsonResponse({"error":f"Connection test failed: {exc}"}, status=400)

        conn.execute("""
            UPDATE cloud_config SET supabase_url=?, supabase_key=?, enabled=? WHERE id=1""",
            (url, actual_key, 1 if (enabled and url and actual_key) else 0))
        conn.commit()
        conn.close()

        # Reconfigure sync engine
        try:
            from .sync import get_engine
            from django.conf import settings
            get_engine().configure(settings.TINDAHAN_DB_PATH, settings.TINDAHAN_DB_KEY, str(settings.MEDIA_ROOT))
        except Exception:
            pass

        return JsonResponse({"ok":True, "storeId": store_id})
    return JsonResponse({"error":"Method not allowed"}, status=405)


@csrf_exempt
@require_http_methods(["POST"])
def register_store(request):
    """
    POST /api/cloud-config/register
    Registers this store in Supabase and SYNCHRONOUSLY pushes ALL local data:
    store_settings, users, categories, products.
    This ensures that even if the local DB is deleted after this call,
    the data lives in Supabase and can be restored via Connect Existing Store.
    """
    err = _guard(request, owner=True)
    if err: return err

    conn    = get_db()
    cfg_row = conn.execute("SELECT * FROM cloud_config WHERE id=1").fetchone()
    ss_row  = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()

    if not cfg_row or not cfg_row["supabase_url"] or not cfg_row["supabase_key"]:
        conn.close()
        return JsonResponse({"error": "Configure Supabase URL and key first."}, status=400)

    sb_url = cfg_row["supabase_url"] or SUPABASE_URL
    sb_key = cfg_row["supabase_key"] or SUPABASE_KEY

    try:
        from .sync import get_engine
        from django.conf import settings as djsettings
        eng = get_engine()

        # ── 1. Register store row ─────────────────────────────────────────────
        store_id = eng.register_store(
            sb_url, sb_key,
            ss_row["store_name"] if ss_row else "Tindahan Mo",
            ss_row["tagline"]    if ss_row else "",
        )
        conn.execute("UPDATE cloud_config SET store_id=?, enabled=1 WHERE id=1", (store_id,))
        conn.commit()

        cfg = {"supabase_url": sb_url, "supabase_key": sb_key, "store_id": store_id}
        now_iso = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

        pushed = {"users": 0, "categories": 0, "products": 0}

        # ── 2. Push store_settings ────────────────────────────────────────────
        if ss_row:
            logo_url = None
            if ss_row["logo_url"] and not ss_row["logo_url"].startswith("http"):
                try:
                    logo_url = eng._upload_image_if_needed(cfg, "store_settings", {
                        "logo_url": ss_row["logo_url"]
                    }).get("logo_url") or ss_row["logo_url"]
                except Exception:
                    logo_url = ss_row["logo_url"]
            else:
                logo_url = ss_row["logo_url"]
            eng._sb_upsert(cfg, "store_settings", {
                "store_id":   store_id,
                "store_name": ss_row["store_name"],
                "tagline":    ss_row["tagline"] or "",
                "logo_url":   logo_url,
                "updated_at": now_iso,
            })

        # ── 3. Push users (including owner) ───────────────────────────────────
        users = conn.execute("SELECT * FROM users").fetchall()
        for u in users:
            payload = {
                "store_id":   store_id,
                "local_id":   u["id"],
                "username":   u["username"],
                "password":   u["password"],
                "full_name":  u["full_name"],
                "role":       u["role"],
                "active":     bool(u["active"]),
                "deleted":    False,
                "updated_at": now_iso,
            }
            if u["avatar"] and not u["avatar"].startswith("http"):
                try:
                    payload["avatar_url"] = eng._upload_image_if_needed(
                        cfg, "users", {"avatar_url": u["avatar"]}
                    ).get("avatar_url") or u["avatar"]
                except Exception:
                    payload["avatar_url"] = None
            eng._sb_upsert(cfg, "users", payload)
            pushed["users"] += 1

        # ── 4. Push categories ────────────────────────────────────────────────
        cats = conn.execute("SELECT * FROM categories").fetchall()
        for c in cats:
            eng._sb_upsert(cfg, "categories", {
                "store_id":   store_id,
                "local_id":   c["id"],
                "name":       c["name"],
                "deleted":    False,
                "updated_at": now_iso,
            })
            pushed["categories"] += 1

        # ── 5. Push products ──────────────────────────────────────────────────
        prods = conn.execute("SELECT * FROM products").fetchall()
        for p in prods:
            payload = {
                "store_id":      store_id,
                "local_id":      p["id"],
                "name":          p["name"],
                "category":      p["category"],
                "price":         float(p["price"]),
                "stock":         int(p["stock"]),
                "reorder_level": int(p["reorder_level"]),
                "deleted":       False,
                "updated_at":    now_iso,
            }
            if p["image"] and not p["image"].startswith("http"):
                try:
                    payload["image_url"] = eng._upload_image_if_needed(
                        cfg, "products", {"image_url": p["image"]}
                    ).get("image_url") or p["image"]
                except Exception:
                    payload["image_url"] = None
            else:
                payload["image_url"] = p["image"] or None
            eng._sb_upsert(cfg, "products", payload)
            pushed["products"] += 1

        # ── 6. Push sales ─────────────────────────────────────────────────────
        pushed["sales"] = 0
        sales = conn.execute("SELECT * FROM sales").fetchall()
        for s in sales:
            eng._sb_upsert(cfg, "sales", {
                "store_id":        store_id,
                "local_id":        s["id"],
                "product_name":    s["product_name"],
                "qty":             int(s["qty"]),
                "total":           float(s["total"]),
                "sale_date":       s["date"],
                "cashier":         s["cashier"],
                "sale_time":       s["time"],
                "receipt_no":      s["receipt_no"],
                "amount_tendered": float(s["amount_tendered"]) if s["amount_tendered"] is not None else None,
                "change_given":    float(s["change_given"])    if s["change_given"]    is not None else None,
                "updated_at":      now_iso,
            })
            pushed["sales"] += 1

        conn.close()

        # ── 6. Reconfigure background sync engine ─────────────────────────────
        eng.configure(
            djsettings.TINDAHAN_DB_PATH,
            djsettings.TINDAHAN_DB_KEY,
            str(djsettings.MEDIA_ROOT)
        )

        return JsonResponse({
            "ok":     True,
            "storeId": store_id,
            "pushed":  pushed,
        })
    except Exception as exc:
        import traceback; traceback.print_exc()
        try: conn.close()
        except Exception: pass
        return JsonResponse({"error": str(exc)}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def sync_now(request):
    """POST /api/sync/now — trigger immediate push+pull cycle."""
    err = _guard(request, owner=True)
    if err: return err
    try:
        from .sync import get_engine
        import threading
        eng = get_engine()
        cfg = eng._load_config()
        if not cfg or not cfg["enabled"]:
            return JsonResponse({"error":"Sync not enabled"}, status=400)
        threading.Thread(target=eng._push, args=(cfg,), daemon=True).start()
        threading.Thread(target=eng._pull, args=(cfg,), daemon=True).start()
        return JsonResponse({"ok":True})
    except Exception as exc:
        return JsonResponse({"error":str(exc)}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def set_store_id(request):
    """
    POST /api/cloud-config/set-store-id
    Directly set the store_id to an existing UUID (no Supabase API call).
    Use when the owner already has a store registered and just needs to
    link this installation to it.
    """
    err = _guard(request, owner=True)
    if err: return err

    import re
    d        = _body(request)
    store_id = (d.get("storeId") or "").strip()

    UUID_RE = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
        re.IGNORECASE
    )
    if not UUID_RE.match(store_id):
        return JsonResponse({"error": "Invalid UUID format."}, status=400)

    conn = get_db()
    conn.execute(
        "UPDATE cloud_config SET store_id=?, enabled=1 WHERE id=1",
        (store_id,)
    )
    conn.commit()
    conn.close()

    # Reconfigure sync engine with the new store_id
    try:
        from .sync import get_engine
        from django.conf import settings
        get_engine().configure(settings.TINDAHAN_DB_PATH, settings.TINDAHAN_DB_KEY, str(settings.MEDIA_ROOT))
    except Exception:
        pass

    return JsonResponse({"ok": True, "storeId": store_id})


@csrf_exempt
@require_http_methods(["POST"])
def reset_sync_cursor(request):
    """
    POST /api/sync/reset-cursor
    Resets last_pulled_at to 1970 so the next pull fetches ALL cloud data.
    Use this on a fresh install to pull everything from Computer 1.
    """
    err = _guard(request, owner=True)
    if err: return err
    conn = get_db()
    conn.execute("UPDATE cloud_config SET last_pulled_at=NULL WHERE id=1")
    conn.commit()
    conn.close()
    # Trigger immediate pull
    try:
        from .sync import get_engine
        import threading
        eng = get_engine()
        cfg = eng._load_config()
        if cfg and cfg["enabled"]:
            threading.Thread(target=eng._pull, args=(cfg,), daemon=True).start()
    except Exception:
        pass
    return JsonResponse({"ok": True})


@csrf_exempt
@require_http_methods(["POST"])
def push_all(request):
    """
    POST /api/sync/push-all
    Re-push ALL local data to Supabase synchronously.
    """
    import traceback
    try:
        err = _guard(request, owner=True)
        if err:
            return err

        conn    = get_db()
        cfg_row = conn.execute("SELECT * FROM cloud_config WHERE id=1").fetchone()
        ss_row  = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()

        if not cfg_row:
            conn.close()
            return JsonResponse({"error": "Cloud config not found."}, status=400)
        if not cfg_row["enabled"]:
            conn.close()
            return JsonResponse({"error": "Cloud sync is not enabled. Configure Supabase credentials first."}, status=400)
        if not cfg_row["store_id"]:
            conn.close()
            return JsonResponse({"error": "No Store ID. Register the store first in Cloud Sync settings."}, status=400)

        from .sync import get_engine
        eng = get_engine()
        cfg = {
            "supabase_url": cfg_row["supabase_url"] or SUPABASE_URL,
            "supabase_key": cfg_row["supabase_key"] or SUPABASE_KEY,
            "store_id":     cfg_row["store_id"],
        }
        sid     = cfg_row["store_id"]
        now_iso = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        pushed  = {"users": 0, "categories": 0, "products": 0}
        errors  = []

        # ── store_settings ────────────────────────────────────────────────────
        if ss_row:
            try:
                logo_url = ss_row["logo_url"] or None
                if logo_url and not logo_url.startswith("http"):
                    logo_url = eng._upload_image_if_needed(
                        cfg, "store_settings", {"logo_url": logo_url}
                    ).get("logo_url") or logo_url
                eng._sb_upsert(cfg, "store_settings", {
                    "store_id":   sid,
                    "store_name": ss_row["store_name"],
                    "tagline":    ss_row["tagline"] or "",
                    "logo_url":   logo_url,
                    "updated_at": now_iso,
                })
            except Exception as e:
                errors.append(f"store_settings: {e}")

        # ── users ─────────────────────────────────────────────────────────────
        for u in conn.execute("SELECT * FROM users").fetchall():
            try:
                avatar_url = None
                if u["avatar"]:
                    if u["avatar"].startswith("http"):
                        avatar_url = u["avatar"]
                    else:
                        avatar_url = eng._upload_image_if_needed(
                            cfg, "users", {"avatar_url": u["avatar"]}
                        ).get("avatar_url")
                eng._sb_upsert(cfg, "users", {
                    "store_id":   sid,
                    "local_id":   u["id"],
                    "username":   u["username"],
                    "password":   u["password"],
                    "full_name":  u["full_name"],
                    "role":       u["role"],
                    "active":     bool(u["active"]),
                    "avatar_url": avatar_url,
                    "deleted":    False,
                    "updated_at": now_iso,
                })
                pushed["users"] += 1
            except Exception as e:
                errors.append(f"user {u['username']}: {e}")

        # ── categories ────────────────────────────────────────────────────────
        for c in conn.execute("SELECT * FROM categories").fetchall():
            try:
                eng._sb_upsert(cfg, "categories", {
                    "store_id":   sid,
                    "local_id":   c["id"],
                    "name":       c["name"],
                    "deleted":    False,
                    "updated_at": now_iso,
                })
                pushed["categories"] += 1
            except Exception as e:
                errors.append(f"category {c['name']}: {e}")

        # ── products ──────────────────────────────────────────────────────────
        for p in conn.execute("SELECT * FROM products").fetchall():
            try:
                image_url = None
                if p["image"]:
                    if p["image"].startswith("http"):
                        image_url = p["image"]
                    else:
                        image_url = eng._upload_image_if_needed(
                            cfg, "products", {"image_url": p["image"]}
                        ).get("image_url") or p["image"]
                eng._sb_upsert(cfg, "products", {
                    "store_id":      sid,
                    "local_id":      p["id"],
                    "name":          p["name"],
                    "category":      p["category"],
                    "price":         float(p["price"]),
                    "stock":         int(p["stock"]),
                    "reorder_level": int(p["reorder_level"]),
                    "image_url":     image_url,
                    "deleted":       False,
                    "updated_at":    now_iso,
                })
                pushed["products"] += 1
            except Exception as e:
                errors.append(f"product {p['name']}: {e}")

        # ── sales ─────────────────────────────────────────────────────────────
        pushed["sales"] = 0
        for s in conn.execute("SELECT * FROM sales").fetchall():
            try:
                eng._sb_upsert(cfg, "sales", {
                    "store_id":        sid,
                    "local_id":        s["id"],
                    "product_name":    s["product_name"],
                    "qty":             int(s["qty"]),
                    "total":           float(s["total"]),
                    "sale_date":       s["date"],
                    "cashier":         s["cashier"],
                    "sale_time":       s["time"],
                    "receipt_no":      s["receipt_no"],
                    "amount_tendered": float(s["amount_tendered"]) if s["amount_tendered"] is not None else None,
                    "change_given":    float(s["change_given"])    if s["change_given"]    is not None else None,
                    "updated_at":      now_iso,
                })
                pushed["sales"] += 1
            except Exception as e:
                errors.append(f"sale #{s['id']}: {e}")

        conn.close()

        if errors and pushed["users"] == 0 and pushed["products"] == 0:
            return JsonResponse({"error": "Push failed: " + "; ".join(errors[:3])}, status=500)

        return JsonResponse({
            "ok":     True,
            "pushed": pushed,
            "errors": errors[:5],   # surface first few errors if any
        })

    except Exception as exc:
        return JsonResponse({"error": f"Unexpected error: {traceback.format_exc()}"}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def setup_connect(request):
    """
    POST /api/setup/connect
    Connect this fresh install to an existing cloud store.
    Body: { supabaseUrl, supabaseKey, storeId, ownerUsername, ownerPassword }

    No session required — this is a pre-auth first-launch endpoint.
    Authentication is done by verifying username+password against Supabase.
    """
    d              = _body(request)
    # URL and key are hardcoded in config.py — never entered by the user
    supabase_url   = SUPABASE_URL.rstrip("/")
    supabase_key   = SUPABASE_KEY
    store_id       = (d.get("storeId")        or "").strip()
    owner_user     = (d.get("ownerUsername")  or "").strip()
    owner_pass     = (d.get("ownerPassword")  or "").strip()

    if not all([store_id, owner_user, owner_pass]):
        return JsonResponse({"error": "Store UUID, username and password are required."}, status=400)

    import re
    if not re.match(r'^[0-9a-f-]{36}$', store_id, re.IGNORECASE):
        return JsonResponse({"error": "Invalid Store UUID format."}, status=400)

    from .sync import get_engine
    eng     = get_engine()
    cfg_tmp = {"supabase_url": supabase_url, "supabase_key": supabase_key,
               "store_id": store_id}

    # ── Step 1: verify the store exists in Supabase ───────────────────────────
    try:
        stores = eng._sb_get(cfg_tmp, "stores", {
            "id":    f"eq.{store_id}",
            "limit": "1",
        })
    except Exception as exc:
        return JsonResponse({"error": f"Cannot reach Supabase: {exc}"}, status=400)

    if not stores:
        return JsonResponse({"error": "Store ID not found. Check the UUID and try again."}, status=404)

    # ── Step 2: verify owner username + password ──────────────────────────────
    # Query ALL users for this store — no role filter, no deleted filter,
    # so we always find the row even if flags differ.
    try:
        all_users = eng._sb_get(cfg_tmp, "users", {
            "store_id": f"eq.{store_id}",
            "select":   "local_id,username,password,full_name,role,active,avatar_url,deleted",
        })
    except Exception as exc:
        return JsonResponse({"error": f"Could not fetch users: {exc}"}, status=400)

    cloud_owner = next(
        (u for u in all_users
         if u.get("username") == owner_user and u.get("password") == owner_pass),
        None
    )

    if not cloud_owner:
        found_usernames = [u.get("username") for u in all_users if not u.get("deleted")]
        if not all_users:
            hint = ("No accounts found in cloud yet. "
                    "On the original device go to Cloud Sync → Register Store to push data first.")
        elif owner_user not in found_usernames:
            hint = f"Username \u2018{owner_user}\u2019 not found. Please check and try again."
        else:
            hint = "Password is incorrect."
        return JsonResponse({"error": hint}, status=401)

    # ── Owner-only guard: only Store Owner can connect on a new device ────────
    user_role = (cloud_owner.get("role") or "").strip()
    if user_role != "Store Owner":
        return JsonResponse(
            {"error": (
                f"Only the Store Owner can connect on a new device.\n"
                f"\u2018{owner_user}\u2019 is a {user_role or 'Cashier'} account. "
                "Please use the Owner username and password."
            )},
            status=403,
        )

    # ── Step 3: fetch full snapshot now that we're authenticated ──────────────
    try:
        snapshot = eng.fetch_store_snapshot(supabase_url, supabase_key, store_id)
        # Merge all_users (includes deleted) — use the broader list for import
        snapshot["users"] = all_users
    except Exception as exc:
        return JsonResponse({"error": f"Data fetch failed: {exc}"}, status=400)

    # ── Import everything into local DB ──────────────────────────────────────
    conn = get_db()
    try:
        # ── Store settings ────────────────────────────────────────────────────
        ss = snapshot["settings"]
        sn = ss.get("store_name") or snapshot["store"].get("store_name") or "Tindahan Mo"
        tl = ss.get("tagline")    or snapshot["store"].get("tagline")    or ""
        logo_local = ss.get("logo_url") or snapshot["store"].get("logo_url") or None
        if logo_local:
            if not logo_local.startswith("http"):
                logo_local = None
            else:
                try:
                    dl = eng._download_image_if_needed(logo_local, "logos", store_id)
                    if dl:
                        logo_local = dl
                except Exception:
                    pass

        conn.execute("""
            INSERT INTO store_settings (id,store_name,tagline,logo_url,setup_done) VALUES (1,?,?,?,1)
            ON CONFLICT(id) DO UPDATE SET
              store_name=excluded.store_name,
              tagline=excluded.tagline,
              logo_url=excluded.logo_url,
              setup_done=1""",
            (sn, tl, logo_local)
        )

        # ── Categories ────────────────────────────────────────────────────────
        for c in snapshot["categories"]:
            lid = c.get("local_id")
            if lid is None:
                continue
            conn.execute("INSERT OR IGNORE INTO categories (id, name) VALUES (?, ?)", (lid, c["name"]))
            conn.execute("UPDATE categories SET name=? WHERE id=?", (c["name"], lid))

        # ── Products (stock, price, image — all fields) ───────────────────────
        for p in snapshot["products"]:
            lid = p.get("local_id")
            if lid is None:
                continue
            local_img = None
            cloud_img = p.get("image_url") or ""
            if cloud_img:
                try:
                    local_img = eng._download_image_if_needed(cloud_img, "products", store_id) or cloud_img
                except Exception:
                    local_img = cloud_img

            stock         = int(p.get("stock")         or 0)
            price         = float(p.get("price")        or 0)
            reorder_level = int(p.get("reorder_level")  or 10)

            conn.execute(
                "INSERT OR IGNORE INTO products "
                "(id, name, category, price, stock, reorder_level, image) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (lid, p["name"], p.get("category", ""), price, stock, reorder_level, local_img)
            )
            # Always update ALL fields including stock and image
            conn.execute(
                "UPDATE products SET name=?, category=?, price=?, stock=?, reorder_level=?, image=? WHERE id=?",
                (p["name"], p.get("category", ""), price, stock, reorder_level, local_img, lid)
            )

        # ── Users (all fields, all roles) ─────────────────────────────────────
        for u in snapshot["users"]:
            lid = u.get("local_id")
            if lid is None:
                continue
            active   = 1 if u.get("active") else 0
            local_av = None
            cloud_av = u.get("avatar_url") or ""
            if cloud_av:
                try:
                    local_av = eng._download_image_if_needed(cloud_av, "avatars", store_id) or cloud_av
                except Exception:
                    local_av = cloud_av

            conn.execute(
                "INSERT OR IGNORE INTO users "
                "(id, username, password, full_name, role, active, avatar) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (lid, u["username"], u["password"], u["full_name"],
                 u.get("role", "Cashier"), active, local_av)
            )
            conn.execute(
                "UPDATE users SET username=?, password=?, full_name=?, role=?, active=?, avatar=? WHERE id=?",
                (u["username"], u["password"], u["full_name"],
                 u.get("role", "Cashier"), active, local_av, lid)
            )

        # ── Sales ─────────────────────────────────────────────────────────────
        for s in snapshot.get("sales", []):
            lid = s.get("local_id")
            if lid is None:
                continue
            lid = int(lid)
            conn.execute(
                "INSERT OR IGNORE INTO sales "
                "(id, product_name, qty, total, date, cashier, "
                " time, receipt_no, amount_tendered, change_given) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (lid,
                 s.get("product_name", ""),
                 int(s.get("qty") or 0),
                 float(s.get("total") or 0),
                 s.get("sale_date") or s.get("date", ""),
                 s.get("cashier", ""),
                 s.get("sale_time") or s.get("time", ""),
                 s.get("receipt_no") or "",
                 float(s["amount_tendered"]) if s.get("amount_tendered") is not None else None,
                 float(s["change_given"])    if s.get("change_given")    is not None else None)
            )

        # ── Cloud config ──────────────────────────────────────────────────────
        conn.execute(
            "UPDATE cloud_config SET supabase_url=?, supabase_key=?, store_id=?, "
            "enabled=1, last_pulled_at=NULL WHERE id=1",
            (supabase_url, supabase_key, store_id)
        )
        conn.commit()
        conn.close()

    except Exception as exc:
        import traceback; traceback.print_exc()
        try: conn.close()
        except Exception: pass
        return JsonResponse({"error": f"Import failed: {exc}"}, status=500)

        # Configure and start sync engine
    try:
        from django.conf import settings as djsettings
        eng.configure(
            djsettings.TINDAHAN_DB_PATH,
            djsettings.TINDAHAN_DB_KEY,
            str(djsettings.MEDIA_ROOT)
        )
    except Exception:
        pass

    # ── Auto-login: find the local owner row and create a session ──
    try:
        conn  = get_db()
        owner = conn.execute("SELECT * FROM users WHERE role='Store Owner'").fetchone()
        conn.close()
        if owner:
            request.session["uid"]  = owner["id"]
            request.session["role"] = owner["role"]
            request.session.save()
    except Exception:
        pass

    return JsonResponse({
        "ok":        True,
        "storeName": sn,
        "storeId":   store_id,
        "imported": {
            "categories": len(snapshot["categories"]),
            "products":   len(snapshot["products"]),
            "users":      len(snapshot["users"]),
            "sales":      len(snapshot.get("sales", [])),
        }
    })


@csrf_exempt
@require_http_methods(["POST"])
def setup_set_owner(request):
    """
    POST /api/setup/set-owner
    Called from the new-store wizard to set the real owner credentials.
    Updates the placeholder owner row created by db.py seed.
    Validates uniqueness of username against any existing users.
    """
    d         = _body(request)
    full_name = (d.get("fullName")  or "").strip()
    username  = (d.get("username")  or "").strip().lower()
    password  = (d.get("password")  or "").strip()

    if not full_name:
        return JsonResponse({"error": "Full name is required."}, status=400)
    if not username:
        return JsonResponse({"error": "Username is required."}, status=400)
    if len(username) < 3:
        return JsonResponse({"error": "Username must be at least 3 characters."}, status=400)
    if not password:
        return JsonResponse({"error": "Password is required."}, status=400)
    if len(password) < 4:
        return JsonResponse({"error": "Password must be at least 4 characters."}, status=400)

    conn = get_db()
    try:
        # Check username is not already taken by a non-owner (edge case)
        conflict = conn.execute(
            "SELECT id FROM users WHERE username=? AND role != 'Store Owner'",
            (username,)
        ).fetchone()
        if conflict:
            return JsonResponse({"error": "Username already taken."}, status=409)

        # Update the placeholder owner row
        conn.execute(
            "UPDATE users SET full_name=?, username=?, password=? WHERE role='Store Owner'",
            (full_name, username, password)
        )
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE role='Store Owner'").fetchone()
        conn.close()

        # ── Auto-login: create session so step 3 (cloud config + register) works ──
        request.session["uid"]  = row["id"]
        request.session["role"] = row["role"]
        request.session.save()

        return JsonResponse({"ok": True, "owner": u2d(row)})
    except Exception as exc:
        conn.close()
        return JsonResponse({"error": str(exc)}, status=500)
