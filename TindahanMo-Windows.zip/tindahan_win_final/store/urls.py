from django.urls import path
from . import views

urlpatterns = [
    path("",                               views.index,           name="index"),
    path("api/me",                         views.me,              name="me"),
    path("api/login",                      views.login,           name="login"),
    path("api/logout",                     views.logout,          name="logout"),
    path("api/products",                   views.products,        name="products"),
    path("api/products/<int:pid>",         views.product_detail,  name="product_detail"),
    path("api/sales",                      views.sales,           name="sales"),
    path("api/users",                      views.users,           name="users"),
    path("api/users/<int:uid>",            views.user_detail,     name="user_detail"),
    path("api/users/<int:uid>/toggle",     views.user_toggle,     name="user_toggle"),
    path("api/categories",                 views.categories,      name="categories"),
    path("api/categories/<int:cid>",       views.category_detail, name="category_detail"),
    path("api/store-settings",             views.store_settings,  name="store_settings"),
    # ── Cloud Sync ────────────────────────────────────────────────────────────
    path("api/sync/status",                views.sync_status,     name="sync_status"),
    path("api/sync/now",                   views.sync_now,        name="sync_now"),
    path("api/cloud-config",               views.cloud_config,    name="cloud_config"),
    path("api/cloud-config/register",      views.register_store,  name="register_store"),
    path("api/cloud-config/set-store-id",  views.set_store_id,    name="set_store_id"),
    path("api/sync/reset-cursor",          views.reset_sync_cursor, name="reset_sync_cursor"),
    path("api/sync/push-all",              views.push_all,          name="push_all"),
    path("api/setup/connect",              views.setup_connect,     name="setup_connect"),
    path("api/setup/set-owner",            views.setup_set_owner,   name="setup_set_owner"),
]
