from django.apps import AppConfig


class StoreConfig(AppConfig):
    name = "store"
    verbose_name = "Tindahan Mo Store"

    def ready(self):
        # init_db() is called explicitly in launcher.py AFTER migrate runs.
        # Do NOT call it here — apps.ready() fires during django.setup(),
        # before migrations, which can cause table-not-found errors on
        # a brand-new database.
        pass
