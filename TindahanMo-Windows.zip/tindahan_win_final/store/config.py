"""
store/config.py — Hardcoded Supabase credentials for Tindahan Mo
=================================================================
Edit the two constants below to match your Supabase project.
Users will NEVER see or type these — they are baked into the app.

How to find these values:
  1. Go to https://supabase.com → your project → Settings → API
  2. Copy "Project URL"          → paste as SUPABASE_URL
  3. Copy "service_role" secret  → paste as SUPABASE_KEY  (NOT the anon key)
  4. Save this file and run ./build.sh to rebuild the AppImage.
"""

# ── Edit these two lines ──────────────────────────────────────────────────────
SUPABASE_URL = "https://YOUR-PROJECT-ID.supabase.co"
SUPABASE_KEY = "YOUR-SERVICE-ROLE-KEY-HERE"
# ─────────────────────────────────────────────────────────────────────────────
