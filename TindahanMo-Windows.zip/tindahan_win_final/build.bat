@echo off
setlocal EnableDelayedExpansion

:: ============================================================
::  Tindahan Mo — Windows Build Script
::  Builds TindahanMo.exe + dist folder ready to distribute
::  Requires: Python 3.10+ installed and on PATH
::  Run from the tindahan_hybrid folder:
::      build.bat
::  Optional: drop logo.png next to build.bat for custom icon
:: ============================================================

echo.
echo   ╔══════════════════════════════════════════════════════════╗
echo   ║  Tindahan Mo  ·  Windows Build  ·  Win10/11             ║
echo   ╚══════════════════════════════════════════════════════════╝
echo.

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "DIST_DIR=%SCRIPT_DIR%\dist"
set "VENV_DIR=%SCRIPT_DIR%\.venv"

:: ── 1. Check Python ─────────────────────────────────────────
echo [1/6] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: Python not found on PATH.
    echo.
    echo Please install Python 3.10+ from https://python.org
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo     Python %PYVER% found
echo.

:: ── 2. Virtual environment ───────────────────────────────────
echo [2/6] Setting up virtual environment...
if exist "%VENV_DIR%\Scripts\python.exe" (
    echo     Existing venv found — reusing
) else (
    echo     Creating new virtual environment...
    python -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo ERROR: Failed to create virtual environment
        pause
        exit /b 1
    )
)
call "%VENV_DIR%\Scripts\activate.bat"
python -m pip install --upgrade pip --quiet
echo     Virtual environment ready
echo.

:: ── 3. Install Python packages ───────────────────────────────
echo [3/6] Installing Python packages (~500 MB first run)...
echo     This may take several minutes on first run...
echo.

pip install ^
    "Django>=4.2,<6.0" ^
    "cryptography>=41.0" ^
    "pywebview>=5.0" ^
    "qtpy>=2.4" ^
    "PySide6>=6.6" ^
    "pyinstaller>=6.0" ^
    "Pillow>=9.0"

if errorlevel 1 (
    echo.
    echo ERROR: Package installation failed.
    echo Check your internet connection and try again.
    pause
    exit /b 1
)

echo.
echo     Verifying key packages...
python -c "import webview; print('    pywebview:', __import__('importlib.metadata', fromlist=['version']).version('pywebview'))"
python -c "import PySide6; print('    PySide6:', PySide6.__version__)"
python -c "import django; print('    Django:', django.__version__)"
echo.
echo     Packages installed OK
echo.

:: ── 4. Clean old build artifacts ─────────────────────────────
echo [4/6] Cleaning previous build...
if exist "%SCRIPT_DIR%\build" rmdir /s /q "%SCRIPT_DIR%\build"
if exist "%DIST_DIR%\TindahanMo" rmdir /s /q "%DIST_DIR%\TindahanMo"

:: Remove stale pyc/pycache
for /r "%SCRIPT_DIR%" %%d in (__pycache__) do (
    if exist "%%d" rmdir /s /q "%%d" 2>nul
)
del /s /q "%SCRIPT_DIR%\*.pyc" 2>nul
echo     Clean OK
echo.

:: ── 5. Generate app icons ─────────────────────────────────────
echo [5/6] Generating app icons...

:: Detect custom logo
if exist "%SCRIPT_DIR%\logo.png" (
    echo     Found logo.png — will be used as app icon
) else if exist "%SCRIPT_DIR%\logo.jpg" (
    echo     Found logo.jpg — will be used as app icon
) else (
    echo     No logo.png found — using built-in store icon
    echo     ^(Drop logo.png next to build.bat to use your own icon^)
)

python "%SCRIPT_DIR%\make_icon.py" "%SCRIPT_DIR%\tindahan_icon.png" 256
python "%SCRIPT_DIR%\make_icon.py" "%SCRIPT_DIR%\tindahan_icon.ico"

if not exist "%SCRIPT_DIR%\tindahan_icon.png" (
    echo ERROR: Icon generation failed
    pause
    exit /b 1
)
echo     Icons ready: tindahan_icon.png + tindahan_icon.ico
echo.

:: ── 6. Build with PyInstaller ─────────────────────────────────
echo [6/6] Building with PyInstaller (5-15 min first run)...
echo     Please wait — bundling Python + Qt + Django...
echo.

cd /d "%SCRIPT_DIR%"
pyinstaller tindahan_windows.spec ^
    --distpath "%DIST_DIR%" ^
    --workpath "%SCRIPT_DIR%\build" ^
    --noconfirm ^
    --clean

if errorlevel 1 (
    echo.
    echo ERROR: PyInstaller build failed.
    echo Check the output above for details.
    pause
    exit /b 1
)

set "APP_FOLDER=%DIST_DIR%\TindahanMo"
if not exist "%APP_FOLDER%\TindahanMo.exe" (
    echo ERROR: dist\TindahanMo\TindahanMo.exe not found after build
    pause
    exit /b 1
)

:: ── Report size ───────────────────────────────────────────────
for /f "tokens=3" %%s in ('dir "%APP_FOLDER%" /s /-c 2^>nul ^| find "File(s)"') do set APP_SIZE=%%s
echo.
echo   ╔══════════════════════════════════════════════════════════╗
echo   ║  BUILD SUCCESSFUL                                        ║
echo   ║                                                          ║
echo   ║  Output : dist\TindahanMo\TindahanMo.exe                ║
echo   ║  Run    : double-click TindahanMo.exe                    ║
echo   ║                                                          ║
echo   ║  To share: zip the entire dist\TindahanMo\ folder       ║
echo   ║  Or run  : build_installer.bat  for an .exe installer    ║
echo   ╚══════════════════════════════════════════════════════════╝
echo.

:: ── Optional: open the output folder ─────────────────────────
set /p OPEN="Open output folder? [Y/n]: "
if /i not "!OPEN!"=="n" explorer "%APP_FOLDER%"

pause
