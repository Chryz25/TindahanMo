@echo off
setlocal EnableDelayedExpansion
title Tindahan Mo - Auto Build

:: ================================================================
::  Tindahan Mo - FULLY AUTOMATIC Windows Build Script
::  Works on a FRESH Windows 10/11 PC with NOTHING pre-installed
::
::  What this script does automatically:
::    1. Finds Python (tries winget, py launcher, PATH, AppData)
::    2. Downloads + silently installs Python 3.11 if not found
::    3. Creates isolated virtual environment (.venv)
::    4. Downloads + installs ALL Python packages
::    5. Generates app icons (PNG + multi-size ICO)
::    6. Warns if Supabase keys are still placeholders
::    7. Builds TindahanMo.exe with PyInstaller
::
::  Requirements:
::    - Windows 10 or 11 (64-bit)
::    - Internet connection (first run only, ~500 MB download)
::    - ~3 GB free disk space
::
::  JUST DOUBLE-CLICK THIS FILE. Everything else is automatic.
:: ================================================================

echo.
echo   +============================================================+
echo   ^|   Tindahan Mo  *  Fully Automatic Windows Build           ^|
echo   ^|   Windows 10 / 11  -  Zero Manual Setup Required          ^|
echo   +============================================================+
echo.

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "DIST_DIR=%SCRIPT_DIR%\dist"
set "VENV_DIR=%SCRIPT_DIR%\.venv"
set "TOOLS_DIR=%SCRIPT_DIR%\.tools"
set "PYTHON_INSTALL_DIR=%TOOLS_DIR%\Python311"
set "PYTHON_INSTALLER=%TOOLS_DIR%\python-3.11.9-amd64.exe"
set "PYTHON_URL=https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
set "PYTHON_EXE="

:: ================================================================
:: STEP 1 -- Find or Install Python
:: ================================================================
echo [1/7] Locating Python...

:: 1a. Check python on PATH (version must be 3.10+)
python --version >nul 2>&1
if not errorlevel 1 (
    for /f "tokens=2" %%V in ('python --version 2^>^&1') do set "PYVER=%%V"
    for /f "tokens=2 delims=." %%M in ("!PYVER!") do set "PYMINOR=%%M"
    for /f "tokens=1 delims=." %%J in ("!PYVER!") do set "PYMAJ=%%J"
    if !PYMAJ! EQU 3 if !PYMINOR! GEQ 10 (
        set "PYTHON_EXE=python"
        echo       Found python !PYVER! on PATH
        goto :PYTHON_FOUND
    )
    echo       Skipping python !PYVER! -- too old, need 3.10+
)

:: 1b. Windows Python Launcher (py.exe)
py -3.11 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_EXE=py -3.11"
    for /f "tokens=2" %%V in ('py -3.11 --version 2^>^&1') do set "PYVER=%%V"
    echo       Found py -3.11 !PYVER! via Windows Launcher
    goto :PYTHON_FOUND
)
py -3.10 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_EXE=py -3.10"
    for /f "tokens=2" %%V in ('py -3.10 --version 2^>^&1') do set "PYVER=%%V"
    echo       Found py -3.10 !PYVER! via Windows Launcher
    goto :PYTHON_FOUND
)

:: 1c. Our own previously-downloaded copy
if exist "%PYTHON_INSTALL_DIR%\python.exe" (
    set "PYTHON_EXE=%PYTHON_INSTALL_DIR%\python.exe"
    for /f "tokens=2" %%V in ('"%PYTHON_INSTALL_DIR%\python.exe" --version 2^>^&1') do set "PYVER=%%V"
    echo       Found local install !PYVER! in .tools\Python311
    goto :PYTHON_FOUND
)

:: 1d. Try winget (built into Windows 11, and most updated Win10)
echo       Python not found -- trying winget (Windows Package Manager)...
winget --version >nul 2>&1
if not errorlevel 1 (
    echo       Installing Python 3.11 via winget...
    winget install --id Python.Python.3.11 --exact --silent ^
        --accept-package-agreements --accept-source-agreements >nul 2>&1
    :: Refresh PATH from registry so the new install is visible
    for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "PATH=%%B;%PATH%"
    for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "PATH=%%B;%PATH%"
    python --version >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=python"
        for /f "tokens=2" %%V in ('python --version 2^>^&1') do set "PYVER=%%V"
        echo       Installed Python !PYVER! via winget
        goto :PYTHON_FOUND
    )
    py -3.11 --version >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=py -3.11"
        for /f "tokens=2" %%V in ('py -3.11 --version 2^>^&1') do set "PYVER=%%V"
        echo       Installed Python !PYVER! via winget
        goto :PYTHON_FOUND
    )
)

:: 1e. Download Python installer directly (guaranteed fallback)
echo       Downloading Python 3.11.9 installer (~27 MB)...
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "[Net.ServicePointManager]::SecurityProtocol='Tls12,Tls13'; Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%PYTHON_INSTALLER%' -UseBasicParsing" ^
 2>nul
if not exist "%PYTHON_INSTALLER%" (
    echo.
    echo   +----------------------------------------------------------+
    echo   ^| ERROR: Cannot download Python automatically.             ^|
    echo   ^|                                                          ^|
    echo   ^| Please install Python 3.11 manually:                    ^|
    echo   ^|   1. Visit: https://www.python.org/downloads/           ^|
    echo   ^|   2. Download "Python 3.11.x Windows installer (64-bit)"^|
    echo   ^|   3. Run it -- check "Add Python to PATH"               ^|
    echo   ^|   4. Re-run this build.bat                              ^|
    echo   +----------------------------------------------------------+
    pause
    exit /b 1
)
echo       Installing Python 3.11.9 silently (1-2 minutes)...
"%PYTHON_INSTALLER%" /quiet ^
    TargetDir="%PYTHON_INSTALL_DIR%" ^
    InstallAllUsers=0 ^
    PrependPath=0 ^
    Include_pip=1 ^
    Include_tcltk=0 ^
    Include_test=0 ^
    Include_launcher=0
if not exist "%PYTHON_INSTALL_DIR%\python.exe" (
    echo   ERROR: Python installer finished but python.exe not found.
    pause
    exit /b 1
)
set "PYTHON_EXE=%PYTHON_INSTALL_DIR%\python.exe"
for /f "tokens=2" %%V in ('"%PYTHON_EXE%" --version 2^>^&1') do set "PYVER=%%V"
echo       Installed Python !PYVER! into .tools\Python311\

:PYTHON_FOUND
echo       [OK] Python !PYVER!
echo.

:: ================================================================
:: STEP 2 -- Create virtual environment
:: ================================================================
echo [2/7] Setting up isolated virtual environment (.venv)...

if exist "%VENV_DIR%\Scripts\python.exe" (
    echo       Reusing existing .venv
) else (
    echo       Creating .venv...
    %PYTHON_EXE% -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo.
        echo   ERROR: Could not create virtual environment.
        echo   Try right-clicking build.bat and "Run as administrator".
        pause
        exit /b 1
    )
)
call "%VENV_DIR%\Scripts\activate.bat"
python -m pip install --upgrade pip setuptools wheel ^
    --quiet --no-warn-script-location
echo       [OK] Virtual environment ready
echo.

:: ================================================================
:: STEP 3 -- Install all Python packages
:: ================================================================
echo [3/7] Installing all Python packages...
echo.
echo       Package list:
echo         - Django (web framework)
echo         - cryptography (database encryption)
echo         - PySide6 (Qt desktop framework, ~200 MB)
echo         - pywebview (embedded browser window)
echo         - Pillow (image processing)
echo         - PyInstaller (build tool)
echo.
echo       First-time download is ~500 MB. Please wait...
echo.

pip install ^
    "Django>=4.2,<6.0" ^
    "cryptography>=41.0" ^
    "PySide6>=6.6,<6.9" ^
    "pywebview>=5.0" ^
    "qtpy>=2.4" ^
    "Pillow>=9.0" ^
    "pyinstaller>=6.0" ^
    "pyinstaller-hooks-contrib>=2024.0" ^
    --no-warn-script-location

if errorlevel 1 (
    echo.
    echo   +----------------------------------------------------------+
    echo   ^| ERROR: Package installation failed.                      ^|
    echo   ^|                                                          ^|
    echo   ^| Possible causes:                                         ^|
    echo   ^|   - No internet / firewall blocking pip                  ^|
    echo   ^|   - Not enough disk space (need ~3 GB free)              ^|
    echo   ^|   - Antivirus blocking downloads                         ^|
    echo   ^|                                                          ^|
    echo   ^| Fix the issue above, then re-run build.bat               ^|
    echo   +----------------------------------------------------------+
    pause
    exit /b 1
)

echo.
echo       Verifying packages...
set "PKG_ERRORS=0"
python -c "import django;      print('         Django      :', django.__version__)" || set "PKG_ERRORS=1"
python -c "import PySide6;     print('         PySide6     :', PySide6.__version__)" || set "PKG_ERRORS=1"
python -c "import webview;     print('         pywebview   : OK')" || set "PKG_ERRORS=1"
python -c "import PIL;         print('         Pillow      :', PIL.__version__)" || set "PKG_ERRORS=1"
python -c "import cryptography;print('         cryptography: OK')" || set "PKG_ERRORS=1"
python -c "import PyInstaller; print('         PyInstaller :', PyInstaller.__version__)" || set "PKG_ERRORS=1"

if "!PKG_ERRORS!"=="1" (
    echo.
    echo   ERROR: One or more packages failed to import.
    echo   Delete the .venv folder and re-run build.bat.
    pause
    exit /b 1
)
echo.
echo       [OK] All packages verified
echo.

:: ================================================================
:: STEP 4 -- Clean old artifacts
:: ================================================================
echo [4/7] Cleaning old build artifacts...
if exist "%SCRIPT_DIR%\build"    rmdir /s /q "%SCRIPT_DIR%\build"    2>nul
if exist "%DIST_DIR%\TindahanMo" rmdir /s /q "%DIST_DIR%\TindahanMo" 2>nul
del /s /q "%SCRIPT_DIR%\*.pyc" 2>nul
for /r "%SCRIPT_DIR%\store" %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D" 2>nul
for /r "%SCRIPT_DIR%\tindahan_project" %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D" 2>nul
for /r "%SCRIPT_DIR%\pysqlcipher3" %%D in (__pycache__) do if exist "%%D" rmdir /s /q "%%D" 2>nul
echo       [OK] Clean done
echo.

:: ================================================================
:: STEP 5 -- Generate app icons
:: ================================================================
echo [5/7] Generating app icons...
if exist "%SCRIPT_DIR%\logo.png"  (echo       Using custom logo.png) else ^
if exist "%SCRIPT_DIR%\logo.jpg"  (echo       Using custom logo.jpg) else ^
if exist "%SCRIPT_DIR%\logo.jpeg" (echo       Using custom logo.jpeg) else (
    echo       No logo file found -- using built-in store icon
    echo       Tip: place logo.png next to build.bat for a custom icon
)
python "%SCRIPT_DIR%\make_icon.py" "%SCRIPT_DIR%\tindahan_icon.png" 256
python "%SCRIPT_DIR%\make_icon.py" "%SCRIPT_DIR%\tindahan_icon.ico"
if not exist "%SCRIPT_DIR%\tindahan_icon.png" (
    echo   ERROR: Icon generation failed
    pause
    exit /b 1
)
echo       [OK] tindahan_icon.png + tindahan_icon.ico generated
echo.

:: ================================================================
:: STEP 6 -- Check Supabase config
:: ================================================================
echo [6/7] Checking cloud configuration...
findstr /C:"YOUR-PROJECT-ID" "%SCRIPT_DIR%\store\config.py" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo   +----------------------------------------------------------+
    echo   ^| WARNING: store\config.py has placeholder Supabase keys! ^|
    echo   ^|                                                          ^|
    echo   ^| Cloud sync will NOT work with placeholder values.        ^|
    echo   ^|                                                          ^|
    echo   ^| Edit store\config.py now (open with Notepad):            ^|
    echo   ^|   SUPABASE_URL = "https://xxxx.supabase.co"             ^|
    echo   ^|   SUPABASE_KEY = "eyJhbGc..."  (service_role key)       ^|
    echo   ^|                                                          ^|
    echo   ^| Then re-run build.bat to include real credentials.       ^|
    echo   +----------------------------------------------------------+
    echo.
    set /p CONT="Build anyway without cloud sync? [Y/n]: "
    if /i "!CONT!"=="n" exit /b 0
    echo.
) else (
    echo       [OK] Supabase credentials found in config.py
    echo.
)

:: ================================================================
:: STEP 7 -- Build with PyInstaller
:: ================================================================
echo [7/7] Building TindahanMo.exe...
echo       Bundling Python + Django + Qt into a standalone EXE...
echo       This takes 5-15 minutes on first run. Please wait.
echo.

cd /d "%SCRIPT_DIR%"
pyinstaller tindahan_windows.spec ^
    --distpath "%DIST_DIR%" ^
    --workpath "%SCRIPT_DIR%\build" ^
    --noconfirm ^
    --clean

if errorlevel 1 (
    echo.
    echo   +----------------------------------------------------------+
    echo   ^| ERROR: PyInstaller build failed.                         ^|
    echo   ^|                                                          ^|
    echo   ^| Most common fix: temporarily disable Windows Defender    ^|
    echo   ^| real-time protection, then re-run build.bat              ^|
    echo   ^| (PyInstaller is often a false positive)                  ^|
    echo   ^|                                                          ^|
    echo   ^| Other fixes:                                             ^|
    echo   ^|   - Run as Administrator                                 ^|
    echo   ^|   - Free up disk space (need 3+ GB)                      ^|
    echo   ^|   - Delete .venv folder and re-run                       ^|
    echo   +----------------------------------------------------------+
    pause
    exit /b 1
)

set "APP_FOLDER=%DIST_DIR%\TindahanMo"
if not exist "%APP_FOLDER%\TindahanMo.exe" (
    echo   ERROR: TindahanMo.exe not found after build.
    pause
    exit /b 1
)

:: ================================================================
:: SUCCESS
:: ================================================================
echo.
echo   +============================================================+
echo   ^|                                                            ^|
echo   ^|   BUILD COMPLETE!                                          ^|
echo   ^|                                                            ^|
echo   ^|   EXE location: dist\TindahanMo\TindahanMo.exe            ^|
echo   ^|                                                            ^|
echo   ^|   To LAUNCH: double-click TindahanMo.exe                  ^|
echo   ^|   To SHARE : ZIP the entire dist\TindahanMo\ folder       ^|
echo   ^|   To INSTALL: run build_installer.bat (needs Inno Setup)  ^|
echo   ^|                                                            ^|
echo   ^|   Store data is saved to:                                  ^|
echo   ^|   %%APPDATA%%\TindahanMo\                                 ^|
echo   ^|   (survives app updates and uninstall)                     ^|
echo   ^|                                                            ^|
echo   +============================================================+
echo.

set /p OPEN="Open the output folder? [Y/n]: "
if /i not "!OPEN!"=="n" explorer "%APP_FOLDER%"

pause
exit /b 0
