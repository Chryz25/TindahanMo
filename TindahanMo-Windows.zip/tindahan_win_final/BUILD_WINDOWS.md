# Tindahan Mo — Windows 10/11 Build Guide

Complete step-by-step instructions for building and distributing the app.

---

## What You Get After Building

```
dist\TindahanMo\
    TindahanMo.exe          ← double-click to launch
    _internal\              ← Qt, Django, Python runtime (do not delete)
```

The **entire `dist\TindahanMo\` folder** is the distributable app.
No Python installation is needed on machines that *run* the app.
Copy the folder anywhere, or ZIP it and send it to store owners.

---

## Build Machine Requirements

| Requirement | Version | Notes |
|---|---|---|
| Windows | 10 or 11 (64-bit) | Build must run on Windows |
| Python | **3.10 or 3.11** | ✅ Recommended |
| Internet | Required for first build | Downloads ~500 MB of packages |

### Install Python (if not already installed)

1. Go to **https://python.org/downloads** → download Python 3.11
2. Run the installer
3. ☑ Check **"Add Python to PATH"** (critical!)
4. ☑ Check **"Install for all users"** (recommended)
5. Click Install Now

Verify it worked — open Command Prompt and type:
```
python --version
```
You should see `Python 3.11.x`.

---

## Step 1 — Edit Your Supabase Credentials

Before building, open `store\config.py` in Notepad and fill in your two values:

```python
SUPABASE_URL = "https://YOUR-PROJECT-ID.supabase.co"   # ← paste here
SUPABASE_KEY = "eyJhbGc..."                             # ← paste here
```

**Where to find these values:**
1. Go to https://supabase.com → your project → **Settings → API**
2. Copy **Project URL** → paste as `SUPABASE_URL`
3. Copy **service_role secret** key → paste as `SUPABASE_KEY` (NOT the anon key)

> The credentials are baked into the EXE. Store owners never see or type them.

---

## Step 2 — (Optional) Add Your Custom Logo

Drop your store logo next to `build.bat`:

```
logo.png    ← preferred (PNG with transparency works best)
logo.jpg    ← also accepted
```

The icon will appear in the taskbar, window title bar, Start Menu shortcut,
and on the loading screen. If no logo is provided, the built-in store icon is used.

---

## Step 3 — Run the Build

**Double-click `build.bat`** — or from Command Prompt:

```cmd
cd C:\Users\YourName\Desktop\TindahanMo-Windows
build.bat
```

The script will:
1. ✅ Check Python version
2. ✅ Create a virtual environment (`.venv\`)
3. ✅ Install all packages (~500 MB, takes 3–10 min first time)
4. ✅ Generate `tindahan_icon.png` + `tindahan_icon.ico`
5. ✅ Clean old build artifacts
6. ✅ Run PyInstaller (5–15 min first time)
7. ✅ Show `dist\TindahanMo\TindahanMo.exe` when done

Subsequent builds are **much faster** (the `.venv` is reused).

---

## Step 4 — Test the App

Double-click `dist\TindahanMo\TindahanMo.exe`.

The first launch takes ~5 seconds (database initialisation).
You should see the loading screen, then the store setup wizard.

---

## Step 5 — Distribute

**Option A — Simple ZIP (recommended for most cases)**

Right-click `dist\TindahanMo\` → Send to → Compressed (zipped) folder.
Send `TindahanMo.zip` to the store owner. They unzip and double-click the EXE.

**Option B — Installer EXE**

1. Install [Inno Setup 6](https://jrsoftware.org/isdl.php) (free)
2. Double-click `build_installer.bat`
3. Get `dist\TindahanMo-Setup.exe` — a proper Windows installer with:
   - Start Menu shortcut
   - Desktop shortcut
   - Add/Remove Programs entry
   - One-click uninstall

---

## Where User Data Is Stored

All store data lives in:
```
C:\Users\<username>\AppData\Roaming\TindahanMo\
    tindahan_secure.db       ← encrypted business database (AES-256)
    tindahan_secure.db.salt  ← encryption key material (NEVER delete)
    django_sessions.db       ← login sessions
    media\                   ← product images, avatars, logos
```

> **Important:** Never delete `tindahan_secure.db.salt`. If it's deleted,
> the database becomes permanently unreadable. Back it up with the `.db` file.

---

## Troubleshooting

### "Python not found"
Re-install Python and check "Add Python to PATH" during setup.
Then open a **new** Command Prompt window.

### "Failed to create virtual environment"
Run Command Prompt as Administrator and try again.

### App opens but shows a black/white screen
This is usually a WebView2 / GPU issue. Try:
1. Update Windows (Settings → Windows Update)
2. Install [Microsoft Edge WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)

### "Access is denied" errors during build
Disable Windows Defender real-time scanning for the project folder, or
add the folder as an exclusion in Windows Security settings.
PyInstaller is frequently flagged as a false positive.

### Antivirus quarantines the EXE
This is a known false positive with PyInstaller-built apps.
Add `dist\TindahanMo\` as an exclusion in your antivirus software.

### App data reset / lost
The `.venv\` folder can be deleted (it's just packages). 
Never delete `%APPDATA%\TindahanMo\tindahan_secure.db` or its `.salt` file.

---

## File Reference

| File | Purpose |
|---|---|
| `launcher_windows.py` | Main app entry point (Windows-specific) |
| `tindahan_windows.spec` | PyInstaller build configuration |
| `build.bat` | One-click build script |
| `build_installer.bat` | Creates `.exe` installer via Inno Setup |
| `dev_run.bat` | Run app directly without building (for testing) |
| `make_icon.py` | Generates PNG + ICO app icons |
| `make_installer_iss.py` | Generates Inno Setup script |
| `store/config.py` | **Your Supabase URL + key — edit this!** |
| `store/views.py` | Django API endpoints |
| `store/sync.py` | Background cloud sync engine |
| `store/db.py` | Local encrypted DB helpers |
| `pysqlcipher3/` | AES-256 SQLite encryption shim |
| `supabase_schema.sql` | Run this in Supabase SQL Editor once |
| `CLOUD_SETUP.md` | Supabase setup guide |
| `requirements_windows.txt` | Python packages list |
