"""
pysqlcipher3 — AES-256 encrypted SQLite shim.
All real code lives in dbapi2.py so that the standard import works:

    from pysqlcipher3 import dbapi2 as sqlite
"""
from pysqlcipher3.dbapi2 import (
    connect, Connection, Cursor,
    Row, OperationalError, IntegrityError, DatabaseError, Error,
    paramstyle, threadsafety, apilevel,
)

__all__ = [
    "connect", "Connection", "Cursor",
    "Row", "OperationalError", "IntegrityError", "DatabaseError", "Error",
    "paramstyle", "threadsafety", "apilevel",
]
