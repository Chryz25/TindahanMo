"""
pysqlcipher3 / dbapi2  —  AES-256 encrypted SQLite shim  (v2 — robust)
=======================================================================
v2 FIXES vs original:
  - _flush(): NEVER silently swallows errors (was: except Exception: pass)
  - _flush(): os.fsync() ensures OS actually writes to physical storage
  - _open():  raises RuntimeError if decryption of EXISTING DB fails
              instead of silently copying encrypted binary as "plaintext"
  - _open():  raises RuntimeError if salt file is missing for existing DB
              instead of generating a new salt and permanently losing data
"""

import os, shutil, sqlite3, tempfile, traceback
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
import base64

Row = sqlite3.Row; OperationalError = sqlite3.OperationalError
IntegrityError = sqlite3.IntegrityError; DatabaseError = sqlite3.DatabaseError
Error = sqlite3.Error; paramstyle = sqlite3.paramstyle
threadsafety = sqlite3.threadsafety; apilevel = sqlite3.apilevel


def _make_fernet(passphrase, salt):
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=260_000)
    return Fernet(base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8"))))

def _salt_path(p): return p + ".salt"

def _pragma_val(sql):
    a, b = sql.find("'"), sql.rfind("'")
    return sql[a+1:b] if 0 <= a < b else ""


class Cursor:
    def __init__(self, inner, conn): self._c, self._conn = inner, conn
    @property
    def lastrowid(self):   return self._c.lastrowid
    @property
    def rowcount(self):    return self._c.rowcount
    @property
    def description(self): return self._c.description
    def execute(self, sql, params=()):
        if self._conn._intercept(sql): return self
        self._c.execute(sql, params); return self
    def executemany(self, sql, seq): self._c.executemany(sql, seq); return self
    def fetchone(self):       return self._c.fetchone()
    def fetchall(self):       return self._c.fetchall()
    def fetchmany(self, n=1): return self._c.fetchmany(n)
    def __iter__(self):       return iter(self._c)
    def close(self):          self._c.close()


class Connection:
    def __init__(self, db_path):
        self._db   = os.path.abspath(db_path)
        self._fern = None; self._tmp = None; self._inner = None
        self._pend = True; self.row_factory = sqlite3.Row

    def _intercept(self, sql):
        u = sql.strip().upper()
        if u.startswith("PRAGMA KEY"):
            self._open(_pragma_val(sql)); return True
        if u.startswith("PRAGMA REKEY") or u.startswith("PRAGMA RE-KEY"):
            phrase = _pragma_val(sql); salt = os.urandom(16)
            with open(_salt_path(self._db), "wb") as f: f.write(salt)
            self._fern = _make_fernet(phrase, salt); return True
        return False

    def _open(self, phrase):
        sp = _salt_path(self._db)
        fd, tmp = tempfile.mkstemp(suffix=".sc_plain.db")
        os.close(fd); self._tmp = tmp
        db_exists = os.path.exists(self._db) and os.path.getsize(self._db) > 0

        if db_exists:
            # ── Existing DB: must decrypt correctly ──────────────────────────
            if not os.path.exists(sp):
                raise RuntimeError(
                    f"[TindahanMo] Salt file missing: {sp}\n"
                    "Cannot open existing database without its salt file.\n"
                    "To reset the app delete both the .db and .salt files."
                )
            with open(sp, "rb") as f: salt = f.read()
            self._fern = _make_fernet(phrase, salt)
            with open(self._db, "rb") as f: cipher = f.read()
            try:
                plain = self._fern.decrypt(cipher)
                with open(tmp, "wb") as f: f.write(plain)
            except (InvalidToken, Exception) as exc:
                # NEVER silently fall back to treating encrypted binary as SQLite
                raise RuntimeError(
                    f"[TindahanMo] Decryption failed for {self._db}: {exc}\n"
                    "The database file may be corrupt.\n"
                    "To reset the app delete both the .db and .salt files."
                ) from exc
        else:
            # ── New DB: generate fresh salt ───────────────────────────────────
            salt = os.urandom(16)
            with open(sp, "wb") as f: f.write(salt)
            self._fern = _make_fernet(phrase, salt)
            # self._tmp is already an empty file; SQLite will initialise it

        self._inner = sqlite3.connect(tmp, check_same_thread=False)
        self._inner.row_factory = sqlite3.Row
        self._inner.execute("PRAGMA journal_mode=DELETE")
        self._inner.execute("PRAGMA foreign_keys=ON")
        self._pend = False

    def _flush(self):
        """Re-encrypt the plaintext temp file back to the encrypted DB on disk.
        Calls fsync() so the OS actually persists the data.
        Raises (and logs) on failure instead of silently swallowing errors."""
        if not self._fern or not self._tmp: return
        try:
            self._inner.commit()                        # flush SQLite WAL→temp
            with open(self._tmp, "rb") as f: plain = f.read()
            cipher = self._fern.encrypt(plain)
            db_dir = os.path.dirname(self._db) or "."
            fd, enc_tmp = tempfile.mkstemp(dir=db_dir, suffix=".enc_tmp")
            try:
                os.write(fd, cipher)
                os.fsync(fd)                            # ensure kernel flushes
                os.close(fd)
                os.replace(enc_tmp, self._db)           # atomic rename
            except Exception:
                try: os.close(fd)
                except Exception: pass
                try: os.unlink(enc_tmp)
                except Exception: pass
                raise
        except Exception as exc:
            print(f"[TindahanMo] ERROR in _flush(): {exc}", flush=True)
            traceback.print_exc()

    def _cleanup(self):
        if self._tmp:
            try: os.unlink(self._tmp)
            except Exception: pass
            self._tmp = None

    def _chk(self):
        if self._pend:
            raise OperationalError("Execute PRAGMA key='...' before any SQL.")

    def cursor(self):      self._chk(); return Cursor(self._inner.cursor(), self)

    def execute(self, sql, params=()):
        if self._intercept(sql):
            return Cursor(sqlite3.connect(":memory:").cursor(), self)
        self._chk(); return Cursor(self._inner.execute(sql, params), self)

    def executemany(self, sql, seq):
        self._chk(); self._inner.executemany(sql, seq)

    def commit(self):
        if self._inner: self._flush()

    def rollback(self):
        if self._inner: self._inner.rollback()

    def close(self):
        if self._inner:
            self._flush(); self._inner.close(); self._inner = None
        self._cleanup()

    def __enter__(self): return self
    def __exit__(self, *_): self.close()

    def __setattr__(self, n, v):
        if n == "row_factory" and hasattr(self, "_inner") and self._inner:
            self._inner.row_factory = v
        object.__setattr__(self, n, v)


def connect(database, **_): return Connection(str(database))
