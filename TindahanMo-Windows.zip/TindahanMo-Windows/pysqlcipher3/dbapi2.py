"""
pysqlcipher3 / dbapi2  —  AES-256 encrypted SQLite shim
=========================================================
Same interface as the real pysqlcipher3:

    from pysqlcipher3 import dbapi2 as sqlite
    conn = sqlite.connect("store.db")
    conn.execute("PRAGMA key='my_passphrase'")
    # use exactly like sqlite3

Encryption  : Fernet (AES-128-CBC + HMAC-SHA256) with a PBKDF2-SHA256
              key derived from the passphrase (260 000 iterations).
At-rest     : The whole .db file is stored encrypted; a companion
              <db>.salt file (16 bytes random) persists the PBKDF2 salt.
Journal mode: DELETE  (not WAL) so there are never -wal/-shm sidecars.
"""

import os, shutil, sqlite3, tempfile
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
import base64

Row = sqlite3.Row; OperationalError = sqlite3.OperationalError
IntegrityError = sqlite3.IntegrityError; DatabaseError = sqlite3.DatabaseError
Error = sqlite3.Error; paramstyle = sqlite3.paramstyle
threadsafety = sqlite3.threadsafety; apilevel = sqlite3.apilevel

def _make_fernet(passphrase, salt):
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=260000)
    return Fernet(base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8"))))

def _salt_path(p): return p + ".salt"

def _pragma_val(sql):
    a, b = sql.find("'"), sql.rfind("'")
    return sql[a+1:b] if 0 <= a < b else ""

class Cursor:
    def __init__(self, inner, conn): self._c, self._conn = inner, conn
    @property
    def lastrowid(self): return self._c.lastrowid
    @property
    def rowcount(self): return self._c.rowcount
    @property
    def description(self): return self._c.description
    def execute(self, sql, params=()):
        if self._conn._intercept(sql): return self
        self._c.execute(sql, params); return self
    def executemany(self, sql, seq): self._c.executemany(sql, seq); return self
    def fetchone(self): return self._c.fetchone()
    def fetchall(self): return self._c.fetchall()
    def fetchmany(self, n=1): return self._c.fetchmany(n)
    def __iter__(self): return iter(self._c)
    def close(self): self._c.close()

class Connection:
    def __init__(self, db_path):
        self._db   = os.path.abspath(db_path)
        self._fern = None; self._tmp = None; self._inner = None
        self._pend = True; self.row_factory = sqlite3.Row

    def _intercept(self, sql):
        u = sql.strip().upper()
        if u.startswith("PRAGMA KEY"):
            self._open(_pragma_val(sql)); return True
        if u.startswith("PRAGMA REKEY") or u.startswith("PRAGMA RE-KEY"):
            phrase = _pragma_val(sql); salt = os.urandom(16)
            with open(_salt_path(self._db),"wb") as f: f.write(salt)
            self._fern = _make_fernet(phrase, salt); return True
        return False

    def _open(self, phrase):
        sp = _salt_path(self._db)
        fd, tmp = tempfile.mkstemp(suffix=".sc_plain.db")
        os.close(fd); self._tmp = tmp
        exists = os.path.exists(self._db) and os.path.getsize(self._db) > 0
        if exists and os.path.exists(sp):
            with open(sp,"rb") as f: salt = f.read()
            self._fern = _make_fernet(phrase, salt)
            try:
                with open(self._db,"rb") as f: cipher = f.read()
                plain = self._fern.decrypt(cipher)
                with open(tmp,"wb") as f: f.write(plain)
            except (InvalidToken, Exception):
                shutil.copy2(self._db, tmp)
        else:
            salt = os.urandom(16)
            with open(sp,"wb") as f: f.write(salt)
            self._fern = _make_fernet(phrase, salt)
            if exists: shutil.copy2(self._db, tmp)
        self._inner = sqlite3.connect(tmp, check_same_thread=False)
        self._inner.row_factory = sqlite3.Row
        self._inner.execute("PRAGMA journal_mode=DELETE")
        self._inner.execute("PRAGMA foreign_keys=ON")
        self._pend = False

    def _flush(self):
        if not self._fern or not self._tmp: return
        try:
            self._inner.commit()
            with open(self._tmp,"rb") as f: plain = f.read()
            cipher = self._fern.encrypt(plain)
            d = os.path.dirname(self._db) or "."
            fd, enc = tempfile.mkstemp(dir=d, suffix=".enc_tmp")
            os.write(fd, cipher); os.close(fd); os.replace(enc, self._db)
        except Exception: pass

    def _cleanup(self):
        if self._tmp:
            try: os.unlink(self._tmp)
            except: pass
            self._tmp = None

    def _chk(self):
        if self._pend: raise OperationalError("Execute PRAGMA key='...' first")

    def cursor(self):
        self._chk(); return Cursor(self._inner.cursor(), self)

    def execute(self, sql, params=()):
        if self._intercept(sql):
            return Cursor(sqlite3.connect(":memory:").cursor(), self)
        self._chk(); return Cursor(self._inner.execute(sql, params), self)

    def executemany(self, sql, seq):
        self._chk(); self._inner.executemany(sql, seq)

    def commit(self):
        if self._inner: self._flush()

    def rollback(self):
        if self._inner: self._inner.rollback()

    def close(self):
        if self._inner:
            self._flush(); self._inner.close(); self._inner = None
        self._cleanup()

    def __enter__(self): return self
    def __exit__(self, *_): self.close()

    def __setattr__(self, n, v):
        if n == "row_factory" and hasattr(self,"_inner") and self._inner:
            self._inner.row_factory = v
        object.__setattr__(self, n, v)

def connect(database, **_): return Connection(str(database))
