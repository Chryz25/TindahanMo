from django.apps import AppConfig


class StoreConfig(AppConfig):
    name = "store"
    verbose_name = "Tindahan Mo Store"

    def ready(self):
        """Initialise the encrypted business database once Django is fully loaded."""
        from .db import init_db
        init_db()
