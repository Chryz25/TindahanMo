"""
store/db.py
===========
All database helpers for the encrypted business database.
Uses pysqlcipher3 (AES-256) — see pysqlcipher3/dbapi2.py.
"""

import sys
import os

# Make sure the local pysqlcipher3 package is importable regardless of CWD.
_base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _base not in sys.path:
    sys.path.insert(0, _base)

from django.conf import settings
from pysqlcipher3 import dbapi2 as sqlite  # noqa: E402


# ── Connection helper ──────────────────────────────────────────────────────────
def get_db():
    """Open and return an authenticated connection to the encrypted database."""
    conn = sqlite.connect(settings.TINDAHAN_DB_PATH)
    conn.execute(f"PRAGMA key='{settings.TINDAHAN_DB_KEY}'")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ── Row → dict helpers ─────────────────────────────────────────────────────────
def p2d(r):
    """Product row → dict."""
    return {
        "id": r["id"],
        "name": r["name"],
        "category": r["category"],
        "price": r["price"],
        "stock": r["stock"],
        "reorderLevel": r["reorder_level"],
        "image": r["image"] if r["image"] else None,
    }


def u2d(r):
    """User row → dict (password included for owner screens)."""
    return {
        "id": r["id"],
        "username": r["username"],
        "fullName": r["full_name"],
        "role": r["role"],
        "active": bool(r["active"]),
        "password": r["password"],
        "avatar": r["avatar"] if r["avatar"] else None,
    }


def s2d(r):
    """Sale row → dict."""
    return {
        "id": r["id"],
        "productId": r["product_id"],
        "productName": r["product_name"],
        "qty": r["qty"],
        "total": r["total"],
        "date": r["date"],
        "cashier": r["cashier"],
        "time": r["time"],
        "receiptNo": r["receipt_no"],
        "amountTendered": r["amount_tendered"] if r["amount_tendered"] is not None else None,
        "changeGiven": r["change_given"] if r["change_given"] is not None else None,
    }


# ── DB initialisation ──────────────────────────────────────────────────────────
def init_db():
    """Create tables and seed data if the database is brand new."""
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            username  TEXT UNIQUE NOT NULL,
            password  TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role      TEXT NOT NULL DEFAULT 'Cashier',
            active    INTEGER NOT NULL DEFAULT 1,
            avatar    TEXT DEFAULT NULL
        )""")

    # Migrate: add avatar column if missing
    try:
        conn.execute("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT NULL")
        conn.commit()
    except Exception:
        pass

    conn.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT NOT NULL,
            category      TEXT NOT NULL,
            price         REAL NOT NULL,
            stock         INTEGER NOT NULL DEFAULT 0,
            reorder_level INTEGER NOT NULL DEFAULT 10,
            image         TEXT DEFAULT NULL
        )""")

    # ── Migrate: add image column if it doesn't exist yet ─────────────────────
    try:
        conn.execute("ALTER TABLE products ADD COLUMN image TEXT DEFAULT NULL")
        conn.commit()
    except Exception:
        pass  # column already exists

    conn.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )""")

    # ── Seed categories from the default product list if table is empty ────────
    if conn.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
        default_cats = [
            "Instant Noodles", "Condiments", "Dairy", "Snacks",
            "Beverages", "Personal Care", "Tobacco", "Household",
        ]
        conn.executemany(
            "INSERT OR IGNORE INTO categories (name) VALUES (?)",
            [(c,) for c in default_cats],
        )

    # ON DELETE CASCADE removes all sales when a cashier user-row is deleted.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id      INTEGER,
            product_name    TEXT NOT NULL,
            qty             INTEGER NOT NULL,
            total           REAL NOT NULL,
            date            TEXT NOT NULL,
            cashier         TEXT NOT NULL,
            cashier_id      INTEGER REFERENCES users(id) ON DELETE CASCADE,
            time            TEXT NOT NULL,
            receipt_no      TEXT NOT NULL,
            amount_tendered REAL DEFAULT NULL,
            change_given    REAL DEFAULT NULL
        )""")

    # Migrate: add payment columns if missing
    for col, default in [("amount_tendered", "NULL"), ("change_given", "NULL")]:
        try:
            conn.execute(f"ALTER TABLE sales ADD COLUMN {col} REAL DEFAULT {default}")
            conn.commit()
        except Exception:
            pass

    # ── Seed users ─────────────────────────────────────────────────────────────
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO users (username, password, full_name, role, active)"
            " VALUES (?, ?, ?, ?, ?)",
            [
                ("owner", "owner123",  "Store Owner",  "Store Owner", 1),
                ("maria", "maria123",  "Maria Santos", "Cashier",     1),
                ("jose",  "jose123",   "Jose Reyes",   "Cashier",     1),
            ],
        )

    # ── Seed products ──────────────────────────────────────────────────────────
    if conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO products (name, category, price, stock, reorder_level)"
            " VALUES (?, ?, ?, ?, ?)",
            [
                ("Lucky Me Pancit Canton",  "Instant Noodles", 15, 48, 10),
                ("Mang Tomas Sarsa",         "Condiments",      25,  7, 10),
                ("Bear Brand Milk (small)",  "Dairy",           12, 60, 20),
                ("Piattos Cheese",           "Snacks",          25,  3, 10),
                ("Kopiko Coffee 3-in-1",     "Beverages",        8, 90, 20),
                ("Safeguard Soap (bar)",     "Personal Care",   40, 22,  8),
                ("Sky Flakes Crackers",      "Snacks",          10, 35, 12),
                ("Marlboro Red (stick)",     "Tobacco",          7, 120, 30),
                ("C2 Apple Green Tea",       "Beverages",       20, 18, 15),
                ("Ariel Powder (sachet)",    "Household",        6, 55, 20),
            ],
        )

    # ── Seed sales ─────────────────────────────────────────────────────────────
    if conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 0:
        maria_id = conn.execute(
            "SELECT id FROM users WHERE username='maria'"
        ).fetchone()["id"]
        jose_id = conn.execute(
            "SELECT id FROM users WHERE username='jose'"
        ).fetchone()["id"]
        conn.executemany(
            "INSERT INTO sales"
            " (product_id, product_name, qty, total, date, cashier, cashier_id, time, receipt_no)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                (1, "Lucky Me Pancit Canton",  3,  45, "2026-03-01", "Maria Santos", maria_id, "09:15 AM", "RCP-0001"),
                (5, "Kopiko Coffee 3-in-1",   10,  80, "2026-03-01", "Maria Santos", maria_id, "10:30 AM", "RCP-0002"),
                (3, "Bear Brand Milk (small)", 5,  60, "2026-03-02", "Jose Reyes",   jose_id,  "08:45 AM", "RCP-0003"),
                (8, "Marlboro Red (stick)",   20, 140, "2026-03-02", "Maria Santos", maria_id, "02:10 PM", "RCP-0004"),
                (7, "Sky Flakes Crackers",     6,  60, "2026-03-03", "Jose Reyes",   jose_id,  "11:20 AM", "RCP-0005"),
                (9, "C2 Apple Green Tea",      4,  80, "2026-03-03", "Maria Santos", maria_id, "03:55 PM", "RCP-0006"),
            ],
        )

    conn.execute("""
        CREATE TABLE IF NOT EXISTS store_settings (
            id         INTEGER PRIMARY KEY CHECK (id = 1),
            store_name TEXT NOT NULL DEFAULT 'Tindahan Mo',
            tagline    TEXT DEFAULT '',
            logo_url   TEXT DEFAULT NULL,
            setup_done INTEGER NOT NULL DEFAULT 0
        )""")

    # Seed a row with setup_done=0 so the Welcome wizard always appears
    # on a brand-new database. INSERT OR IGNORE never overwrites an existing
    # row, so a store that was already set up is left untouched.
    conn.execute("""
        INSERT OR IGNORE INTO store_settings (id, store_name, tagline, logo_url, setup_done)
        VALUES (1, 'Tindahan Mo', '', NULL, 0)
    """)

    conn.commit()
    conn.close()
    print(f"✅  Encrypted database ready → {settings.TINDAHAN_DB_PATH}")


def c2d(r):
    """Category row → dict."""
    return {"id": r["id"], "name": r["name"]}


def ss2d(r):
    """Store settings row → dict."""
    if not r:
        return {"storeName": "Tindahan Mo", "tagline": "", "logoUrl": None, "setupDone": False}
    return {
        "storeName": r["store_name"],
        "tagline":   r["tagline"] or "",
        "logoUrl":   r["logo_url"] if r["logo_url"] else None,
        "setupDone": bool(r["setup_done"]),
    }
