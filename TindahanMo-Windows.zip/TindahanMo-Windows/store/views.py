"""
store/views.py — Django views with product image upload support.
"""

import json
import os
import uuid
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from .db import get_db, p2d, u2d, s2d, c2d, ss2d


def _body(request):
    try:
        return json.loads(request.body)
    except (json.JSONDecodeError, ValueError):
        return {}


def _guard(request, owner=False):
    if "uid" not in request.session:
        return JsonResponse({"error": "Unauthorized"}, status=401)
    if owner and request.session.get("role") != "Store Owner":
        return JsonResponse({"error": "Forbidden — Owner only"}, status=403)
    return None


def _save_image(image_file, old_url=None):
    """Save uploaded image; delete old one. Returns relative URL or None."""
    if not image_file:
        return None
    allowed = {"image/jpeg", "image/png", "image/gif", "image/webp"}
    ct = getattr(image_file, "content_type", "image/jpeg")
    if ct not in allowed:
        return None
    ext = Path(image_file.name).suffix.lower() or ".jpg"
    filename = uuid.uuid4().hex + ext
    products_dir = Path(settings.MEDIA_ROOT) / "products"
    products_dir.mkdir(parents=True, exist_ok=True)
    with open(products_dir / filename, "wb") as f:
        for chunk in image_file.chunks():
            f.write(chunk)
    if old_url:
        try:
            old_path = Path(settings.MEDIA_ROOT) / old_url.replace("/media/", "", 1)
            if old_path.exists():
                old_path.unlink()
        except Exception:
            pass
    return f"/media/products/{filename}"


def _save_avatar(image_file, old_url=None):
    """Save user avatar image; deletes old file. Returns URL or None."""
    if not image_file:
        return None
    allowed = {"image/jpeg","image/png","image/gif","image/webp"}
    ct = getattr(image_file, "content_type", "image/jpeg")
    if ct not in allowed:
        return None
    ext = Path(image_file.name).suffix.lower() or ".jpg"
    filename = uuid.uuid4().hex + ext
    avatars_dir = Path(settings.MEDIA_ROOT) / "avatars"
    avatars_dir.mkdir(parents=True, exist_ok=True)
    with open(avatars_dir / filename, "wb") as f:
        for chunk in image_file.chunks():
            f.write(chunk)
    if old_url:
        try:
            old_path = Path(settings.MEDIA_ROOT) / old_url.replace("/media/", "", 1)
            if old_path.exists():
                old_path.unlink()
        except Exception:
            pass
    return f"/media/avatars/{filename}"


def _parse_product_request(request):
    """
    Parse product fields + optional image from multipart or JSON.
    Django only auto-populates request.POST/FILES for POST — for PUT
    we must manually invoke MultiPartParser.
    """
    ct = request.content_type or ""
    if "multipart" in ct:
        if request.method == "POST":
            return request.POST, request.FILES.get("image")
        # PUT — parse manually
        from django.http.multipartparser import MultiPartParser
        post_data, file_data = MultiPartParser(
            request.META, request, request.upload_handlers
        ).parse()
        return post_data, file_data.get("image")
    return _body(request), None


# ── Frontend ───────────────────────────────────────────────────────────────────
def index(request):
    return render(request, "store/index.html")


# ── Auth ───────────────────────────────────────────────────────────────────────
@csrf_exempt
def me(request):
    if request.method == "GET":
        if "uid" not in request.session:
            return JsonResponse(None, safe=False)
        conn = get_db()
        row = conn.execute("SELECT * FROM users WHERE id=?", (request.session["uid"],)).fetchone()
        conn.close()
        return JsonResponse(u2d(row) if row else None, safe=False)
    if request.method == "PUT":
        err = _guard(request)
        if err: return err
        d, avatar_file = _parse_product_request(request)
        full_name = (d.get("fullName") or "").strip()
        password  = (d.get("password") or "").strip()
        if not full_name or not password:
            return JsonResponse({"error": "Name and password are required"}, status=400)
        conn = get_db()
        old_row = conn.execute("SELECT avatar FROM users WHERE id=?",
                               (request.session["uid"],)).fetchone()
        new_avatar = _save_avatar(avatar_file, old_row["avatar"] if old_row else None)
        if new_avatar:
            conn.execute("UPDATE users SET full_name=?,password=?,avatar=? WHERE id=?",
                         (full_name, password, new_avatar, request.session["uid"]))
        else:
            conn.execute("UPDATE users SET full_name=?,password=? WHERE id=?",
                         (full_name, password, request.session["uid"]))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?",
                           (request.session["uid"],)).fetchone()
        conn.close()
        u = u2d(row)
        return JsonResponse(u)
    return JsonResponse({"error": "Method not allowed"}, status=405)


@csrf_exempt
@require_http_methods(["POST"])
def login(request):
    d = _body(request)
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM users WHERE username=? AND password=? AND active=1",
        (d.get("username", ""), d.get("password", ""))
    ).fetchone()
    conn.close()
    if not row:
        return JsonResponse({"error": "Invalid username or password"}, status=401)
    request.session["uid"]  = row["id"]
    request.session["role"] = row["role"]
    request.session.save()
    return JsonResponse(u2d(row))


@csrf_exempt
@require_http_methods(["POST"])
def logout(request):
    request.session.flush()
    return JsonResponse({"ok": True})


# ── Products ───────────────────────────────────────────────────────────────────
@csrf_exempt
def products(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
        conn.close()
        return JsonResponse([p2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d, image_file = _parse_product_request(request)
        image_url = _save_image(image_file)
        conn = get_db()
        cur = conn.execute(
            "INSERT INTO products (name,category,price,stock,reorder_level,image) VALUES (?,?,?,?,?,?)",
            (d.get("name",""), d.get("category",""), float(d.get("price",0)),
             int(d.get("stock",0)), int(d.get("reorderLevel",10)), image_url)
        )
        conn.commit()
        row = conn.execute("SELECT * FROM products WHERE id=?", (cur.lastrowid,)).fetchone()
        conn.close()
        return JsonResponse(p2d(row), status=201)

    return JsonResponse({"error": "Method not allowed"}, status=405)


@csrf_exempt
def product_detail(request, pid):
    if request.method == "PUT":
        err = _guard(request, owner=True)
        if err: return err
        d, image_file = _parse_product_request(request)
        conn = get_db()
        old_row = conn.execute("SELECT image FROM products WHERE id=?", (pid,)).fetchone()
        old_image = old_row["image"] if old_row else None
        new_image_url = _save_image(image_file, old_image)
        if new_image_url:
            conn.execute(
                "UPDATE products SET name=?,category=?,price=?,stock=?,reorder_level=?,image=? WHERE id=?",
                (d.get("name",""), d.get("category",""), float(d.get("price",0)),
                 int(d.get("stock",0)), int(d.get("reorderLevel",10)), new_image_url, pid)
            )
        else:
            conn.execute(
                "UPDATE products SET name=?,category=?,price=?,stock=?,reorder_level=? WHERE id=?",
                (d.get("name",""), d.get("category",""), float(d.get("price",0)),
                 int(d.get("stock",0)), int(d.get("reorderLevel",10)), pid)
            )
        conn.commit()
        row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        conn.close()
        return JsonResponse(p2d(row))

    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        conn = get_db()
        row = conn.execute("SELECT image FROM products WHERE id=?", (pid,)).fetchone()
        if row and row["image"]:
            try:
                img_path = Path(settings.MEDIA_ROOT) / row["image"].replace("/media/","",1)
                if img_path.exists(): img_path.unlink()
            except Exception: pass
        conn.execute("DELETE FROM products WHERE id=?", (pid,))
        conn.commit()
        conn.close()
        return JsonResponse({"ok": True})

    return JsonResponse({"error": "Method not allowed"}, status=405)


# ── Sales ──────────────────────────────────────────────────────────────────────
@csrf_exempt
def sales(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM sales ORDER BY date DESC, id DESC").fetchall()
        conn.close()
        return JsonResponse([s2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request)
        if err: return err
        d = _body(request)
        now = datetime.now()
        date_str, time_str = now.strftime("%Y-%m-%d"), now.strftime("%I:%M %p")
        receipt_no   = "RCP-" + uuid.uuid4().hex[:6].upper()
        cashier_name = d.get("cashier", "")
        conn = get_db()
        cashier_row = conn.execute("SELECT id FROM users WHERE full_name=?", (cashier_name,)).fetchone()
        cashier_id = cashier_row["id"] if cashier_row else None
        saved = []
        amount_tendered = d.get("amountTendered")
        change_given    = d.get("change")
        for item in d.get("items", []):
            conn.execute("UPDATE products SET stock=MAX(0,stock-?) WHERE id=?",
                         (item["qty"], item["productId"]))
            cur = conn.execute(
                "INSERT INTO sales (product_id,product_name,qty,total,date,cashier,cashier_id,time,receipt_no,amount_tendered,change_given)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (item["productId"], item["productName"], item["qty"], item["total"],
                 date_str, cashier_name, cashier_id, time_str, receipt_no,
                 amount_tendered, change_given)
            )
            row = conn.execute("SELECT * FROM sales WHERE id=?", (cur.lastrowid,)).fetchone()
            saved.append({**s2d(row), "price": item.get("price",0)})
        conn.commit()
        all_products = [p2d(r) for r in conn.execute("SELECT * FROM products ORDER BY name").fetchall()]
        conn.close()
        return JsonResponse({"sales":saved,"products":all_products,
                             "receiptNo":receipt_no,"date":date_str,"time":time_str})

    return JsonResponse({"error": "Method not allowed"}, status=405)


# ── Users ──────────────────────────────────────────────────────────────────────
@csrf_exempt
def users(request):
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM users ORDER BY role, full_name").fetchall()
        conn.close()
        return JsonResponse([u2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d = _body(request)
        conn = get_db()
        try:
            cur = conn.execute(
                "INSERT INTO users (username,password,full_name,role,active) VALUES (?,?,?,?,?)",
                (d["username"], d["password"], d["fullName"], "Cashier",
                 1 if d.get("active", True) else 0)
            )
            conn.commit()
            row = conn.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
            conn.close()
            return JsonResponse(u2d(row), status=201)
        except Exception:
            conn.close()
            return JsonResponse({"error": "Username already taken"}, status=409)

    return JsonResponse({"error": "Method not allowed"}, status=405)


@csrf_exempt
def user_detail(request, uid):
    if request.method == "PUT":
        err = _guard(request, owner=True)
        if err: return err
        d, avatar_file = _parse_product_request(request)
        conn = get_db()
        old_row = conn.execute("SELECT avatar FROM users WHERE id=?", (uid,)).fetchone()
        new_avatar = _save_avatar(avatar_file, old_row["avatar"] if old_row else None)
        if new_avatar:
            conn.execute("UPDATE users SET full_name=?,password=?,active=?,avatar=? WHERE id=?",
                         (d.get("fullName",""), d.get("password",""),
                          1 if d.get("active",True) else 0, new_avatar, uid))
        else:
            conn.execute("UPDATE users SET full_name=?,password=?,active=? WHERE id=?",
                         (d.get("fullName",""), d.get("password",""),
                          1 if d.get("active",True) else 0, uid))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        conn.close()
        return JsonResponse(u2d(row))

    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        if uid == request.session.get("uid"):
            return JsonResponse({"error": "Cannot delete your own account"}, status=400)
        conn = get_db()
        user_row = conn.execute("SELECT full_name FROM users WHERE id=?", (uid,)).fetchone()
        if user_row:
            conn.execute("DELETE FROM sales WHERE cashier_id=? OR cashier=?",
                         (uid, user_row["full_name"]))
        conn.execute("DELETE FROM users WHERE id=?", (uid,))
        conn.commit()
        conn.close()
        return JsonResponse({"ok": True})

    return JsonResponse({"error": "Method not allowed"}, status=405)


@csrf_exempt
@require_http_methods(["POST"])
def user_toggle(request, uid):
    err = _guard(request, owner=True)
    if err: return err
    conn = get_db()
    conn.execute("UPDATE users SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=?", (uid,))
    conn.commit()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return JsonResponse(u2d(row))

# ══════════════════════════════════════════════════════════════════════════════
# CATEGORIES
# ══════════════════════════════════════════════════════════════════════════════

@csrf_exempt
def categories(request):
    """GET /api/categories — list; POST /api/categories — create (owner only)."""
    if request.method == "GET":
        err = _guard(request)
        if err: return err
        conn = get_db()
        rows = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
        conn.close()
        return JsonResponse([c2d(r) for r in rows], safe=False)

    if request.method == "POST":
        err = _guard(request, owner=True)
        if err: return err
        d = _body(request)
        name = (d.get("name") or "").strip()
        if not name:
            return JsonResponse({"error": "Category name is required"}, status=400)
        conn = get_db()
        try:
            cur = conn.execute("INSERT INTO categories (name) VALUES (?)", (name,))
            conn.commit()
            row = conn.execute("SELECT * FROM categories WHERE id=?", (cur.lastrowid,)).fetchone()
            conn.close()
            return JsonResponse(c2d(row), status=201)
        except Exception:
            conn.close()
            return JsonResponse({"error": "Category already exists"}, status=409)

    return JsonResponse({"error": "Method not allowed"}, status=405)


@csrf_exempt
def category_detail(request, cid):
    """DELETE /api/categories/<cid> — remove if unused (owner only)."""
    if request.method == "DELETE":
        err = _guard(request, owner=True)
        if err: return err
        conn = get_db()
        row = conn.execute("SELECT name FROM categories WHERE id=?", (cid,)).fetchone()
        if not row:
            conn.close()
            return JsonResponse({"error": "Not found"}, status=404)
        # Refuse if any product still uses this category
        in_use = conn.execute(
            "SELECT COUNT(*) FROM products WHERE category=?", (row["name"],)
        ).fetchone()[0]
        if in_use:
            conn.close()
            return JsonResponse(
                {"error": f"Cannot delete — {in_use} product(s) still use this category"},
                status=409,
            )
        conn.execute("DELETE FROM categories WHERE id=?", (cid,))
        conn.commit()
        conn.close()
        return JsonResponse({"ok": True})

    return JsonResponse({"error": "Method not allowed"}, status=405)

# ── Store Settings ─────────────────────────────────────────────────────────────
@csrf_exempt
def store_settings(request):
    """GET /api/store-settings  — public (no auth needed for login screen)
       POST /api/store-settings — multipart for logo upload"""
    if request.method == "GET":
        conn = get_db()
        row = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()
        conn.close()
        return JsonResponse(ss2d(row))

    if request.method == "POST":
        d, logo_file = _parse_product_request(request)
        conn = get_db()
        old_row = conn.execute("SELECT logo_url FROM store_settings WHERE id=1").fetchone()
        old_logo = old_row["logo_url"] if old_row else None
        new_logo = _save_image(logo_file, old_logo) if logo_file else None

        store_name = (d.get("storeName") or "Tindahan Mo").strip()
        tagline    = (d.get("tagline") or "").strip()

        if new_logo:
            conn.execute("""INSERT INTO store_settings (id, store_name, tagline, logo_url, setup_done)
                VALUES (1,?,?,?,1)
                ON CONFLICT(id) DO UPDATE SET store_name=excluded.store_name,
                tagline=excluded.tagline, logo_url=excluded.logo_url, setup_done=1""",
                (store_name, tagline, new_logo))
        else:
            conn.execute("""INSERT INTO store_settings (id, store_name, tagline, logo_url, setup_done)
                VALUES (1,?,?,NULL,1)
                ON CONFLICT(id) DO UPDATE SET store_name=excluded.store_name,
                tagline=excluded.tagline, setup_done=1""",
                (store_name, tagline))
        conn.commit()
        row = conn.execute("SELECT * FROM store_settings WHERE id=1").fetchone()
        conn.close()
        return JsonResponse(ss2d(row))

    return JsonResponse({"error": "Method not allowed"}, status=405)
