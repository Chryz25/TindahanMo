from django.urls import path
from . import views

urlpatterns = [
    # ── Frontend ──────────────────────────────────────────────────────────────
    path("", views.index, name="index"),

    # ── Auth ──────────────────────────────────────────────────────────────────
    path("api/me",             views.me,     name="me"),
    path("api/login",          views.login,  name="login"),
    path("api/logout",         views.logout, name="logout"),

    # ── Products ──────────────────────────────────────────────────────────────
    path("api/products",             views.products,        name="products"),
    path("api/products/<int:pid>",   views.product_detail,  name="product_detail"),

    # ── Sales ─────────────────────────────────────────────────────────────────
    path("api/sales", views.sales, name="sales"),

    # ── Users ─────────────────────────────────────────────────────────────────
    path("api/users",                     views.users,        name="users"),
    path("api/users/<int:uid>",           views.user_detail,  name="user_detail"),
    path("api/users/<int:uid>/toggle",    views.user_toggle,  name="user_toggle"),

    # ── Categories ────────────────────────────────────────────────────────────
    path("api/categories",             views.categories,        name="categories"),
    path("api/categories/<int:cid>",   views.category_detail,   name="category_detail"),

    # ── Store Settings ────────────────────────────────────────────────────────
    path("api/store-settings",         views.store_settings,    name="store_settings"),
]
