# tindahan_windows.spec
# PyInstaller build spec for Windows — produces a single TindahanMo.exe
# Run on Windows:  pyinstaller tindahan_windows.spec
#
# Backend: Edge WebView2 (built into Windows 10/11 — no extra install needed)

import os
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_data_files

PROJECT = Path(SPECPATH)

datas         = []
hiddenimports = []
binaries      = []

# ── Collect package data ───────────────────────────────────────────────────────
for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas           += d
    binaries        += b
    hiddenimports   += h

# ── Our app source ─────────────────────────────────────────────────────────────
for folder in ("store", "tindahan_project", "pysqlcipher3"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

# Templates
datas.append((str(PROJECT / "store" / "templates"), "store/templates"))

# ── Seed data files ────────────────────────────────────────────────────────────
for fname in ("tindahan_secure.db", "tindahan_secure.db.salt",
              "django_sessions.db", "manage.py"):
    f = PROJECT / fname
    if f.is_file():
        datas.append((str(f), "."))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

# ── Analysis ───────────────────────────────────────────────────────────────────
a = Analysis(
    [str(PROJECT / "launcher.py")],
    pathex   = [str(PROJECT)],
    binaries = binaries,
    datas    = datas,
    hiddenimports = list(set(hiddenimports)) + [
        # Django internals
        "django.template.defaulttags",
        "django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security",
        "django.middleware.common",
        # App modules
        "store", "store.views", "store.db", "store.apps",
        "tindahan_project.settings",
        "tindahan_project.urls",
        "tindahan_project.wsgi",
        "pysqlcipher3", "pysqlcipher3.dbapi2",
        # pywebview Edge backend
        "webview.platforms.edgechromium",
        "clr_loader",
        # Cryptography
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes",
        "cryptography.fernet",
        # Standard library used at runtime
        "wsgiref.simple_server",
        "wsgiref.handlers",
        "email.mime.text",
        "email.mime.multipart",
    ],
    excludes = [
        "tkinter", "PyQt5", "PyQt6", "PySide2", "PySide6",
        "wx", "matplotlib", "gi",
    ],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

# --onefile: everything packed into a single TindahanMo.exe
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name             = "TindahanMo",
    debug            = False,
    bootloader_ignore_signals = False,
    strip            = False,
    upx              = True,       # compress — reduces file size ~30%
    upx_exclude      = [],
    runtime_tmpdir   = None,
    console          = False,      # no black CMD window — clean GUI app
    disable_windowed_traceback = False,
    icon             = None,       # add "icon.ico" here if you have one
    version_file     = None,
    uac_admin        = False,      # no admin rights required
)
