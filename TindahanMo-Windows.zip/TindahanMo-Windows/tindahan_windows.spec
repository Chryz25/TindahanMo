# tindahan_windows.spec — PyInstaller spec for single TindahanMo.exe
# Run: pyinstaller tindahan_windows.spec
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

PROJECT = Path(SPECPATH)
datas, binaries, hiddenimports = [], [], []

for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

for folder in ("store", "tindahan_project", "pysqlcipher3"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

datas.append((str(PROJECT / "store" / "templates"), "store/templates"))

favicon = PROJECT / "store" / "favicon.ico"
if favicon.is_file():
    datas.append((str(favicon), "store"))

for fname in ("manage.py",):
    f = PROJECT / fname
    if f.is_file():
        datas.append((str(f), "."))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

a = Analysis(
    [str(PROJECT / "launcher.py")],
    pathex        = [str(PROJECT)],
    binaries      = binaries,
    datas         = datas,
    hiddenimports = list(set(hiddenimports)) + [
        "django.template.defaulttags", "django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security", "django.middleware.common",
        "store", "store.views", "store.db", "store.apps", "store.urls",
        "tindahan_project.settings", "tindahan_project.urls", "tindahan_project.wsgi",
        "pysqlcipher3", "pysqlcipher3.dbapi2",
        "webview.platforms.edgechromium",
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes", "cryptography.fernet",
        "wsgiref.simple_server", "wsgiref.handlers",
        "email.mime.text", "email.mime.multipart", "importlib.metadata",
    ],
    excludes   = ["tkinter","PyQt5","PyQt6","PySide2","PySide6","wx","matplotlib","gi"],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name           = "TindahanMo",
    debug          = False,
    strip          = False,
    upx            = True,
    runtime_tmpdir = None,
    console        = False,
    uac_admin      = False,
)
