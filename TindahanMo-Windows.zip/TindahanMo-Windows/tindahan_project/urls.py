from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.http import FileResponse, Http404
from pathlib import Path

def _favicon(request):
    """Serve the bundled favicon.ico from store/favicon.ico."""
    ico = Path(__file__).resolve().parent.parent / "store" / "favicon.ico"
    if not ico.exists():
        raise Http404
    return FileResponse(open(ico, "rb"), content_type="image/x-icon")

urlpatterns = [
    path("favicon.ico", _favicon),
    path("", include("store.urls")),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
