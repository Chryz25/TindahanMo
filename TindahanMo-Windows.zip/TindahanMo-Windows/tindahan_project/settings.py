"""
Tindahan Mo — Django Settings
"""
import os
from pathlib import Path

# When launched as a desktop app, TINDAHAN_BASE_DIR is set by launcher.py
# so that all user data (DBs, media) live in ~/.local/share/tindahan/.
# Fall back to the project root when running in dev mode.
BASE_DIR = Path(
    os.environ.get("TINDAHAN_BASE_DIR",
                   Path(__file__).resolve().parent.parent)
)

# ── Security ───────────────────────────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY", "tindahan-mo-django-2026!")
DEBUG = os.environ.get("DEBUG", "True") == "True"
ALLOWED_HOSTS = ["*"]

# ── Applications ───────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "store",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
]

ROOT_URLCONF = "tindahan_project.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
            ],
        },
    },
]

WSGI_APPLICATION = "tindahan_project.wsgi.application"

# ── Database ───────────────────────────────────────────────────────────────────
# Django uses this SQLite only for sessions.
# Business data lives in the encrypted tindahan_secure.db via pysqlcipher3.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "django_sessions.db",
    }
}

# ── Sessions ───────────────────────────────────────────────────────────────────
SESSION_ENGINE = "django.contrib.sessions.backends.db"
SESSION_COOKIE_AGE = 60 * 60 * 8  # 8 hours

# ── Internationalisation ───────────────────────────────────────────────────────
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Manila"
USE_I18N = True
USE_TZ = True

# ── Static files ───────────────────────────────────────────────────────────────
STATIC_URL = "/static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
APPEND_SLASH = False

# ── Media files (product images) ───────────────────────────────────────────────
MEDIA_URL  = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# ── Encrypted business DB config ──────────────────────────────────────────────
TINDAHAN_DB_PATH = os.environ.get("DB_PATH", str(BASE_DIR / "tindahan_secure.db"))
TINDAHAN_DB_KEY  = os.environ.get("DB_KEY",  "TindahanMo@Cebu2026#Secure!")
