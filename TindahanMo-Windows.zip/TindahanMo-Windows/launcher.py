"""
Tindahan Mo — Windows Desktop Launcher
=======================================
• Uses Microsoft Edge WebView2 (built into every Windows 10/11)
  via pywebview — zero browser install needed on the target PC.
• Starts Django on a free localhost port in a background thread.
• Shows a animated splash while Django boots.
• Fresh install / deleted DB → Welcome wizard appears automatically.
• All user data lives in:
      C:\\Users\\<you>\\AppData\\Local\\TindahanMo\\
  so the .exe can be replaced without losing any store data.
"""

import os
import sys
import threading
import time
import socket
import shutil
from pathlib import Path

# ── User-data directory ───────────────────────────────────────────────────────
# %LOCALAPPDATA% = C:\Users\<name>\AppData\Local  — private, no admin needed
APP_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TindahanMo"

# ── Splash screen HTML ────────────────────────────────────────────────────────
LOADING_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Tindahan Mo</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    background: linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
    display:flex; align-items:center; justify-content:center;
    height:100vh; font-family:'Segoe UI',Arial,sans-serif; color:#fff;
    user-select:none;
  }
  .card { text-align:center; animation:fadeIn .7s ease; }
  @keyframes fadeIn {
    from { opacity:0; transform:translateY(24px); }
    to   { opacity:1; transform:translateY(0); }
  }
  .logo  { font-size:76px; margin-bottom:20px; }
  h1     { font-size:38px; font-weight:900; color:#f5c518; letter-spacing:1px; }
  p      { margin-top:14px; font-size:15px; opacity:.65; }
  .dots span {
    display:inline-block; width:9px; height:9px; border-radius:50%;
    background:#f5c518; margin:0 3px; animation:bounce 1.2s infinite;
  }
  .dots span:nth-child(2){ animation-delay:.2s; }
  .dots span:nth-child(3){ animation-delay:.4s; }
  @keyframes bounce {
    0%,80%,100%{ transform:translateY(0); }
    40%         { transform:translateY(-12px); }
  }
</style>
</head>
<body>
  <div class="card">
    <div class="logo">&#127978;</div>
    <h1>Tindahan Mo</h1>
    <p>Starting up&nbsp;
      <span class="dots"><span></span><span></span><span></span></span>
    </p>
  </div>
</body>
</html>"""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _bundle_dir() -> Path:
    """Directory that contains our bundled source files."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)           # PyInstaller --onefile temp dir
    return Path(__file__).resolve().parent  # normal / dev run


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ── First-run / update setup ──────────────────────────────────────────────────

def _setup_data_dir() -> bool:
    """
    Sync Python source from bundle into APP_DATA_DIR on every launch so that
    replacing the .exe also updates the app code.

    Databases and media are seeded ONLY on first run — user data is never
    overwritten by an update.

    Returns True if this is a brand-new / reset installation.
    """
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    bundle = _bundle_dir()

    # Always refresh Python source packages
    for pkg in ("store", "tindahan_project", "pysqlcipher3"):
        src = bundle / pkg
        dst = APP_DATA_DIR / pkg
        if src.exists():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)

    if (bundle / "manage.py").exists():
        shutil.copy2(bundle / "manage.py", APP_DATA_DIR / "manage.py")

    # Detect fresh install BEFORE seeding
    is_fresh = not (APP_DATA_DIR / "tindahan_secure.db").exists()

    # Seed DB + salt only when they don't yet exist
    for fname in ("tindahan_secure.db", "tindahan_secure.db.salt", "django_sessions.db"):
        src = bundle / fname
        if src.exists() and not (APP_DATA_DIR / fname).exists():
            shutil.copy2(src, APP_DATA_DIR / fname)

    # Seed media only when it doesn't yet exist
    media_src = bundle / "media"
    if media_src.exists() and not (APP_DATA_DIR / "media").exists():
        shutil.copytree(media_src, APP_DATA_DIR / "media")

    # Always ensure upload directories exist
    (APP_DATA_DIR / "media" / "products").mkdir(parents=True, exist_ok=True)
    (APP_DATA_DIR / "media" / "avatars").mkdir(parents=True, exist_ok=True)

    return is_fresh


# ── Django server ─────────────────────────────────────────────────────────────

def _run_django(port: int) -> None:
    os.environ["DJANGO_SETTINGS_MODULE"] = "tindahan_project.settings"
    os.environ["TINDAHAN_BASE_DIR"]       = str(APP_DATA_DIR)
    sys.path.insert(0, str(APP_DATA_DIR))

    import django
    django.setup()

    from django.core.management import call_command
    call_command("migrate", "--run-syncdb", verbosity=0)

    from store.db import init_db
    init_db()

    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler

    class _Quiet(WSGIRequestHandler):
        def log_message(self, *_): pass

    make_server("127.0.0.1", port, get_wsgi_application(),
                handler_class=_Quiet).serve_forever()


def _wait_for_server(port: int, timeout: float = 30.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.2)
    return False


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    # Force Edge WebView2 backend — pre-installed on all Win10/11 machines.
    # This avoids needing Qt, GTK, or any extra browser installation.
    os.environ["PYWEBVIEW_GUI"] = "edgechromium"

    print("Tindahan Mo starting...")
    is_fresh = _setup_data_dir()
    if is_fresh:
        print("Fresh install — welcome screen will appear")

    port = _find_free_port()
    threading.Thread(target=_run_django, args=(port,), daemon=True).start()

    import webview

    window = webview.create_window(
        title     = "Tindahan Mo",
        html      = LOADING_HTML,
        width     = 1280,
        height    = 820,
        min_size  = (900, 600),
        resizable = True,
    )

    def _go():
        if _wait_for_server(port, timeout=30):
            window.load_url(f"http://127.0.0.1:{port}")
        else:
            window.load_html(
                "<body style='background:#1a1a2e;color:#f5c518;font-family:Segoe UI,Arial;"
                "display:flex;align-items:center;justify-content:center;height:100vh'>"
                "<div style='text-align:center'><div style='font-size:48px'>&#9888;</div>"
                "<h2 style='margin-top:16px'>Could not start. Please relaunch.</h2></div></body>"
            )

    threading.Thread(target=_go, daemon=True).start()

    # gui="edgechromium" uses the Edge WebView2 runtime built into Win10/11
    webview.start(gui="edgechromium", debug=False)
    print("Tindahan Mo closed.")


if __name__ == "__main__":
    main()
