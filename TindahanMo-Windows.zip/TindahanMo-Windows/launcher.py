"""
Tindahan Mo — Windows Desktop Launcher
=======================================
• Edge WebView2 (built into Windows 10/11) — no browser install needed
• Django on a free localhost port
• Fresh install → Welcome wizard (setup_done=0 guaranteed)
• Data in %LOCALAPPDATA%\TindahanMo\ — never lost on update
• Print: temp HTML + os.startfile → default browser auto-prints
• Non-daemon Django thread → _flush() always completes on close
"""

import os, sys, threading, time, socket, shutil, tempfile
from pathlib import Path

APP_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TindahanMo"
VERSION      = "1.0.0"

LOADING_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Tindahan Mo</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
  display:flex;align-items:center;justify-content:center;height:100vh;
  font-family:'Segoe UI',Arial,sans-serif;color:#fff;user-select:none}
.card{text-align:center;animation:fadeIn .7s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
.logo{font-size:76px;margin-bottom:20px}
h1{font-size:38px;font-weight:900;color:#f5c518;letter-spacing:1px}
p{margin-top:14px;font-size:15px;opacity:.65}
.dots span{display:inline-block;width:9px;height:9px;border-radius:50%;
  background:#f5c518;margin:0 3px;animation:bounce 1.2s infinite}
.dots span:nth-child(2){animation-delay:.2s}
.dots span:nth-child(3){animation-delay:.4s}
@keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-12px)}}
</style></head>
<body><div class="card">
  <div class="logo">&#127978;</div>
  <h1>Tindahan Mo</h1>
  <p>Starting up&nbsp;<span class="dots"><span></span><span></span><span></span></span></p>
</div></body></html>"""


# ── Print API ─────────────────────────────────────────────────────────────────

class PrintAPI:
    """
    JS: pywebview.api.print_receipt(html)
    Writes receipt to a temp .html file, opens with os.startfile()
    (Windows default browser). The HTML auto-triggers window.print().
    No Qt threading issues — no UI objects created off the main thread.
    """
    def print_receipt(self, html: str) -> dict:
        try:
            fd, tmp = tempfile.mkstemp(suffix=".html", prefix="tindahan_receipt_")
            os.close(fd)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(html)
            os.startfile(tmp)                       # opens in default browser
            def _del():
                time.sleep(300)
                try: os.unlink(tmp)
                except: pass
            threading.Thread(target=_del, daemon=True).start()
            return {"ok": True}
        except Exception as exc:
            import traceback; traceback.print_exc()
            return {"ok": False, "err": str(exc)}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _bundle_dir() -> Path:
    if hasattr(sys, "_MEIPASS"): return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent

def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); return s.getsockname()[1]


# ── Data directory setup ──────────────────────────────────────────────────────

def _setup_data_dir() -> bool:
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    bundle = _bundle_dir()
    stamp  = APP_DATA_DIR / ".version"
    if not stamp.exists() or stamp.read_text().strip() != VERSION:
        for pkg in ("store", "tindahan_project", "pysqlcipher3"):
            src, dst = bundle / pkg, APP_DATA_DIR / pkg
            if src.exists():
                if dst.exists(): shutil.rmtree(dst)
                shutil.copytree(src, dst)
        src_mgr = bundle / "manage.py"
        if src_mgr.exists():
            shutil.copy2(src_mgr, APP_DATA_DIR / "manage.py")
        stamp.write_text(VERSION)
    is_fresh = not (APP_DATA_DIR / "tindahan_secure.db").exists()
    msrc = bundle / "media"
    if msrc.exists() and not (APP_DATA_DIR / "media").exists():
        shutil.copytree(msrc, APP_DATA_DIR / "media")
    (APP_DATA_DIR / "media" / "products").mkdir(parents=True, exist_ok=True)
    (APP_DATA_DIR / "media" / "avatars").mkdir(parents=True, exist_ok=True)
    return is_fresh


# ── Django server ─────────────────────────────────────────────────────────────

_httpd = None

def _run_django(port: int) -> None:
    global _httpd
    os.environ["DJANGO_SETTINGS_MODULE"] = "tindahan_project.settings"
    os.environ["TINDAHAN_BASE_DIR"]       = str(APP_DATA_DIR)
    sys.path.insert(0, str(APP_DATA_DIR))
    import django; django.setup()
    from django.core.management import call_command
    call_command("migrate", "--run-syncdb", verbosity=0)
    from store.db import init_db; init_db()
    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler
    class _Q(WSGIRequestHandler):
        def log_message(self, *_): pass
    _httpd = make_server("127.0.0.1", port, get_wsgi_application(), handler_class=_Q)
    _httpd.serve_forever()

def _wait(port, timeout=30.0):
    d = time.monotonic() + timeout
    while time.monotonic() < d:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5): return True
        except OSError: time.sleep(0.2)
    return False

def _stop():
    if _httpd:
        try: _httpd.shutdown()
        except: pass
    time.sleep(0.5)


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    print("Tindahan Mo starting...")
    os.environ["PYWEBVIEW_GUI"] = "edgechromium"

    is_fresh = _setup_data_dir()
    print("Fresh install" if is_fresh else "Existing data found")

    port = _free_port()
    threading.Thread(target=_run_django, args=(port,),
                     daemon=False, name="tindahan-django").start()

    import webview
    api    = PrintAPI()
    window = webview.create_window(
        title    = "Tindahan Mo",
        html     = LOADING_HTML,
        width    = 1280, height = 820,
        min_size = (900, 600),
        resizable= True,
        js_api   = api,
    )

    def _go():
        if _wait(port): window.load_url(f"http://127.0.0.1:{port}")
        else: window.load_html(
            "<body style='background:#1a1a2e;color:#f5c518;font-family:Segoe UI;"
            "display:flex;align-items:center;justify-content:center;height:100vh'>"
            "<div style='text-align:center'><div style='font-size:48px'>&#9888;</div>"
            "<h2 style='margin-top:16px'>Server failed to start.</h2>"
            "<p style='opacity:.7;margin-top:8px'>Please close and relaunch.</p>"
            "</div></body>")

    threading.Thread(target=_go, daemon=True).start()
    webview.start(gui="edgechromium", debug=False)

    print("Shutting down...")
    _stop()
    print("Done.")

if __name__ == "__main__":
    main()
