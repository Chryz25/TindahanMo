@echo off
:: =============================================================================
::  build.bat — Tindahan Mo Windows Desktop Build Script
::  Run this on your Windows 10/11 machine to produce TindahanMo.exe
::  Double-click this file OR run it in Command Prompt / PowerShell
:: =============================================================================
setlocal enabledelayedexpansion
title Tindahan Mo — Windows Build

echo.
echo  ============================================================
echo   Tindahan Mo — Windows Desktop Builder
echo   Output: dist\TindahanMo.exe  (share with anyone on Win10/11)
echo  ============================================================
echo.

:: ── Check Python ─────────────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found in PATH.
    echo.
    echo  Please install Python 3.11 or newer from:
    echo    https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: Check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  [OK] Found: %PYVER%
echo.

:: ── Create virtual environment ────────────────────────────────────────────────
echo  [1/4] Creating virtual environment...
if exist .venv (
    echo       (.venv already exists, reusing)
) else (
    python -m venv .venv
    if errorlevel 1 (
        echo  [ERROR] Failed to create virtual environment.
        pause & exit /b 1
    )
)

:: ── Activate venv ─────────────────────────────────────────────────────────────
call .venv\Scripts\activate.bat
echo  [OK] Virtual environment activated

:: ── Install Python packages ───────────────────────────────────────────────────
echo.
echo  [2/4] Installing Python packages (first run may take a few minutes)...
python -m pip install --upgrade pip --quiet
pip install ^
    "Django>=4.2,<6.0" ^
    "cryptography>=41.0" ^
    "pywebview>=5.0" ^
    "pyinstaller>=6.0" ^
    --quiet

if errorlevel 1 (
    echo  [ERROR] Package installation failed. Check your internet connection.
    pause & exit /b 1
)
echo  [OK] Packages installed

:: ── PyInstaller build ─────────────────────────────────────────────────────────
echo.
echo  [3/4] Building TindahanMo.exe with PyInstaller...
echo        (This takes 3-10 minutes — please wait)
echo.

pyinstaller tindahan_windows.spec ^
    --distpath dist ^
    --workpath build ^
    --noconfirm ^
    --clean

if errorlevel 1 (
    echo.
    echo  [ERROR] Build failed. See error above.
    pause & exit /b 1
)

:: ── Done ──────────────────────────────────────────────────────────────────────
echo.
echo  [4/4] Checking output...
if not exist "dist\TindahanMo.exe" (
    echo  [ERROR] TindahanMo.exe was not created.
    pause & exit /b 1
)

:: Get file size
for %%A in ("dist\TindahanMo.exe") do set SIZE=%%~zA
set /a SIZE_MB=!SIZE! / 1048576

echo.
echo  ============================================================
echo   [SUCCESS] Build complete!
echo.
echo   File:  %CD%\dist\TindahanMo.exe
echo   Size:  ~!SIZE_MB! MB
echo.
echo   HOW TO SHARE:
echo   Copy  dist\TindahanMo.exe  to any Windows 10/11 computer.
echo   Just double-click it — no installation needed!
echo.
echo   USER DATA is stored in:
echo   %%LOCALAPPDATA%%\TindahanMo\
echo   (Replacing the .exe never erases store data)
echo  ============================================================
echo.

:: Ask to open the dist folder
set /p OPEN="  Open dist folder now? (Y/N): "
if /i "!OPEN!"=="Y" explorer dist

endlocal
pause
