@echo off
setlocal enabledelayedexpansion
title Tindahan Mo — Windows Build

echo.
echo  ============================================================
echo   Tindahan Mo ^| Windows Desktop Builder
echo   Output: dist\TindahanMo.exe  (share with anyone on Win10/11)
echo  ============================================================
echo.

:: ── Check Python ──────────────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found.
    echo  Install Python 3.11 from https://www.python.org/downloads/
    echo  IMPORTANT: tick "Add Python to PATH" during install.
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  [OK] %PYVER%
echo.

:: ── Virtual environment ────────────────────────────────────────────────────────
echo  [1/4] Setting up virtual environment...
if not exist .venv (
    python -m venv .venv
    if errorlevel 1 ( echo  [ERROR] venv failed. & pause & exit /b 1 )
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip --quiet
echo  [OK] Virtual environment ready

:: ── Python packages ───────────────────────────────────────────────────────────
echo.
echo  [2/4] Installing packages (first run ~5 min, downloads ~150 MB)...
pip install "Django>=4.2,<6.0" "cryptography>=41.0" "pywebview>=5.0" "pyinstaller>=6.0" --quiet
if errorlevel 1 ( echo  [ERROR] Package install failed. Check internet connection. & pause & exit /b 1 )
echo  [OK] Packages installed

:: ── Build EXE ─────────────────────────────────────────────────────────────────
echo.
echo  [3/4] Building TindahanMo.exe (3-10 minutes)...
echo.
pyinstaller tindahan_windows.spec --distpath dist --workpath build --noconfirm --clean
if errorlevel 1 ( echo. & echo  [ERROR] Build failed. & pause & exit /b 1 )

:: ── Done ──────────────────────────────────────────────────────────────────────
if not exist "dist\TindahanMo.exe" (
    echo  [ERROR] TindahanMo.exe was not created.
    pause & exit /b 1
)

for %%A in ("dist\TindahanMo.exe") do set BYTES=%%~zA
set /a MB=!BYTES! / 1048576

echo.
echo  ============================================================
echo   [SUCCESS] Build complete!
echo.
echo   File : %CD%\dist\TindahanMo.exe
echo   Size : ~!MB! MB
echo.
echo   SHARE: Copy dist\TindahanMo.exe to any Windows 10/11 PC.
echo          Double-click to run — no install needed!
echo.
echo   DATA : C:\Users\^<name^>\AppData\Local\TindahanMo\
echo          (Replacing the .exe never erases store data)
echo  ============================================================
echo.

set /p OPEN="  Open dist folder now? (Y/N): "
if /i "!OPEN!"=="Y" explorer dist

endlocal
pause
