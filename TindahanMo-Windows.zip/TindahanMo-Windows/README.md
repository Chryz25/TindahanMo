# Tindahan Mo — Windows Desktop App

## What You Get

A single file: **`TindahanMo.exe`**

- Runs on **any Windows 10 or Windows 11** PC
- No installation required — just double-click
- Uses **Microsoft Edge WebView2** (built into every Win10/11 — nothing extra to install)
- ~50–80 MB file size

---

## Build Steps (run once on your Windows PC)

### Step 1 — Install Python

Download from: **https://www.python.org/downloads/**

Choose Python **3.11** or **3.12** (64-bit Windows installer)

> ⚠️ **Important:** Check **"Add Python to PATH"** during installation!

### Step 2 — Run the build script

Double-click **`build.bat`**

Or open Command Prompt in this folder and run:
```
build.bat
```

The script will:
1. Create a Python virtual environment
2. Install Django, cryptography, PyWebView, PyInstaller
3. Bundle everything into `dist\TindahanMo.exe`

> First run takes **5–15 minutes** (downloads packages, compiles).
> Subsequent builds are much faster.

### Step 3 — Share the EXE

After building, you get one file:
```
dist\TindahanMo.exe
```

Copy it to **any Windows 10/11 computer** and double-click.
**No Python, no installation, no setup needed.**

---

## How It Works

```
User double-clicks TindahanMo.exe
  │
  ├─ Extracts itself to a temp folder (~3 sec)
  ├─ Starts Django server on 127.0.0.1:RANDOM_PORT
  ├─ Shows animated splash screen
  └─ Opens Edge WebView2 window → loads the app

First launch (or after reset):
  └─ Welcome screen + Store Setup Wizard appears
```

### User Data Location

All store data is saved here — **never touched by app updates**:
```
C:\Users\<YourName>\AppData\Local\TindahanMo\
├── tindahan_secure.db       ← encrypted business database
├── tindahan_secure.db.salt  ← encryption key
├── django_sessions.db       ← login sessions
└── media\
    ├── products\            ← product images
    └── avatars\             ← user avatars
```

### Reset to Fresh / Welcome Screen

Delete the data folder to start over:
```
C:\Users\<YourName>\AppData\Local\TindahanMo\
```
Next launch will show the Welcome wizard again.

---

## Default Login Credentials

| Username | Password  | Role        |
|----------|-----------|-------------|
| owner    | owner123  | Store Owner |
| maria    | maria123  | Cashier     |
| jose     | jose123   | Cashier     |

*Change these in the app after first login.*

---

## Troubleshooting

### "Python not found" when running build.bat
Reinstall Python from python.org and check **"Add Python to PATH"**.

### App opens but shows blank white screen
Wait 5–10 seconds — Django is still starting up on first launch.

### "WebView2 runtime not found" error
This is rare on Win10/11 (it's built-in), but if it happens:
Install from: https://developer.microsoft.com/en-us/microsoft-edge/webview2/

### Windows SmartScreen warning when running the EXE
Click **"More info"** → **"Run anyway"**
This appears because the EXE is not code-signed (normal for self-built apps).
