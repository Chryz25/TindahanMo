# Tindahan Mo — Windows Desktop App

## What You Get

`dist\TindahanMo.exe` — a single file, share with anyone on Windows 10/11.
No Python, no browser, no installation needed on the target PC.
Uses Edge WebView2 (built into every Windows 10/11 machine).

---

## Build Steps (once on your Windows 10/11 PC)

### 1. Install Python 3.11
https://www.python.org/downloads/
⚠️  Tick "Add Python to PATH" during install!

### 2. Double-click build.bat
The script will:
  - Create a virtual environment
  - Install Django, cryptography, pywebview, pyinstaller
  - Bundle everything into dist\TindahanMo.exe

First run: ~5-15 minutes (downloads ~150 MB).
Subsequent builds: ~3-5 minutes.

### 3. Share dist\TindahanMo.exe
Copy it anywhere. Recipients just double-click it — nothing to install.

---

## How It Works

  Double-click TindahanMo.exe
    → Extracts to temp folder (~3 sec)
    → Django starts on 127.0.0.1:RANDOM_PORT
    → Splash screen → Edge WebView2 window loads the app
    → Fresh install? Welcome wizard appears automatically

---

## Printing Receipts

Click the Print button on a receipt:
  → Receipt opens as a new tab in your default browser
  → Print dialog opens automatically (Ctrl+P)
  → Choose printer or Save as PDF

---

## User Data

C:\Users\<Name>\AppData\Local\TindahanMo\
  tindahan_secure.db       — encrypted business data
  tindahan_secure.db.salt  — encryption key
  django_sessions.db       — login sessions
  media\products\          — product images
  media\avatars\           — user avatars

Replacing TindahanMo.exe NEVER deletes this data.

To reset (show Welcome wizard again):
  Delete C:\Users\<Name>\AppData\Local\TindahanMo\

---

## Default Credentials

  owner / owner123  (Store Owner)
  maria / maria123  (Cashier)
  jose  / jose123   (Cashier)

---

## Troubleshooting

  "Python not found"     → reinstall Python, tick Add to PATH
  Blank white screen     → wait 5-10 sec (Django starting up)
  "WebView2 not found"   → https://developer.microsoft.com/microsoft-edge/webview2/
  Windows SmartScreen    → click "More info" → "Run anyway"
  Build error            → delete .venv folder, run build.bat again
