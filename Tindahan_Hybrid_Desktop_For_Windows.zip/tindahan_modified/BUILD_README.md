# Tindahan Mo — Desktop App

## Building the Single-File Executable

### Requirements
- Debian 13 (Trixie) GNOME — the build machine must match the target OS
- `sudo` access (to install system packages)
- Internet connection (first run only)

### Build Steps

```bash
# 1. Make the build script executable
chmod +x build.sh

# 2. Run it — installs deps and produces dist/tindahan-mo
./build.sh
```

The script will:
1. Install system libraries (WebKitGTK, GTK3, etc.) via `apt`
2. Create a Python virtual environment
3. Install Django, PyWebView, cryptography, PyInstaller
4. Run PyInstaller to bundle everything into `dist/tindahan-mo`
5. Create a GNOME `.desktop` shortcut (searchable in Activities)

---

## Distributing the App

After building, share the single file:

```
dist/tindahan-mo
```

Anyone on **Debian 13 GNOME** can run it:

```bash
chmod +x tindahan-mo
./tindahan-mo
```

The app will:
- Extract itself on first launch (takes ~5 seconds)
- Store all user data in `~/.local/share/tindahan/`
- Open a native GNOME window — no browser needed

---

## User Data Location

All data is stored per-user at:

```
~/.local/share/tindahan/
├── tindahan_secure.db        ← encrypted business database
├── tindahan_secure.db.salt   ← encryption salt
├── django_sessions.db        ← session data
└── media/
    ├── products/             ← product images
    └── avatars/              ← user avatars
```

Updating the app (replacing the executable) will **not** overwrite user data.

---

## Development Mode

Run without building:

```bash
# Install deps
pip install Django cryptography "pywebview[gtk]" PyGObject

# Run
python launcher.py
```

---

## Architecture

```
launcher.py
  │
  ├── Sets TINDAHAN_BASE_DIR → ~/.local/share/tindahan/
  ├── Starts Django on a free local port (127.0.0.1:XXXX)
  │     └── Serves the full web app (REST API + HTML frontend)
  └── Opens PyWebView window (GTK/WebKitGTK2)
        └── Loads http://127.0.0.1:XXXX
```

The app is a standard Django web app wrapped in a native window.
There is no internet connection required at runtime.

---

## 🪟 Windows Build (Windows 10 / 11)

### What You Need
- A Windows 10 or 11 PC (64-bit)
- Internet connection (first run — downloads Python, packages, Inno Setup automatically)
- **No pre-installed software required** — the build script installs everything

### Files for Windows Build
| File | Purpose |
|------|---------|
| `build_windows.bat` | Double-click to start the build |
| `build_windows.ps1` | Main build logic (PowerShell) |
| `launcher_windows.py` | Windows-adapted app launcher |
| `tindahan_windows.spec` | PyInstaller spec for Windows |

### Build Steps

1. Copy the whole project folder to your Windows machine
2. Double-click **`build_windows.bat`**
3. Click **Yes** on the UAC prompt (needed to install Python)
4. Wait 15–30 minutes (one-time dependency download)
5. Done ✅

### What the Script Does Automatically
1. Checks for Python 3.11+ → downloads & installs Python 3.12 if missing
2. Creates an isolated virtual environment
3. Installs PySide6, Django, pywebview, cryptography, PyInstaller, Pillow
4. Generates a multi-size `.png` and `.ico` icon
5. Builds the app with PyInstaller → `dist_windows\tindahan\`
6. Downloads & installs Inno Setup 6 if missing
7. Compiles a shareable Windows installer `.exe`

### Output Files
```
dist_windows\
├── tindahan\                          ← portable app folder
│   ├── tindahan.exe                   ← run directly (no install needed)
│   └── ...                            ← supporting DLLs and assets
└── TindahanMo-Setup-v1.0.0-Windows.exe ← shareable installer for any Win10/11 PC
```

### Distributing to Other Windows Users
Share the **`TindahanMo-Setup-v1.0.0-Windows.exe`** installer.  
The recipient just double-clicks it — no Python or dependencies needed.
- Installs to `%ProgramFiles%\Tindahan Mo\`
- Creates Start Menu shortcut
- Optional Desktop shortcut
- Includes uninstaller

### User Data Location (Windows)
```
%LOCALAPPDATA%\TindahanMo\
├── tindahan_secure.db        ← encrypted business database
├── tindahan_secure.db.salt   ← encryption salt
├── django_sessions.db        ← session data
└── media\
    ├── products\             ← product images
    └── avatars\              ← user avatars
```
Data survives app updates and uninstalls.

### Custom Logo
Drop your own `logo.png` (or `logo.jpg`) next to `build_windows.bat`  
before building — it will be used as the app icon everywhere.

### Troubleshooting
| Problem | Fix |
|---------|-----|
| App won't start after install | Install [VC++ Redist x64](https://aka.ms/vs/17/release/vc_redist.x64.exe) |
| Black screen on launch | Add `--disable-gpu` flag already included in launcher |
| PyInstaller fails | Run `build_windows.bat` again — it cleans the cache first |
| No installer created | Install [Inno Setup 6](https://jrsoftware.org/isdl.php) manually, re-run |
