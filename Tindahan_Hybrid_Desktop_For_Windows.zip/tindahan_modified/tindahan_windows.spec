# tindahan_windows.spec — PyInstaller spec for Windows 10/11
# ─────────────────────────────────────────────────────────────
# Used by build_windows.ps1 — do NOT run pyinstaller manually
# with this spec unless you have the venv activated first.
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_data_files

PROJECT  = Path(SPECPATH)
datas, binaries, hiddenimports = [], [], []

# ── Collect package data for Django, cryptography, pywebview ─────────────────
for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

# ── Also collect PySide6 WebEngine resources (Windows needs them) ─────────────
try:
    d, b, h = collect_all("PySide6")
    datas += d; binaries += b; hiddenimports += h
except Exception:
    pass

# ── App source packages ───────────────────────────────────────────────────────
for folder in ("store", "tindahan_project", "pysqlcipher3"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

# ── Static assets ─────────────────────────────────────────────────────────────
if (PROJECT / "store" / "favicon.ico").is_file():
    datas.append((str(PROJECT / "store" / "favicon.ico"), "store"))

if (PROJECT / "manage.py").is_file():
    datas.append((str(PROJECT / "manage.py"), "."))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

# ── App icon (PNG — embedded into bundle, served at /media/app_icon.png) ──────
_icon_src = PROJECT / "tindahan_icon.png"
if not _icon_src.is_file():
    import subprocess as _sp, sys as _sys
    _sp.run(
        [_sys.executable, str(PROJECT / "make_icon.py"), str(_icon_src), "256"],
        check=False
    )
if _icon_src.is_file():
    datas.append((str(_icon_src), "."))

# ── ICO file for Windows window/taskbar icon ──────────────────────────────────
_ico_src = PROJECT / "tindahan_icon.ico"
if _ico_src.is_file():
    datas.append((str(_ico_src), "."))

# ── Determine the correct icon path for EXE metadata ─────────────────────────
# PyInstaller on Windows needs a .ico — fall back to PNG if ICO missing
_exe_icon = None
if _ico_src.is_file():
    _exe_icon = str(_ico_src)
elif _icon_src.is_file():
    _exe_icon = str(_icon_src)

# ─────────────────────────────────────────────────────────────────────────────
a = Analysis(
    [str(PROJECT / "launcher.py")],    # build_windows.ps1 swaps launcher_windows.py → launcher.py
    pathex        = [str(PROJECT)],
    binaries      = binaries,
    datas         = datas,
    hiddenimports = list(set(hiddenimports)) + [
        # Django internals
        "django.template.defaulttags",
        "django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security",
        "django.middleware.common",
        # App modules
        "store",
        "store.views",
        "store.db",
        "store.sync",
        "store.apps",
        "store.urls",
        "tindahan_project.settings",
        "tindahan_project.urls",
        "tindahan_project.wsgi",
        "pysqlcipher3",
        "pysqlcipher3.dbapi2",
        # pywebview Qt backend
        "webview.platforms.qt",
        # Crypto
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes",
        "cryptography.fernet",
        # stdlib extras
        "wsgiref.simple_server",
        "wsgiref.handlers",
        "urllib.request",
        "urllib.parse",
        "email.mime.text",
        "importlib.metadata",
        # Windows-specific
        "winreg",
        "ctypes",
        "ctypes.wintypes",
    ],
    excludes = [
        "tkinter", "PyQt5", "PyQt6", "PySide2", "wx",
        "matplotlib", "gi", "test", "unittest",
    ],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
    win_no_prefer_redirects = False,
    win_private_assemblies  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries = True,
    name    = "tindahan",
    debug   = False,
    bootloader_ignore_signals = False,
    strip   = False,
    upx     = True,
    console = False,        # no black console window on Windows
    icon    = _exe_icon,
    # Windows version info shown in Properties → Details
    version_file = None,
    uac_admin    = False,   # does not require elevation to run
    uac_uiaccess = False,
    # Windows manifest — DPI-aware, no admin required
    manifest = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="1.0.0.0" processorArchitecture="amd64"
    name="com.tindahanmo.app" type="win32"/>
  <description>Tindahan Mo Store Management</description>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security><requestedPrivileges><requestedExecutionLevel
      level="asInvoker" uiAccess="false"/>
    </requestedPrivileges></security>
  </trustInfo>
  <application xmlns="urn:schemas-microsoft-com:asm.v3">
    <windowsSettings>
      <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true/PM</dpiAware>
      <dpiAwareness xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">PerMonitorV2</dpiAwareness>
    </windowsSettings>
  </application>
</assembly>""",
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    strip   = False,
    upx     = True,
    name    = "tindahan",
)
