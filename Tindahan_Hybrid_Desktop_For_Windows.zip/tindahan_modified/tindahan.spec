# tindahan.spec — PyInstaller spec (Debian 13 / Linux)
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

PROJECT = Path(SPECPATH)
datas, binaries, hiddenimports = [], [], []

for pkg in ("django", "cryptography", "webview"):
    d, b, h = collect_all(pkg)
    datas += d; binaries += b; hiddenimports += h

for folder in ("store", "tindahan_project", "pysqlcipher3"):
    src = PROJECT / folder
    if src.is_dir():
        datas.append((str(src), folder))

if (PROJECT / "store" / "favicon.ico").is_file():
    datas.append((str(PROJECT / "store" / "favicon.ico"), "store"))

# ── Bundle the app icon so it is available at runtime inside the AppImage ─────
# make_icon.py is called by build.sh before PyInstaller runs, so the file
# already exists.  If it doesn't (e.g. manual pyinstaller run), generate it.
_icon_src = PROJECT / "tindahan_icon.png"
if not _icon_src.is_file():
    import subprocess as _sp, sys as _sys
    _sp.run([_sys.executable, str(PROJECT / "make_icon.py"), str(_icon_src), "256"],
            check=False)
if _icon_src.is_file():
    datas.append((str(_icon_src), "."))    # lands in sys._MEIPASS/tindahan_icon.png

if (PROJECT / "manage.py").is_file():
    datas.append((str(PROJECT / "manage.py"), "."))

if (PROJECT / "media").is_dir():
    datas.append((str(PROJECT / "media"), "media"))

a = Analysis(
    [str(PROJECT / "launcher.py")],
    pathex        = [str(PROJECT)],
    binaries      = binaries,
    datas         = datas,
    hiddenimports = list(set(hiddenimports)) + [
        "django.template.defaulttags","django.template.defaultfilters",
        "django.template.loader_tags",
        "django.contrib.sessions.backends.db",
        "django.contrib.sessions.serializers",
        "django.core.cache.backends.locmem",
        "django.middleware.security","django.middleware.common",
        "store","store.views","store.db","store.sync","store.apps","store.urls",
        "tindahan_project.settings","tindahan_project.urls","tindahan_project.wsgi",
        "pysqlcipher3","pysqlcipher3.dbapi2",
        "webview.platforms.qt",
        "cryptography.hazmat.primitives.kdf.pbkdf2",
        "cryptography.hazmat.primitives.hashes","cryptography.fernet",
        "wsgiref.simple_server","wsgiref.handlers",
        "urllib.request","urllib.parse","email.mime.text","importlib.metadata",
    ],
    excludes   = ["tkinter","PyQt5","PyQt6","PySide2","wx","matplotlib","gi"],
    hookspath  = [],
    cipher     = None,
    noarchive  = False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

_exe_icon = str(PROJECT / "tindahan_icon.png") if (PROJECT / "tindahan_icon.png").is_file() else None

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries = True,
    name    = "tindahan",
    debug   = False,
    strip   = False,
    upx     = True,
    console = False,
    icon    = _exe_icon,
)

coll = COLLECT(
    exe, a.binaries, a.zipfiles, a.datas, [],
    strip   = False,
    upx     = True,
    name    = "tindahan",
)
