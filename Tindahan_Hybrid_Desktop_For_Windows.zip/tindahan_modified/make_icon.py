#!/usr/bin/env python3
"""
make_icon.py — Tindahan Mo app icon generator
==============================================
Usage:
    python3 make_icon.py OUTPUT.png [SIZE]
    SIZE defaults to 256.  Common sizes: 16 32 48 64 128 256 512

Custom-logo support (highest priority):
    Drop  logo.png  (or logo.jpg / logo.jpeg / icon.png) in the same folder
    as this script.  build.sh installs Pillow automatically so the image will
    be cleanly resized to every required size and embedded into the AppImage.
    Anyone who receives that AppImage will see YOUR logo as the app icon.

    No logo file?  A built-in store illustration is drawn with pure stdlib
    (no Pillow, no external deps).
"""
import struct, zlib, sys, os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# ── 1. Custom logo via Pillow ─────────────────────────────────────────────────
def _find_logo():
    for name in ("logo.png", "logo.jpg", "logo.jpeg", "icon.png"):
        p = os.path.join(SCRIPT_DIR, name)
        if os.path.isfile(p):
            return p
    return None


def _pillow_resize(src, dst, size):
    try:
        from PIL import Image
        img = Image.open(src).convert("RGBA")
        img = img.resize((size, size), Image.LANCZOS)
        img.save(dst, "PNG", optimize=True)
        print(f"    Icon from {os.path.basename(src)} → {dst}  ({size}×{size})")
        return True
    except ImportError:
        print("    Pillow not installed — using built-in icon  (pip install Pillow to use logo.png)")
        return False
    except Exception as e:
        print(f"    logo resize failed ({e}) — using built-in icon")
        return False


# ── 2. Built-in drawn icon (stdlib only) ─────────────────────────────────────
def _pack(tag, data):
    crc = zlib.crc32(tag + data) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)


def _builtin(W):
    """Return flat RGBA pixel list for W×W store icon."""
    H   = W
    S   = W / 256          # scale factor
    sc  = lambda v: int(round(v * S))

    TRANSP=(0,0,0,0); DISC=(26,35,60,255); WALL=(245,245,230,255)
    ROOF=(180,75,15,255); GOLD=(245,197,24,255); GDARK=(200,155,10,255)
    WIN=(26,79,168,220); WFR=(200,190,170,255); DOOR=(139,90,40,255)
    STR1=(200,70,10,255); STR2=(245,245,230,255)

    px = [TRANSP]*(W*H)

    def rect(x0,y0,x1,y1,c):
        for y in range(max(0,sc(y0)),min(H,sc(y1))):
            for x in range(max(0,sc(x0)),min(W,sc(x1))):
                px[y*W+x]=c

    def circle(cx,cy,r,c,hole=0):
        cs,ys,rs,hs=sc(cx),sc(cy),sc(r),sc(hole)
        for y in range(max(0,ys-rs-1),min(H,ys+rs+2)):
            for x in range(max(0,cs-rs-1),min(W,cs+rs+2)):
                d=(x-cs)**2+(y-ys)**2
                if d<=rs*rs and (not hole or d>hs*hs):
                    px[y*W+x]=c

    def tri(tx,ty,by,hw,c):
        for y in range(sc(ty),sc(by)+1):
            t2=(y-sc(ty))/max(1,sc(by)-sc(ty))
            w=int(hw*S*t2); cx=sc(tx)
            for x in range(cx-w,cx+w+1):
                if 0<=x<W and 0<=y<H: px[y*W+x]=c

    circle(128,128,122,DISC)
    rect(65,122,193,196,WALL)
    tri(128,58,126,72,ROOF)
    rect(57,120,201,130,ROOF)
    # awning stripes
    for dy in range(sc(130),sc(140)):
        col=STR1 if ((dy-sc(130))//max(1,sc(2)))%2==0 else STR2
        for x in range(sc(60),sc(198)):
            if 0<=x<W and 0<=dy<H: px[dy*W+x]=col
    rect(74,140,184,155,GOLD)
    rect(76,142,182,148,GDARK)
    # two windows
    for wx in (82,150):
        rect(wx,160,wx+25,184,WFR)
        rect(wx+2,162,wx+23,182,WIN)
        rect(wx+13,161,wx+14,183,WFR)
        rect(wx+1,171,wx+24,173,WFR)
    # door
    rect(111,163,147,196,DOOR)
    rect(114,165,144,182,(160,110,60,140))
    rect(114,184,144,195,(160,110,60,110))
    circle(143,179,2,GOLD)
    # chimney
    rect(156,78,166,120,(210,200,185,255))
    # subtle outline ring
    circle(128,128,122,(60,80,120,90),hole=119)
    return px


def _save_png(px, W, dst):
    raw = bytearray()
    for y in range(W):
        raw += b"\x00"
        for x in range(W): raw += bytes(px[y*W+x])
    ihdr = struct.pack(">IIBBBBB", W, W, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw), 9)
    png  = (b"\x89PNG\r\n\x1a\n"
            + _pack(b"IHDR", ihdr)
            + _pack(b"IDAT", idat)
            + _pack(b"IEND", b""))
    with open(dst, "wb") as f: f.write(png)
    print(f"    Built-in icon → {dst}  ({len(png):,} bytes, {W}×{W})")


# ── Public API ────────────────────────────────────────────────────────────────
def make_png(dst, size=256):
    """Generate the app icon at `size`×`size` px and save to `dst`."""
    logo = _find_logo()
    if logo and _pillow_resize(logo, dst, size):
        return
    _save_png(_builtin(size), size, dst)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} OUTPUT.png [SIZE]", file=sys.stderr)
        sys.exit(1)
    make_png(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 256)
