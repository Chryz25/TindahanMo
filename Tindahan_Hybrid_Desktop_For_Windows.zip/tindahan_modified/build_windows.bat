@echo off
setlocal EnableDelayedExpansion

title Tindahan Mo - Windows Build

echo.
echo   ╔══════════════════════════════════════════════════════════╗
echo   ║  Tindahan Mo  ·  Windows Desktop Build  ·  v1.0.0       ║
echo   ╚══════════════════════════════════════════════════════════╝
echo.

:: ── Check PowerShell availability ────────────────────────────────────────────
where powershell >nul 2>&1
if errorlevel 1 (
    echo [ERROR] PowerShell is required but was not found.
    echo         Please install PowerShell 5.1 or later.
    pause
    exit /b 1
)

:: ── Check PowerShell version (need 5.1+) ─────────────────────────────────────
for /f "tokens=*" %%v in ('powershell -NoProfile -Command "$PSVersionTable.PSVersion.Major"') do set PSVER=%%v
if !PSVER! LSS 5 (
    echo [ERROR] PowerShell 5.1 or later is required. Found version !PSVER!.
    pause
    exit /b 1
)

:: ── Self-elevate to Administrator (required for Python silent install) ────────
net session >nul 2>&1
if errorlevel 1 (
    echo [INFO]  Requesting Administrator privileges for dependency installation...
    echo         A UAC prompt will appear - please click Yes.
    echo.
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "Start-Process cmd -ArgumentList '/c cd /d ""%~dp0"" && ""%~f0""' -Verb RunAs -Wait"
    exit /b
)

echo   Running as Administrator ^✓
echo.

:: ── Run the main PowerShell build script ─────────────────────────────────────
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_windows.ps1"
set BUILD_EXIT=%ERRORLEVEL%

if !BUILD_EXIT! NEQ 0 (
    echo.
    echo   [FAILED] Build exited with code !BUILD_EXIT!
    echo   Scroll up to see the error details.
)

echo.
pause
exit /b !BUILD_EXIT!
