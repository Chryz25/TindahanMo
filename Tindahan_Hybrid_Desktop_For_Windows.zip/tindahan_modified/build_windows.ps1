#Requires -Version 5.1
<#
.SYNOPSIS
    Tindahan Mo — Full Windows Desktop Build Script
.DESCRIPTION
    Automatically installs Python, all Python packages, builds the app
    with PyInstaller, and packages it as a proper Windows .exe installer
    using Inno Setup. Run via build_windows.bat (handles UAC elevation).
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"   # speeds up Invoke-WebRequest massively

$SCRIPT_DIR  = Split-Path -Parent $MyInvocation.MyCommand.Path
$DIST_DIR    = Join-Path $SCRIPT_DIR "dist_windows"
$VENV_DIR    = Join-Path $SCRIPT_DIR ".venv_win"
$BUILD_DIR   = Join-Path $SCRIPT_DIR "build_win"
$LOG_FILE    = Join-Path $SCRIPT_DIR "build_windows.log"

# ── Helpers ───────────────────────────────────────────────────────────────────
function Write-Step([string]$num, [string]$msg) {
    Write-Host ""
    Write-Host "  ▶  [$num] $msg" -ForegroundColor Cyan
}
function Write-OK([string]$msg)   { Write-Host "  ✅  $msg" -ForegroundColor Green }
function Write-Warn([string]$msg) { Write-Host "  ⚠️   $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "  ❌  $msg" -ForegroundColor Red }
function Write-Info([string]$msg) { Write-Host "      $msg" -ForegroundColor Gray }

function Download-File([string]$Url, [string]$Dest, [string]$Label) {
    Write-Info "Downloading $Label..."
    try {
        Invoke-WebRequest -Uri $Url -OutFile $Dest -UseBasicParsing
        Write-Info "Downloaded: $(Split-Path -Leaf $Dest)"
    } catch {
        throw "Download failed for $Label`: $_"
    }
}

function Run-Cmd([string]$Exe, [string[]]$Args, [string]$WorkDir = $SCRIPT_DIR) {
    $proc = Start-Process -FilePath $Exe -ArgumentList $Args `
                          -WorkingDirectory $WorkDir `
                          -Wait -NoNewWindow -PassThru
    if ($proc.ExitCode -ne 0) {
        throw "Command failed (exit $($proc.ExitCode)): $Exe $Args"
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Find or Install Python
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "1/8" "Locating Python 3.11+ installation..."

# Target: Python 3.12 (stable, widely tested with PySide6 6.7)
$PYTHON_VER     = "3.12.10"
$PYTHON_VER_MM  = "3.12"          # major.minor for registry lookup
$PYTHON_URL     = "https://www.python.org/ftp/python/$PYTHON_VER/python-$PYTHON_VER-amd64.exe"
$PYTHON_INST    = Join-Path $env:TEMP "python-$PYTHON_VER-amd64.exe"

function Find-Python {
    # 1. Check PATH for py launcher
    $py = Get-Command "py" -ErrorAction SilentlyContinue
    if ($py) {
        $ver = & py --version 2>&1
        if ($ver -match "Python (\d+)\.(\d+)") {
            $maj = [int]$Matches[1]; $min = [int]$Matches[2]
            if ($maj -eq 3 -and $min -ge 11) {
                $path = & py -c "import sys; print(sys.executable)" 2>&1
                return $path.Trim()
            }
        }
    }
    # 2. Check PATH for python3 / python
    foreach ($cmd in @("python3","python")) {
        $p = Get-Command $cmd -ErrorAction SilentlyContinue
        if ($p) {
            $ver = & $p.Source --version 2>&1
            if ($ver -match "Python (\d+)\.(\d+)") {
                $maj = [int]$Matches[1]; $min = [int]$Matches[2]
                if ($maj -eq 3 -and $min -ge 11) { return $p.Source }
            }
        }
    }
    # 3. Check known install locations
    $locations = @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "C:\Python312\python.exe",
        "C:\Python311\python.exe",
        "$env:ProgramFiles\Python312\python.exe",
        "$env:ProgramFiles\Python311\python.exe"
    )
    foreach ($loc in $locations) {
        if (Test-Path $loc) { return $loc }
    }
    return $null
}

$PYTHON = Find-Python
if ($PYTHON) {
    $pyVer = & "$PYTHON" --version 2>&1
    Write-OK "Found: $PYTHON ($pyVer)"
} else {
    Write-Warn "Python 3.11+ not found. Downloading Python $PYTHON_VER (64-bit)..."
    Download-File $PYTHON_URL $PYTHON_INST "Python $PYTHON_VER"
    Write-Info "Installing Python $PYTHON_VER silently (this takes ~1 min)..."
    $installArgs = @(
        "/quiet",
        "InstallAllUsers=0",          # user-only install (no admin scope needed after elevation)
        "PrependPath=1",
        "Include_test=0",
        "Include_doc=0",
        "Include_launcher=1",
        "InstallLauncherAllUsers=0"
    )
    Run-Cmd $PYTHON_INST $installArgs
    Remove-Item $PYTHON_INST -Force -ErrorAction SilentlyContinue

    # Refresh PATH so newly installed Python is visible
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH","Machine") + ";" +
                [System.Environment]::GetEnvironmentVariable("PATH","User")

    $PYTHON = Find-Python
    if (-not $PYTHON) {
        Write-Fail "Python installation succeeded but executable not found in PATH."
        Write-Info "Please reboot and re-run this script."
        exit 1
    }
    $pyVer = & "$PYTHON" --version 2>&1
    Write-OK "Installed and found: $PYTHON ($pyVer)"
}

# Extract major.minor from the found Python
$pyVerFull = (& "$PYTHON" -c "import sys; print('.'.join(map(str,sys.version_info[:3])))" 2>&1).Trim()
$pyMinor   = [int]((& "$PYTHON" -c "import sys; print(sys.version_info[1])" 2>&1).Trim())

Write-Info "Python version: $pyVerFull  (minor=$pyMinor)"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Virtual environment
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "2/8" "Setting up virtual environment..."

# Remove stale venv if built with different Python
if (Test-Path $VENV_DIR) {
    $existingPy = Join-Path $VENV_DIR "Scripts\python.exe"
    if (Test-Path $existingPy) {
        $existingVer = (& "$existingPy" --version 2>&1).Trim()
        $wantedVer   = "Python $pyVerFull"
        if ($existingVer -ne $wantedVer) {
            Write-Info "Removing stale venv ($existingVer → need $wantedVer)..."
            Remove-Item $VENV_DIR -Recurse -Force
        }
    } else {
        Remove-Item $VENV_DIR -Recurse -Force
    }
}

if (-not (Test-Path $VENV_DIR)) {
    & "$PYTHON" -m venv "$VENV_DIR"
}

$VENV_PY  = Join-Path $VENV_DIR "Scripts\python.exe"
$VENV_PIP = Join-Path $VENV_DIR "Scripts\pip.exe"

& "$VENV_PY" -m pip install --upgrade pip --quiet
$venvVer = (& "$VENV_PY" --version 2>&1).Trim()
Write-OK "venv ready ($venvVer)"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Install Python packages
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "3/8" "Installing Python packages (~600 MB first run, please wait)..."

$BASE_PKGS = @(
    "Django>=4.2,<6.0",
    "cryptography>=41.0",
    "pywebview>=5.0",
    "qtpy>=2.4",
    "pyinstaller>=6.0",
    "Pillow>=9.0",
    "supabase>=2.0"
)

# PySide6 version matrix — same logic as Linux build.sh
if ($pyMinor -le 11) {
    Write-Info "Strategy: PySide6 6.5.x + PySide6-WebEngine 6.5.x (Python ≤3.11)"
    $PYSIDE_PKGS = @("PySide6>=6.5,<6.6", "PySide6-WebEngine>=6.5,<6.6")
} elseif ($pyMinor -eq 12) {
    Write-Info "Strategy: PySide6>=6.6  (WebEngine bundled in PySide6-Addons)"
    $PYSIDE_PKGS = @("PySide6>=6.6,<6.8")
} else {
    Write-Info "Strategy: PySide6>=6.8  (Python 3.13+)"
    $PYSIDE_PKGS = @("PySide6>=6.8")
}

$ALL_PKGS = $BASE_PKGS + $PYSIDE_PKGS

Write-Info "Installing $($ALL_PKGS.Count) package groups..."
foreach ($pkg in $ALL_PKGS) {
    Write-Info "  pip install $pkg"
    & "$VENV_PIP" install "$pkg" --quiet 2>&1 | Out-Null
}

# Verify WebEngine
$weOk = & "$VENV_PY" -c "from PySide6 import QtWebEngineWidgets; print('OK')" 2>&1
if ($weOk -match "OK") {
    Write-OK "QtWebEngineWidgets OK"
} else {
    Write-Warn "QtWebEngineWidgets not found — trying PySide6-Addons..."
    & "$VENV_PIP" install "PySide6-Addons" --quiet 2>&1 | Out-Null
    $weOk2 = & "$VENV_PY" -c "from PySide6 import QtWebEngineWidgets; print('OK')" 2>&1
    if ($weOk2 -match "OK") { Write-OK "QtWebEngineWidgets OK (via PySide6-Addons)" }
    else { Write-Fail "QtWebEngineWidgets not importable. Cannot continue."; exit 1 }
}

$pyside6Ver = (& "$VENV_PY" -c "import PySide6; print(PySide6.__version__)" 2>&1).Trim()
$webviewVer = (& "$VENV_PY" -c "import importlib.metadata; print(importlib.metadata.version('pywebview'))" 2>&1).Trim()
Write-Info "PySide6   : $pyside6Ver"
Write-Info "pywebview : $webviewVer"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Generate app icons (PNG + ICO)
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "4/8" "Generating app icons..."

$PNG_ICON = Join-Path $SCRIPT_DIR "tindahan_icon.png"
$ICO_ICON = Join-Path $SCRIPT_DIR "tindahan_icon.ico"

# Generate PNG master
& "$VENV_PY" "$SCRIPT_DIR\make_icon.py" "$PNG_ICON" 256
if (-not (Test-Path $PNG_ICON)) {
    Write-Fail "PNG icon generation failed."; exit 1
}
Write-Info "PNG icon: $PNG_ICON"

# Convert PNG → ICO with all required sizes embedded (uses Pillow, already installed)
$icoScript = @"
from PIL import Image
import sys
src = r'$($PNG_ICON -replace "\\","/")'
dst = r'$($ICO_ICON -replace "\\","/")'
img = Image.open(src).convert('RGBA')
sizes = [(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)]
imgs  = [img.resize(s, Image.LANCZOS) for s in sizes]
imgs[0].save(dst, format='ICO', sizes=sizes, append_images=imgs[1:])
print(f'ICO icon written: {dst}')
"@
& "$VENV_PY" -c $icoScript
if (-not (Test-Path $ICO_ICON)) {
    Write-Warn "ICO generation failed — PNG will be used as fallback."
} else {
    Write-OK "ICO icon: $ICO_ICON"
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Copy Windows-specific launcher into place
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "5/8" "Preparing Windows launcher..."

$WIN_LAUNCHER_SRC = Join-Path $SCRIPT_DIR "launcher_windows.py"
$WIN_LAUNCHER_BAK = Join-Path $SCRIPT_DIR "launcher_linux.py.bak"

if (-not (Test-Path $WIN_LAUNCHER_SRC)) {
    Write-Fail "launcher_windows.py not found in $SCRIPT_DIR"
    exit 1
}

# Back up the Linux launcher and swap in the Windows one
if (Test-Path "$SCRIPT_DIR\launcher.py") {
    Copy-Item "$SCRIPT_DIR\launcher.py" $WIN_LAUNCHER_BAK -Force
}
Copy-Item $WIN_LAUNCHER_SRC "$SCRIPT_DIR\launcher.py" -Force
Write-OK "Windows launcher active"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Build with PyInstaller
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "6/8" "Building with PyInstaller (5-15 min)..."

# Clean stale bytecache
Get-ChildItem $SCRIPT_DIR -Recurse -Filter "__pycache__" -Directory |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem $SCRIPT_DIR -Recurse -Filter "*.pyc" |
    Remove-Item -Force -ErrorAction SilentlyContinue
Write-Info "Bytecache cleaned"

New-Item -ItemType Directory -Path $DIST_DIR  -Force | Out-Null
New-Item -ItemType Directory -Path $BUILD_DIR -Force | Out-Null

$specFile = Join-Path $SCRIPT_DIR "tindahan_windows.spec"
if (-not (Test-Path $specFile)) {
    Write-Fail "tindahan_windows.spec not found."; exit 1
}

$pyinstallerExe = Join-Path $VENV_DIR "Scripts\pyinstaller.exe"
& "$pyinstallerExe" "$specFile" `
    --distpath "$DIST_DIR" `
    --workpath "$BUILD_DIR" `
    --noconfirm `
    --clean

$DIST_FOLDER = Join-Path $DIST_DIR "tindahan"
if (-not (Test-Path $DIST_FOLDER)) {
    Write-Fail "PyInstaller failed — $DIST_FOLDER not found."
    # Restore Linux launcher
    if (Test-Path $WIN_LAUNCHER_BAK) {
        Copy-Item $WIN_LAUNCHER_BAK "$SCRIPT_DIR\launcher.py" -Force
    }
    exit 1
}
Write-OK "PyInstaller build complete: $DIST_FOLDER"

# Restore Linux launcher after build
if (Test-Path $WIN_LAUNCHER_BAK) {
    Copy-Item $WIN_LAUNCHER_BAK "$SCRIPT_DIR\launcher.py" -Force
    Remove-Item $WIN_LAUNCHER_BAK -Force
    Write-Info "Linux launcher restored"
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 — Check / Install Inno Setup 6
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "7/8" "Locating Inno Setup 6..."

$IS_COMPILER = $null
$IS_PATHS = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles(x86)}\Inno Setup 5\ISCC.exe"
)
foreach ($p in $IS_PATHS) {
    if (Test-Path $p) { $IS_COMPILER = $p; break }
}

if (-not $IS_COMPILER) {
    Write-Warn "Inno Setup not found. Downloading Inno Setup 6..."
    $IS_URL      = "https://jrsoftware.org/download.php/is.exe"
    $IS_FALLBACK = "https://files.jrsoftware.org/is/6/innosetup-6.2.2.exe"
    $IS_INST     = Join-Path $env:TEMP "innosetup-installer.exe"

    try {
        Download-File $IS_URL $IS_INST "Inno Setup 6"
    } catch {
        Write-Warn "Primary download failed, trying mirror..."
        Download-File $IS_FALLBACK $IS_INST "Inno Setup 6 (mirror)"
    }

    Write-Info "Installing Inno Setup silently..."
    Run-Cmd $IS_INST @("/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART")
    Remove-Item $IS_INST -Force -ErrorAction SilentlyContinue

    foreach ($p in $IS_PATHS) {
        if (Test-Path $p) { $IS_COMPILER = $p; break }
    }
    if (-not $IS_COMPILER) {
        Write-Warn "Inno Setup install succeeded but ISCC.exe not found."
        Write-Warn "Skipping installer creation. Your app is still usable from:"
        Write-Info "  $DIST_FOLDER\tindahan.exe"
        goto SUMMARY
    }
    Write-OK "Inno Setup installed: $IS_COMPILER"
} else {
    Write-OK "Found: $IS_COMPILER"
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 8 — Generate .iss and compile Windows installer
# ─────────────────────────────────────────────────────────────────────────────
Write-Step "8/8" "Compiling Windows installer (.exe)..."

$APP_VERSION = "1.0.0"
$ISS_FILE    = Join-Path $SCRIPT_DIR "tindahan_setup.iss"
$SETUP_OUT   = Join-Path $DIST_DIR   "TindahanMo-Setup-v${APP_VERSION}-Windows.exe"

# Escape backslashes for Inno Setup (it uses backslash natively so we just ensure no double-backslash)
$distEsc   = $DIST_FOLDER
$outputEsc = $DIST_DIR
$icoEsc    = $ICO_ICON

$ISS_CONTENT = @"
; ── Tindahan Mo — Inno Setup Script ─────────────────────────────────────────
; Generated automatically by build_windows.ps1
; DO NOT EDIT — re-run the build script to regenerate.
[Setup]
AppId={{E4F2A1C3-7B8D-4E5F-9A2C-1D3B6E8F7A9C}
AppName=Tindahan Mo
AppVersion=$APP_VERSION
AppPublisher=Tindahan Mo Team
AppPublisherURL=https://github.com/tindahanmo/tindahan
AppSupportURL=https://github.com/tindahanmo/tindahan/issues
AppUpdatesURL=https://github.com/tindahanmo/tindahan/releases
DefaultDirName={autopf}\Tindahan Mo
DefaultGroupName=Tindahan Mo
AllowNoIcons=no
LicenseFile=
OutputDir=$outputEsc
OutputBaseFilename=TindahanMo-Setup-v$APP_VERSION-Windows
SetupIconFile=$icoEsc
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
UninstallDisplayIcon={app}\tindahan.exe
UninstallDisplayName=Tindahan Mo $APP_VERSION

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";  Description: "{cm:CreateDesktopIcon}";  GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "quicklaunch"; Description: "Pin to taskbar on first run"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; ── Main application bundle ─────────────────────────────────────────────────
Source: "$distEsc\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
; Start Menu
Name: "{group}\Tindahan Mo";      Filename: "{app}\tindahan.exe"; IconFilename: "{app}\tindahan.exe"
Name: "{group}\Uninstall Tindahan Mo"; Filename: "{uninstallexe}"
; Desktop (optional task)
Name: "{userdesktop}\Tindahan Mo"; Filename: "{app}\tindahan.exe"; IconFilename: "{app}\tindahan.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\tindahan.exe"; Description: "{cm:LaunchProgram,Tindahan Mo}"; \
    Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Remove user data only if the user confirms (we just remove app files here)
Type: filesandordirs; Name: "{app}"

[Code]
// ── Ensure Visual C++ Redistributable is present ────────────────────────────
// PySide6/Qt on Windows requires MSVC runtime. Most Win10/11 machines already
// have it, but we silently install if missing.
function VCRedistInstalled: Boolean;
var
  RegVal: Cardinal;
begin
  Result := RegQueryDWordValue(HKLM,
    'SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64',
    'Installed', RegVal) and (RegVal = 1);
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssInstall then begin
    if not VCRedistInstalled then begin
      MsgBox('Note: The Microsoft Visual C++ 2015-2022 Redistributable (x64) ' +
             'may be required. If Tindahan Mo does not start, please install it ' +
             'from: https://aka.ms/vs/17/release/vc_redist.x64.exe', mbInformation, MB_OK);
    end;
  end;
end;
"@

$ISS_CONTENT | Out-File -FilePath $ISS_FILE -Encoding UTF8
Write-Info "Inno Setup script written: $ISS_FILE"

# Compile
& "$IS_COMPILER" "$ISS_FILE"
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Inno Setup compilation returned exit code $LASTEXITCODE"
    Write-Warn "Installer may not have been created."
} else {
    Write-OK "Installer compiled successfully"
}

# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
:SUMMARY
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║  BUILD SUMMARY                                               ║" -ForegroundColor Green
Write-Host "  ╠══════════════════════════════════════════════════════════════╣" -ForegroundColor Green

# App folder
if (Test-Path $DIST_FOLDER) {
    $folderSizeMB = [math]::Round((Get-ChildItem $DIST_FOLDER -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
    Write-Host "  ║  ✅  App Folder : dist_windows\tindahan\                     ║" -ForegroundColor Green
    Write-Host ("  ║      Size       : {0,-52}║" -f "${folderSizeMB} MB") -ForegroundColor Green
    Write-Host "  ║      Run directly: dist_windows\tindahan\tindahan.exe         ║" -ForegroundColor Green
}

# Installer
$SETUP_FILE = Get-ChildItem $DIST_DIR -Filter "TindahanMo-Setup*.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($SETUP_FILE) {
    $setupSizeMB = [math]::Round($SETUP_FILE.Length / 1MB, 1)
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║  ✅  Installer  : dist_windows\$($SETUP_FILE.Name)" -ForegroundColor Green
    Write-Host ("  ║      Size       : {0,-52}║" -f "${setupSizeMB} MB") -ForegroundColor Green
    Write-Host "  ║      Share this .exe with any Windows 10/11 user!           ║" -ForegroundColor Green
} else {
    Write-Host "  ║  ⚠️   Installer : not created (run PyInstaller output manually)║" -ForegroundColor Yellow
}

Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
