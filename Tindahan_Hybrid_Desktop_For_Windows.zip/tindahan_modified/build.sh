#!/usr/bin/env bash
set -euo pipefail

# ── Tindahan Mo Hybrid — Debian 13 GNOME Build Script ────────────────────────
echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║  Tindahan Mo  ·  Hybrid Desktop Build  ·  Debian 13     ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="$SCRIPT_DIR/dist"
VENV_DIR="$SCRIPT_DIR/.venv"

# ── 1. System dependencies ────────────────────────────────────────────────────
echo "▶  [1/6] Installing system packages (requires sudo)…"
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends \
    python3 python3-pip python3-venv python3-dev \
    libxcb-cursor0 libxcb-icccm4 libxcb-keysyms1 libxcb-randr0 \
    libxcb-render-util0 libxcb-xinerama0 libxcb-xfixes0 \
    libxkbcommon-x11-0 libglib2.0-0 libdbus-1-3 \
    libgl1 libegl1 libfontconfig1 xdg-utils \
    fuse libfuse2 patchelf imagemagick \
    2>/dev/null || true
echo "✅  System packages ready"
echo ""

# ── 2. Detect Python version ──────────────────────────────────────────────────
#
# PySide6 WebEngine packaging changed across Python versions:
#
#   Python ≤ 3.11  →  pip install PySide6==6.5.3  PySide6-WebEngine==6.5.3
#                     (separate wheel, only supports Python < 3.12)
#
#   Python 3.12    →  pip install PySide6>=6.6
#                     (WebEngine bundled in PySide6-Addons, auto-installed)
#
#   Python 3.13+   →  pip install PySide6>=6.8
#   (Debian 13)       (WebEngine bundled — NO separate PySide6-WebEngine at all)
#
# ─────────────────────────────────────────────────────────────────────────────
PYMINOR="$(python3 -c 'import sys; print(sys.version_info[1])')"
PYMAJOR="$(python3 -c 'import sys; print(sys.version_info[0])')"
PYVER="$(python3 -c 'import sys; print(".".join(map(str,sys.version_info[:3])))')"
PYTHON="$(command -v python3)"

echo "▶  Python detected: $PYTHON ($PYMAJOR.$PYMINOR  →  $PYVER)"

if [ "$PYMAJOR" -ne 3 ]; then
    echo "❌  Python 3 required."
    exit 1
fi

# ── 3. Virtual environment ────────────────────────────────────────────────────
echo ""
echo "▶  [2/6] Setting up virtual environment…"

# Remove stale venv built with a different Python
if [ -d "$VENV_DIR" ]; then
    EXISTING_VER="$("$VENV_DIR/bin/python" --version 2>/dev/null || echo '')"
    WANTED_VER="Python $PYVER"
    if [ "$EXISTING_VER" != "$WANTED_VER" ]; then
        echo "    Removing stale venv ($EXISTING_VER → need $WANTED_VER)…"
        rm -rf "$VENV_DIR"
    fi
fi

"$PYTHON" -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
pip install --upgrade pip --quiet
echo "✅  venv ready  ($(python --version))"
echo ""

# ── 4. Install Python packages ────────────────────────────────────────────────
echo "▶  [3/6] Installing Python packages (~300 MB first run)…"
echo "    Python $PYMAJOR.$PYMINOR detected — selecting correct PySide6 variant…"
echo ""

# Base packages always installed
BASE_PKGS=(
    "Django>=4.2,<6.0"
    "cryptography>=41.0"
    "pywebview>=5.0"
    "qtpy>=2.4"
    "pyinstaller>=6.0"
    "Pillow>=9.0"              # needed to resize logo.png → app icon
)

if   [ "$PYMINOR" -le 11 ]; then
    # ── Python 3.8–3.11: PySide6 6.5.x with separate WebEngine ──────────────
    echo "    Strategy: PySide6 6.5.x  +  PySide6-WebEngine 6.5.x (separate package)"
    PIP_PKGS=(
        "${BASE_PKGS[@]}"
        "PySide6>=6.5,<6.6"
        "PySide6-WebEngine>=6.5,<6.6"
    )

elif [ "$PYMINOR" -eq 12 ]; then
    # ── Python 3.12: PySide6 6.6+ with WebEngine bundled in PySide6-Addons ───
    echo "    Strategy: PySide6>=6.6  (WebEngine bundled in PySide6-Addons)"
    PIP_PKGS=(
        "${BASE_PKGS[@]}"
        "PySide6>=6.6,<6.8"
    )

elif [ "$PYMINOR" -ge 13 ]; then
    # ── Python 3.13+: PySide6 6.8+ — PySide6-WebEngine DOES NOT EXIST ────────
    echo "    Strategy: PySide6>=6.8  (WebEngine bundled — no separate package)"
    PIP_PKGS=(
        "${BASE_PKGS[@]}"
        "PySide6>=6.8"
    )

else
    echo "❌  Unsupported Python version: $PYMAJOR.$PYMINOR"
    exit 1
fi

echo ""
pip install "${PIP_PKGS[@]}"

echo ""
echo "✅  Packages installed. Verifying…"

# Verify pywebview
PYWEBVIEW_VER="$(python -c 'import importlib.metadata; print(importlib.metadata.version("pywebview"))' 2>/dev/null || echo 'NOT FOUND')"
PYSIDE6_VER="$(python -c 'import PySide6; print(PySide6.__version__)' 2>/dev/null || echo 'NOT FOUND')"

echo "    pywebview : $PYWEBVIEW_VER"
echo "    PySide6   : $PYSIDE6_VER"

# Verify WebEngine is importable (critical — app won't work without it)
if python -c "from PySide6 import QtWebEngineWidgets; print('    WebEngine  : OK ✅')" 2>/dev/null; then
    true
else
    echo ""
    echo "❌  QtWebEngineWidgets not importable!"
    echo "    This usually means the PySide6-Addons wheel was not installed."
    echo "    Trying to install PySide6-Addons directly…"
    pip install PySide6-Addons || true
    if python -c "from PySide6 import QtWebEngineWidgets" 2>/dev/null; then
        echo "✅  QtWebEngineWidgets OK after manual PySide6-Addons install"
    else
        echo "❌  Still missing. Try: sudo apt install python3-pyside6.qtwebenginewidgets"
        exit 1
    fi
fi

# Verify qtpy bridge
python -c "import qtpy; qtpy.QtWebEngineWidgets" 2>/dev/null && \
    echo "    qtpy       : OK ✅" || \
    echo "    qtpy       : bridge (OK — non-fatal if PySide6 direct import works)"

echo ""

# ── 5. Generate app icon (before PyInstaller so it can be bundled) ───────────
echo "▶  [4/6] Generating app icon…"
cd "$SCRIPT_DIR"

# Auto-detect a custom logo dropped next to this script
if [ -f "$SCRIPT_DIR/logo.png" ]; then
    echo "    Found logo.png — will be used as app icon (Pillow required, already installed)"
elif [ -f "$SCRIPT_DIR/logo.jpg" ]; then
    echo "    Found logo.jpg — will be used as app icon"
elif [ -f "$SCRIPT_DIR/logo.jpeg" ]; then
    echo "    Found logo.jpeg — will be used as app icon"
else
    echo "    No logo.png found — built-in store icon will be used"
    echo "    (Drop logo.png next to build.sh and re-run to use your own icon)"
fi

# Generate 256px master icon → project root (bundled by PyInstaller spec)
python3 "$SCRIPT_DIR/make_icon.py" "$SCRIPT_DIR/tindahan_icon.png" 256
if [ ! -f "$SCRIPT_DIR/tindahan_icon.png" ]; then
    echo "❌  Icon generation failed"; exit 1
fi
echo "✅  Icon ready: tindahan_icon.png"
echo ""

# ── 6. Build with PyInstaller ─────────────────────────────────────────────────
echo "▶  [5/7] Building with PyInstaller (3–10 min)…"
cd "$SCRIPT_DIR"

# ── Always wipe all cached bytecode first so PyInstaller recompiles from source
echo "    Cleaning stale .pyc / __pycache__ files…"
find "$SCRIPT_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$SCRIPT_DIR" -name "*.pyc" -delete 2>/dev/null || true
echo "    Bytecache clean ✅"

pyinstaller tindahan.spec \
    --distpath "$DIST_DIR" \
    --workpath "$SCRIPT_DIR/build" \
    --noconfirm \
    --clean \
    2>&1 | tail -20

DIST_FOLDER="$DIST_DIR/tindahan"
if [ ! -d "$DIST_FOLDER" ]; then
    echo ""
    echo "❌  PyInstaller failed — dist/tindahan folder not found"
    exit 1
fi
echo "✅  PyInstaller complete"
echo ""

# ── 6. Assemble AppDir ────────────────────────────────────────────────────────
echo "▶  [6/7] Assembling AppDir…"
APPDIR="$SCRIPT_DIR/AppDir"
rm -rf "$APPDIR"

# appimagetool requires the icon in TWO places:
#   $APPDIR/tindahan.png                                (AppDir root)
#   $APPDIR/usr/share/icons/hicolor/256x256/apps/      (XDG icon theme)
mkdir -p \
    "$APPDIR/usr/bin" \
    "$APPDIR/usr/lib" \
    "$APPDIR/usr/share/applications" \
    "$APPDIR/usr/share/icons/hicolor/256x256/apps" \
    "$APPDIR/usr/share/metainfo"

cp -r "$DIST_FOLDER"/. "$APPDIR/usr/bin/"

# ── AppStream metadata (fixes appimagetool AppStream warning) ─────────────────
cp "$SCRIPT_DIR/com.tindahanmo.app.appdata.xml" "$APPDIR/usr/share/metainfo/com.tindahanmo.app.appdata.xml"
echo "✅  AppStream metadata installed"

# ── Desktop entry ─────────────────────────────────────────────────────────────
cat > "$APPDIR/tindahan.desktop" << 'DEOF'
[Desktop Entry]
Type=Application
Name=Tindahan Mo
Comment=Sari-Sari Store Management System
Exec=tindahan
Icon=tindahan
Categories=Office;Finance;
Keywords=store;inventory;sales;pos;
StartupNotify=true
DEOF
cp "$APPDIR/tindahan.desktop" "$APPDIR/usr/share/applications/"

# ── Generate icon at every XDG size ───────────────────────────────────────────
# appimagetool embeds:
#   $APPDIR/tindahan.png       → the AppImage icon (shown by file managers)
#   $APPDIR/.DirIcon           → thumbnail shown in Nautilus / Dolphin / Thunar
#   $APPDIR/usr/share/icons/… → installed to system icon theme on desktop integration
#
echo "    Generating app icons (all sizes)…"
for SIZE in 16 32 48 64 128 256 512; do
    IDIR="$APPDIR/usr/share/icons/hicolor/${SIZE}x${SIZE}/apps"
    mkdir -p "$IDIR"
    python3 "$SCRIPT_DIR/make_icon.py" "$IDIR/tindahan.png" "$SIZE"
done

# Root icon — REQUIRED by appimagetool; embedded into AppImage squashfs
cp "$APPDIR/usr/share/icons/hicolor/256x256/apps/tindahan.png" "$APPDIR/tindahan.png"

# .DirIcon — file managers show this icon when browsing AppImages
cp "$APPDIR/tindahan.png" "$APPDIR/.DirIcon"
chmod 644 "$APPDIR/.DirIcon"

# Hard fail if root icon missing
if [ ! -f "$APPDIR/tindahan.png" ]; then
    echo "❌  Icon missing from AppDir root — appimagetool will fail"
    exit 1
fi
echo "    Icons embedded: 16 32 48 64 128 256 512 px ✅"
echo "    .DirIcon ready ✅"

# ── AppRun launcher ───────────────────────────────────────────────────────────
cat > "$APPDIR/AppRun" << 'AREOF'
#!/bin/bash
APPDIR="$(dirname "$(readlink -f "$0")")"
export LD_LIBRARY_PATH="$APPDIR/usr/bin:${LD_LIBRARY_PATH:-}"
export QTWEBENGINE_DISABLE_SANDBOX=1
export PYWEBVIEW_GUI=qt
export QT_API=pyside6
# APPDIR is used by launcher.py to locate the icon at runtime
export APPDIR
# Expose icon theme dirs so Qt/GNOME can resolve the icon by name
export XDG_DATA_DIRS="$APPDIR/usr/share:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"
if [ -n "${WAYLAND_DISPLAY:-}" ]; then
    export QT_QPA_PLATFORM=wayland
elif [ -n "${DISPLAY:-}" ]; then
    export QT_QPA_PLATFORM=xcb
fi
exec "$APPDIR/usr/bin/tindahan" "$@"
AREOF
chmod +x "$APPDIR/AppRun"
echo "✅  AppDir ready"
echo ""

# ── 7. Create AppImage ────────────────────────────────────────────────────────
echo "▶  [7/7] Creating AppImage…"
APPTOOL="$SCRIPT_DIR/appimagetool"

if [ ! -f "$APPTOOL" ]; then
    echo "    Downloading appimagetool…"
    wget -q \
        "https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage" \
        -O "$APPTOOL"
    chmod +x "$APPTOOL"
fi

# On Debian 13, FUSE 2 may not be available for appimagetool itself to run.
# --appimage-extract-and-run tells it to extract to /tmp and run without FUSE.
APPIMAGE_OUT="$DIST_DIR/Tindahan-Mo-x86_64.AppImage"

echo "    Running appimagetool…"
ARCH=x86_64 "$APPTOOL" \
    --appimage-extract-and-run \
    "$APPDIR" \
    "$APPIMAGE_OUT" \
    2>&1
APPTOOL_RC=$?

if [ -f "$APPIMAGE_OUT" ] && [ "$APPTOOL_RC" -eq 0 ]; then
    chmod +x "$APPIMAGE_OUT"
    SIZE="$(du -sh "$APPIMAGE_OUT" | cut -f1)"
    echo ""
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║  ✅  BUILD SUCCESSFUL                                    ║"
    echo "  ║                                                          ║"
    printf "  ║  File : dist/Tindahan-Mo-x86_64.AppImage                ║\n"
    printf "  ║  Size : %-48s║\n" "$SIZE"
    echo "  ║                                                          ║"
    echo "  ║  Run  : ./dist/Tindahan-Mo-x86_64.AppImage              ║"
    echo "  ╚══════════════════════════════════════════════════════════╝"
else
    echo ""
    echo "  ⚠️   appimagetool failed (exit $APPTOOL_RC) — trying fallback without FUSE flag…"
    ARCH=x86_64 "$APPTOOL" "$APPDIR" "$APPIMAGE_OUT" 2>&1
    if [ -f "$APPIMAGE_OUT" ]; then
        chmod +x "$APPIMAGE_OUT"
        echo "  ✅  AppImage created on second attempt!"
    else
        echo ""
        echo "  ─────────────────────────────────────────────────────────"
        echo "  ⚠️   AppImage packaging failed, but your app still works."
        echo ""
        echo "  Run the app directly (no AppImage needed):"
        echo "     $DIST_DIR/tindahan/tindahan"
        echo ""
        echo "  Or make it executable from anywhere:"
        echo "     ln -sf $DIST_DIR/tindahan/tindahan ~/Desktop/TindahanMo"
        echo "  ─────────────────────────────────────────────────────────"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8 — Build .deb package
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo "▶  [8/8] Building .deb package…"

APP_VERSION="1.0.0"
PKG_NAME="tindahan-mo"
ARCH_DEB="amd64"
DEB_DIR="$SCRIPT_DIR/deb_pkg"
DEB_ROOT="$DEB_DIR/${PKG_NAME}_${APP_VERSION}_${ARCH_DEB}"
APP_INSTALL_DIR="$DEB_ROOT/opt/tindahan-mo"

# ── Clean and scaffold package tree ──────────────────────────────────────────
rm -rf "$DEB_ROOT"
mkdir -p \
    "$DEB_ROOT/DEBIAN" \
    "$APP_INSTALL_DIR" \
    "$DEB_ROOT/usr/share/applications" \
    "$DEB_ROOT/usr/share/icons/hicolor/16x16/apps" \
    "$DEB_ROOT/usr/share/icons/hicolor/32x32/apps" \
    "$DEB_ROOT/usr/share/icons/hicolor/48x48/apps" \
    "$DEB_ROOT/usr/share/icons/hicolor/64x64/apps" \
    "$DEB_ROOT/usr/share/icons/hicolor/128x128/apps" \
    "$DEB_ROOT/usr/share/icons/hicolor/256x256/apps" \
    "$DEB_ROOT/usr/share/metainfo" \
    "$DEB_ROOT/usr/local/bin"

# ── Copy the PyInstaller bundle into /opt/tindahan-mo ────────────────────────
cp -r "$DIST_FOLDER"/. "$APP_INSTALL_DIR/"
chmod +x "$APP_INSTALL_DIR/tindahan"

# ── /usr/local/bin wrapper so users can type `tindahan` anywhere ─────────────
cat > "$DEB_ROOT/usr/local/bin/tindahan" << 'WEOF'
#!/bin/bash
export QTWEBENGINE_DISABLE_SANDBOX=1
export PYWEBVIEW_GUI=qt
export QT_API=pyside6
if [ -n "${WAYLAND_DISPLAY:-}" ]; then
    export QT_QPA_PLATFORM=wayland
elif [ -n "${DISPLAY:-}" ]; then
    export QT_QPA_PLATFORM=xcb
fi
exec /opt/tindahan-mo/tindahan "$@"
WEOF
chmod 0755 "$DEB_ROOT/usr/local/bin/tindahan"

# ── Desktop entry ─────────────────────────────────────────────────────────────
cat > "$DEB_ROOT/usr/share/applications/tindahan-mo.desktop" << 'DEOF'
[Desktop Entry]
Type=Application
Name=Tindahan Mo
Comment=Sari-Sari Store Management System
Exec=/usr/local/bin/tindahan
Icon=tindahan-mo
Categories=Office;Finance;
Keywords=store;inventory;sales;pos;sari-sari;
StartupNotify=true
DEOF

# ── Icons at all XDG sizes ────────────────────────────────────────────────────
for SIZE in 16 32 48 64 128 256; do
    python3 "$SCRIPT_DIR/make_icon.py" \
        "$DEB_ROOT/usr/share/icons/hicolor/${SIZE}x${SIZE}/apps/tindahan-mo.png" \
        "$SIZE"
done
echo "    Icons embedded ✅"

# ── AppStream metadata ────────────────────────────────────────────────────────
cp "$SCRIPT_DIR/com.tindahanmo.app.appdata.xml" \
   "$DEB_ROOT/usr/share/metainfo/tindahan-mo.appdata.xml"

# ── postinst — update icon caches after install ───────────────────────────────
cat > "$DEB_ROOT/DEBIAN/postinst" << 'PIEOF'
#!/bin/bash
set -e
if command -v update-icon-caches &>/dev/null; then
    update-icon-caches /usr/share/icons/hicolor || true
fi
if command -v gtk-update-icon-cache &>/dev/null; then
    gtk-update-icon-cache -f -t /usr/share/icons/hicolor || true
fi
if command -v update-desktop-database &>/dev/null; then
    update-desktop-database /usr/share/applications || true
fi
PIEOF
chmod 0755 "$DEB_ROOT/DEBIAN/postinst"

# ── postrm — clean icon cache after removal ───────────────────────────────────
cat > "$DEB_ROOT/DEBIAN/postrm" << 'PREF'
#!/bin/bash
set -e
if command -v update-icon-caches &>/dev/null; then
    update-icon-caches /usr/share/icons/hicolor || true
fi
if command -v gtk-update-icon-cache &>/dev/null; then
    gtk-update-icon-cache -f -t /usr/share/icons/hicolor || true
fi
if command -v update-desktop-database &>/dev/null; then
    update-desktop-database /usr/share/applications || true
fi
PREF
chmod 0755 "$DEB_ROOT/DEBIAN/postrm"

# ── Calculate installed size (in KB) ─────────────────────────────────────────
INSTALLED_SIZE_KB="$(du -sk "$DEB_ROOT" | cut -f1)"

# ── DEBIAN/control ────────────────────────────────────────────────────────────
cat > "$DEB_ROOT/DEBIAN/control" << CEOF
Package: ${PKG_NAME}
Version: ${APP_VERSION}
Section: office
Priority: optional
Architecture: ${ARCH_DEB}
Installed-Size: ${INSTALLED_SIZE_KB}
Depends: libxcb-cursor0, libxcb-icccm4, libxcb-keysyms1, libxcb-randr0, libxcb-render-util0, libxcb-xinerama0, libxcb-xfixes0, libxkbcommon-x11-0, libglib2.0-0, libdbus-1-3, libgl1, libegl1, libfontconfig1, xdg-utils
Maintainer: Tindahan Mo <tindahanmo@localhost>
Homepage: https://github.com/tindahanmo/tindahan
Description: Sari-Sari Store Inventory and Sales Management
 Tindahan Mo is a lightweight desktop POS and inventory system
 designed for Filipino sari-sari store owners. Features include:
  - Visual Point-of-Sale with receipt printing
  - Product inventory with image support and low-stock alerts
  - Cashier account management with role-based access
  - Daily, weekly, and monthly sales reports
  - Dark and light mode interface
  - Optional cloud sync via Supabase
CEOF

# ── Set correct permissions on all files ─────────────────────────────────────
find "$DEB_ROOT" -type f ! -path "*/DEBIAN/*" ! -name "tindahan" \
    -exec chmod 0644 {} \;
find "$DEB_ROOT" -type d ! -path "*/DEBIAN" \
    -exec chmod 0755 {} \;
# Ensure the main binary stays executable
chmod 0755 "$APP_INSTALL_DIR/tindahan"
find "$APP_INSTALL_DIR" -name "*.so*" -exec chmod 0755 {} \;

# ── Build the .deb ────────────────────────────────────────────────────────────
DEB_OUT="$DIST_DIR/${PKG_NAME}_${APP_VERSION}_${ARCH_DEB}.deb"
dpkg-deb --build --root-owner-group "$DEB_ROOT" "$DEB_OUT"

if [ -f "$DEB_OUT" ]; then
    DEB_SIZE="$(du -sh "$DEB_OUT" | cut -f1)"
    echo ""
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║  ✅  .DEB BUILD SUCCESSFUL                               ║"
    echo "  ║                                                          ║"
    printf "  ║  File : dist/%-43s║\n" "${PKG_NAME}_${APP_VERSION}_${ARCH_DEB}.deb"
    printf "  ║  Size : %-48s║\n" "$DEB_SIZE"
    echo "  ║                                                          ║"
    echo "  ║  Install :  sudo dpkg -i dist/${PKG_NAME}_${APP_VERSION}_${ARCH_DEB}.deb  ║"
    echo "  ║  Remove  :  sudo apt remove ${PKG_NAME}               ║"
    echo "  ║                                                          ║"
    echo "  ║  After install, run: tindahan                           ║"
    echo "  ╚══════════════════════════════════════════════════════════╝"
else
    echo "  ⚠️   .deb build failed — dpkg-deb returned an error."
    echo "  Make sure dpkg-deb is installed: sudo apt install dpkg-dev"
fi
