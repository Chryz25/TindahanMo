"""
Tindahan Mo — Hybrid Desktop Launcher (Debian 13 / Linux)
==========================================================
• Qt backend (PySide6 + QtWebEngine)
• Django on a free localhost port
• SyncEngine starts in background after Django is ready
• Print via xdg-open (system browser auto-prints)
"""
import os, sys, threading, time, socket, shutil, tempfile
from pathlib import Path

APP_DATA_DIR = Path.home() / ".local" / "share" / "tindahan"
VERSION      = "2.1.0"   # bump this to force source refresh on update

def _make_loading_html() -> str:
    """Build the startup loading screen, embedding the app icon as a base64 image."""
    import base64

    # Try to load the icon file and encode it as a data URL
    logo_html = "<div class=\"logo\" style=\"font-size:72px\">🏬</div>"  # fallback if icon file missing
    icon_path = _find_icon()
    if icon_path:
        try:
            with open(icon_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode("ascii")
            ext = Path(icon_path).suffix.lower().lstrip(".")
            mime = "image/png" if ext == "png" else f"image/{ext}"
            logo_html = (
                f'<img src="data:{mime};base64,{b64}" '
                f'alt="Tindahan Mo" class="logo-img"/>'
            )
        except Exception as exc:
            print(f"⚠️  Could not embed icon in loading screen: {exc}")

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Tindahan Mo</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
  display:flex;align-items:center;justify-content:center;height:100vh;
  font-family:'Segoe UI',sans-serif;color:#fff;user-select:none}}
.card{{text-align:center;animation:fadeIn .6s ease}}
@keyframes fadeIn{{from{{opacity:0;transform:translateY(20px)}}to{{opacity:1;transform:translateY(0)}}}}
.logo{{font-size:72px;margin-bottom:18px}}
.logo-img{{width:120px;height:120px;object-fit:contain;border-radius:24px;
  margin-bottom:18px;filter:drop-shadow(0 8px 24px rgba(245,197,24,.35));
  animation:pulse 2.4s ease-in-out infinite}}
@keyframes pulse{{0%,100%{{transform:scale(1)}}50%{{transform:scale(1.06)}}}}
h1{{font-size:38px;font-weight:900;color:#f5c518;letter-spacing:1px}}
p{{margin-top:12px;font-size:15px;opacity:.7}}
.dots span{{display:inline-block;width:8px;height:8px;border-radius:50%;
  background:#f5c518;margin:0 3px;animation:bounce 1.2s infinite}}
.dots span:nth-child(2){{animation-delay:.2s}}
.dots span:nth-child(3){{animation-delay:.4s}}
@keyframes bounce{{0%,80%,100%{{transform:translateY(0)}}40%{{transform:translateY(-10px)}}}}
</style></head>
<body><div class="card">
  {logo_html}
  <h1>Tindahan Mo</h1>
  <p>Starting up&nbsp;<span class="dots"><span></span><span></span><span></span></span></p>
</div></body></html>"""


class PrintAPI:
    """JS: pywebview.api.print_receipt(html) → xdg-open temp file → browser prints."""
    def print_receipt(self, html: str) -> dict:
        try:
            fd, tmp = tempfile.mkstemp(suffix=".html", prefix="tindahan_receipt_")
            os.close(fd)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(html)
            import subprocess
            subprocess.Popen(["xdg-open", tmp],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            def _del():
                time.sleep(300)
                try: os.unlink(tmp)
                except: pass
            threading.Thread(target=_del, daemon=True).start()
            return {"ok": True}
        except Exception as exc:
            import traceback; traceback.print_exc()
            return {"ok": False, "err": str(exc)}


def _bundle_dir() -> Path:
    if hasattr(sys, "_MEIPASS"): return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent

def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); return s.getsockname()[1]

def _setup_data_dir() -> bool:
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    bundle = _bundle_dir()
    stamp  = APP_DATA_DIR / ".version"
    if not stamp.exists() or stamp.read_text().strip() != VERSION:
        print(f"🔄  Updating app source to {VERSION}…")
        for pkg in ("store", "tindahan_project", "pysqlcipher3"):
            src, dst = bundle / pkg, APP_DATA_DIR / pkg
            if src.exists():
                if dst.exists(): shutil.rmtree(dst)
                shutil.copytree(src, dst)
        src_mgr = bundle / "manage.py"
        if src_mgr.exists(): shutil.copy2(src_mgr, APP_DATA_DIR / "manage.py")
        stamp.write_text(VERSION)
    is_fresh = not (APP_DATA_DIR / "tindahan_secure.db").exists()
    msrc = bundle / "media"
    if msrc.exists() and not (APP_DATA_DIR / "media").exists():
        shutil.copytree(msrc, APP_DATA_DIR / "media")
    (APP_DATA_DIR / "media" / "products").mkdir(parents=True, exist_ok=True)
    (APP_DATA_DIR / "media" / "avatars").mkdir(parents=True, exist_ok=True)
    # Always copy the app icon into media so it's served at /media/app_icon.png
    icon_src = bundle / "tindahan_icon.png"
    icon_dst = APP_DATA_DIR / "media" / "app_icon.png"
    if icon_src.exists():
        shutil.copy2(icon_src, icon_dst)
        print(f"   App icon → {icon_dst}")
    return is_fresh


_httpd = None

def _run_django(port: int) -> None:
    global _httpd
    os.environ["DJANGO_SETTINGS_MODULE"] = "tindahan_project.settings"
    os.environ["TINDAHAN_BASE_DIR"]       = str(APP_DATA_DIR)
    sys.path.insert(0, str(APP_DATA_DIR))

    import django; django.setup()
    from django.core.management import call_command
    call_command("migrate", "--run-syncdb", verbosity=0)
    from store.db import init_db; init_db()

    # ── Start sync engine after DB is ready ───────────────────────────────────
    try:
        from store.sync import get_engine
        from django.conf import settings as djsettings
        eng = get_engine()
        eng.configure(djsettings.TINDAHAN_DB_PATH, djsettings.TINDAHAN_DB_KEY, str(djsettings.MEDIA_ROOT))
        eng.start()
    except Exception as exc:
        print(f"⚠️   Sync engine failed to start: {exc}")

    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler
    class _Q(WSGIRequestHandler):
        def log_message(self, *_): pass
    _httpd = make_server("127.0.0.1", port, get_wsgi_application(), handler_class=_Q)
    _httpd.serve_forever()

def _wait(port, timeout=30.0):
    d = time.monotonic() + timeout
    while time.monotonic() < d:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5): return True
        except OSError: time.sleep(0.2)
    return False

def _stop_server():
    global _httpd
    try:
        from store.sync import get_engine
        get_engine().stop()
    except Exception: pass
    if _httpd:
        try: _httpd.shutdown()
        except Exception: pass
    time.sleep(0.5)

def _find_icon():
    """
    Locate tindahan_icon.png at runtime.  Search order:
      1. sys._MEIPASS      — PyInstaller bundle root (inside AppImage squashfs)
      2. $APPDIR env var   — AppImage mount point (set by AppRun)
      3. Script directory  — development / direct-run fallback
    """
    candidates = []
    if hasattr(sys, "_MEIPASS"):
        candidates.append(os.path.join(sys._MEIPASS, "tindahan_icon.png"))
    appdir = os.environ.get("APPDIR", "")
    if appdir:
        candidates += [
            os.path.join(appdir, "tindahan.png"),
            os.path.join(appdir, "usr", "share", "icons",
                         "hicolor", "256x256", "apps", "tindahan.png"),
        ]
    candidates.append(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "tindahan_icon.png"))
    for p in candidates:
        if os.path.isfile(p):
            return p
    return None


def _set_icon():
    """Set QApplication + all top-level window icons."""
    path = _find_icon()
    if not path:
        print("⚠️  App icon not found — skipping"); return
    try:
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None: return          # Qt not ready yet; caller retries
        icon = QIcon(path)
        app.setWindowIcon(icon)
        for w in app.topLevelWidgets():
            w.setWindowIcon(icon)
        print(f"🎨  Icon set: {path}")
    except Exception as e:
        print(f"⚠️  Could not set Qt icon: {e}")


def _configure_qt():
    os.environ["PYWEBVIEW_GUI"]               = "qt"
    os.environ["QTWEBENGINE_DISABLE_SANDBOX"] = "1"
    appdir = os.environ.get("APPDIR", "")
    if appdir:
        lib = os.path.join(appdir, "usr", "bin")
        ld  = os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = f"{lib}:{ld}" if ld else lib
    if "QT_QPA_PLATFORM" not in os.environ:
        if os.environ.get("WAYLAND_DISPLAY"):
            os.environ["QT_QPA_PLATFORM"] = "wayland"
        elif os.environ.get("DISPLAY"):
            os.environ["QT_QPA_PLATFORM"] = "xcb"
        else:
            os.environ["QT_QPA_PLATFORM"] = "offscreen"


def main():
    print("🚀  Tindahan Mo (Hybrid) starting…")
    _configure_qt()
    is_fresh = _setup_data_dir()
    print("🌟  Fresh install" if is_fresh else "✅  Data found")

    port = _free_port()
    threading.Thread(target=_run_django, args=(port,),
                     daemon=False, name="tindahan-django").start()

    import webview
    api    = PrintAPI()
    window = webview.create_window(
        title    = "Tindahan Mo",
        html     = _make_loading_html(),
        width    = 1280, height = 820,
        min_size = (900, 600),
        resizable= True,
        js_api   = api,
    )

    def _go():
        _set_icon()          # Qt is now fully initialised — apply window/taskbar icon
        if _wait(port): window.load_url(f"http://127.0.0.1:{port}")
        else: window.load_html(
            "<body style='background:#1a1a2e;color:#f5c518;font-family:sans-serif;"
            "display:flex;align-items:center;justify-content:center;height:100vh'>"
            "<h2>&#10060; Server failed to start. Please relaunch.</h2></body>")

    threading.Thread(target=_go, daemon=True).start()
    webview.start(debug=False)
    print("🛑  Shutting down…")
    _stop_server()
    print("👋  Done.")

if __name__ == "__main__":
    main()
