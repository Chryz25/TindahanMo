# Tindahan Mo — Android App Build Instructions (Windows 10/11)

## What you will get

A single **APK file** you can install on any Android phone (Android 7.0+).  
The app bundles its own Python runtime — no apps need to be installed on the phone.

---

## Step 1 — Install Required Software

Install all three of these on your Windows 10/11 PC:

### A. Android Studio
1. Download from https://developer.android.com/studio
2. Run the installer and click **Next** through all steps
3. On first launch, complete the **Setup Wizard** — it will download the Android SDK automatically

### B. JDK 17
Android Studio may install this automatically. If not:
1. Download from https://adoptium.net/temurin/releases/?version=17
2. Choose: **Windows → x64 → JDK → .msi**
3. Run the installer

### C. Python 3.11
Chaquopy needs Python on your PC to resolve packages at build time.
1. Download from https://www.python.org/downloads/release/python-3119/
2. Choose: **Windows installer (64-bit)**
3. ⚠️ **Check "Add Python to PATH"** during install

---

## Step 2 — Open the Project in Android Studio

1. Unzip `TindahanMo-Android.zip` to a folder (e.g. `C:\Projects\TindahanMo`)
2. Open **Android Studio**
3. Click **Open** → navigate to the unzipped folder → click **OK**
4. Wait for **Gradle Sync** to complete (first time downloads ~1GB, takes 10–20 min)
   - Watch the progress bar at the bottom of Android Studio
   - If asked about "Trust Gradle project" → click **Trust Project**
   - If asked about "Android Gradle Plugin upgrade" → click **Don't remind me**

---

## Step 3 — Build the APK

1. In Android Studio menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for the build (5–15 minutes on first build)
3. When done, a notification appears: **"APK(s) generated successfully"**
4. Click **"locate"** in that notification to open the folder

The APK is at:
```
app\build\outputs\apk\debug\app-debug.apk
```

---

## Step 4 — Install on Android Phone

**Method A: USB cable (recommended)**
1. On your phone: Settings → Developer Options → Enable **USB Debugging**
   - If you don't see Developer Options: Settings → About Phone → tap "Build Number" 7 times
2. Connect phone to PC with USB cable
3. In Android Studio: click the **▶ Run** button (green triangle)
4. Select your phone from the list → click **OK**

**Method B: Share the APK file directly**
1. Copy `app-debug.apk` to your phone (via USB, WhatsApp, Google Drive, etc.)
2. On the phone: tap the APK file
3. If prompted "Install unknown apps" → tap **Settings** → enable it → go back and install
4. Tap **Install**

---

## How the App Works on Android

```
When you open the app:
  1. Python runtime starts (Chaquopy, ~2-3 seconds)
  2. Django server starts on localhost (127.0.0.1:XXXXX)
  3. WebView opens and loads the app

If it's a FRESH INSTALL (or database was deleted):
  → Welcome screen + store setup wizard appears
  → Set your store name and complete setup
  → App is ready to use

All data is stored in the phone's private storage:
  /data/data/com.tindahan.mo/files/
  ├── tindahan_secure.db       ← encrypted business data
  ├── tindahan_secure.db.salt  ← encryption key salt
  ├── django_sessions.db       ← login sessions
  └── media/                   ← product & avatar images
```

---

## Default Login Credentials

| Username | Password  | Role        |
|----------|-----------|-------------|
| owner    | owner123  | Store Owner |
| maria    | maria123  | Cashier     |
| jose     | jose123   | Cashier     |

*(Change these after first login via the app)*

---

## Sharing the APK with Others

After building, you get ONE file:
```
app-debug.apk  (~50-100MB)
```

Share it however you like:
- WhatsApp / Telegram / Messenger (file attachment)
- Google Drive / Dropbox link
- USB cable to another phone
- Email attachment

Recipients just tap the APK to install. No Play Store needed.

---

## Troubleshooting

### "Python not found" error during Gradle sync
Open `app/build.gradle`, find this section:
```gradle
python {
    version "3.11"
    pip { ... }
    // buildPython "..."   ← uncomment this line
}
```
Uncomment the `buildPython` line and set it to your Python path, e.g.:
```gradle
buildPython "C:/Users/YourName/AppData/Local/Programs/Python/Python311/python.exe"
```

### "SDK location not found" error
In Android Studio: File → Project Structure → SDK Location → set your Android SDK path
(Usually `C:\Users\YourName\AppData\Local\Android\Sdk`)

### App crashes on phone / blank white screen
- Wait 5-10 seconds after opening (first launch is slow)
- Force-close and reopen
- Check that your phone runs Android 7.0 or newer

### Gradle sync takes forever
This is normal on first run — it downloads Android SDK, Gradle, and Python packages.
Make sure you have a stable internet connection.

---

## App Size

| Component               | Size     |
|-------------------------|----------|
| Python 3.11 runtime     | ~25 MB   |
| Django + Cryptography   | ~15 MB   |
| App HTML/JS frontend    | ~2 MB    |
| **Total APK**           | **~50 MB** |
