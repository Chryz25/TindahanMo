package com.tindahan.mo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import java.io.IOException;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    // ── Constants ──────────────────────────────────────────────────────────────
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int PERMISSION_REQUEST   = 1002;

    // ── Views ──────────────────────────────────────────────────────────────────
    private WebView  webView;
    private View     splashView;

    // ── State ──────────────────────────────────────────────────────────────────
    private int      serverPort = -1;
    private boolean  serverStarted = false;
    private ValueCallback<Uri[]> fileUploadCallback;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // ── Splash HTML ────────────────────────────────────────────────────────────
    private static final String LOADING_HTML =
        "<!DOCTYPE html><html><head><meta charset='utf-8'>" +
        "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<style>" +
        "*{margin:0;padding:0;box-sizing:border-box}" +
        "body{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);" +
        "display:flex;align-items:center;justify-content:center;" +
        "min-height:100vh;font-family:sans-serif;color:#fff}" +
        ".card{text-align:center;padding:40px 20px}" +
        ".logo{font-size:72px;margin-bottom:20px}" +
        "h1{font-size:32px;font-weight:900;color:#f5c518;letter-spacing:1px}" +
        "p{margin-top:12px;font-size:14px;opacity:.7}" +
        ".dots span{display:inline-block;width:8px;height:8px;border-radius:50%;" +
        "background:#f5c518;margin:0 3px;animation:b 1.2s infinite}" +
        ".dots span:nth-child(2){animation-delay:.2s}" +
        ".dots span:nth-child(3){animation-delay:.4s}" +
        "@keyframes b{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-10px)}}" +
        "</style></head>" +
        "<body><div class='card'>" +
        "<div class='logo'>🏪</div>" +
        "<h1>Tindahan Mo</h1>" +
        "<p>Starting up&nbsp;<span class='dots'><span></span><span></span><span></span></span></p>" +
        "</div></body></html>";

    // ═══════════════════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen immersive experience
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        // ── Layout: WebView fills the screen ───────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        webView = new WebView(this);
        webView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ));
        root.addView(webView);
        setContentView(root);

        // ── WebView settings ───────────────────────────────────────────────────
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        ws.setMediaPlaybackRequiresUserGesture(false);

        // ── WebViewClient: handle navigation + errors ──────────────────────────
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String url = req.getUrl().toString();
                // Keep localhost URLs inside the WebView
                if (url.startsWith("http://127.0.0.1") || url.startsWith("http://localhost")) {
                    return false;
                }
                // Open external URLs in browser
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req,
                                        WebResourceError err) {
                // Only show error for main frame
                if (req.isForMainFrame()) {
                    view.loadData(
                        "<body style='background:#1a1a2e;color:#f5c518;font-family:sans-serif;" +
                        "display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>" +
                        "<div style='text-align:center'><div style='font-size:48px'>⚠️</div>" +
                        "<h2>Could not connect</h2><p style='opacity:.7;margin-top:8px'>Tap back and reopen the app.</p>" +
                        "</div></body>",
                        "text/html", "UTF-8"
                    );
                }
            }
        });

        // ── WebChromeClient: handle file chooser (image uploads) ───────────────
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                fileUploadCallback = callback;
                requestImagePermissionAndPick();
                return true;
            }
        });

        // ── Show splash while Django starts ────────────────────────────────────
        webView.loadData(LOADING_HTML, "text/html", "UTF-8");

        // ── Start Django server in background ──────────────────────────────────
        startDjangoServer();
    }

    // ── Django server lifecycle ────────────────────────────────────────────────

    private void startDjangoServer() {
        String dataDir = getFilesDir().getAbsolutePath();

        new Thread(() -> {
            try {
                Python py = Python.getInstance();
                PyObject serverModule = py.getModule("server");

                // server.start(data_dir) → returns port as int
                serverPort = serverModule.callAttr("start", dataDir).toInt();

                // Wait until the HTTP server is actually accepting connections
                waitForPort(serverPort, 30_000);

                serverStarted = true;

                // Navigate to the app on the main thread
                mainHandler.post(() ->
                    webView.loadUrl("http://127.0.0.1:" + serverPort)
                );

            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> webView.loadData(
                    "<body style='background:#1a1a2e;color:#f00;font-family:sans-serif;" +
                    "padding:40px'><h2>⚠ Server Error</h2><pre style='margin-top:16px;font-size:12px;white-space:pre-wrap'>"
                    + e.toString() + "</pre></body>",
                    "text/html", "UTF-8"
                ));
            }
        }, "django-starter").start();
    }

    private void waitForPort(int port, long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            try {
                new Socket("127.0.0.1", port).close();
                return;     // success — port is open
            } catch (IOException ignored) {
                Thread.sleep(200);
            }
        }
        throw new RuntimeException("Django server did not start within " + timeoutMs + "ms");
    }

    // ── Hardware back button: WebView navigation ───────────────────────────────

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ── File upload (product images / avatars) ─────────────────────────────────

    private void requestImagePermissionAndPick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ uses READ_MEDIA_IMAGES
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_MEDIA_IMAGES}, PERMISSION_REQUEST);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST);
                return;
            }
        }
        launchImagePicker();
    }

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Image"), FILE_CHOOSER_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                           @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                launchImagePicker();
            } else {
                // User denied — cancel the file chooser
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                    fileUploadCallback = null;
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (fileUploadCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            fileUploadCallback.onReceiveValue(results);
            fileUploadCallback = null;
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        // If server already started and WebView is on splash, navigate to app
        if (serverStarted && serverPort > 0) {
            String url = webView.getUrl();
            if (url == null || url.startsWith("about:") || url.startsWith("data:")) {
                webView.loadUrl("http://127.0.0.1:" + serverPort);
            }
        }
    }

    @Override
    protected void onDestroy() {
        webView.destroy();
        super.onDestroy();
    }
}
