package com.tindahan.mo;

import android.app.Application;
import com.chaquo.python.android.AndroidPlatform;
import com.chaquo.python.Python;

/**
 * Custom Application class.
 * Starts the Chaquopy Python runtime as early as possible
 * so it's ready when MainActivity launches.
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
    }
}
