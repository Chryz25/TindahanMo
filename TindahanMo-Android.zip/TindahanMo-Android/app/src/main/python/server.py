"""
server.py — Android Django launcher for Tindahan Mo
=====================================================
Called from MainActivity.java via Chaquopy:
    py.getModule("server").callAttr("start", data_dir)

The Django source packages (store, tindahan_project, pysqlcipher3)
are bundled by Chaquopy and already in sys.path — no manual path
manipulation needed for imports.

User data (databases, uploaded images) lives in:
    /data/data/com.tindahan.mo/files/   ← data_dir passed from Java
"""

import os
import sys
import socket
import threading
from pathlib import Path

# ── Module-level state ────────────────────────────────────────────────────────
_server_port: int | None = None
_ready_event = threading.Event()


def find_free_port() -> int:
    """Find an available TCP port on loopback."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def start(data_dir: str) -> int:
    """
    Called from Java. Starts the Django server in a background daemon thread.
    Returns the port number immediately (server may still be warming up).
    Java polls the port with Socket() until it accepts connections.
    """
    global _server_port
    _server_port = find_free_port()

    t = threading.Thread(
        target=_run_server,
        args=(data_dir, _server_port),
        daemon=True,
        name="tindahan-django",
    )
    t.start()
    return _server_port


def _run_server(data_dir: str, port: int) -> None:
    """Full Django bootstrap and serve_forever — runs in background thread."""
    try:
        _prepare_data_dir(data_dir)
        _start_django(port)
    except Exception as exc:
        import traceback
        print(f"[Tindahan] FATAL: {exc}", flush=True)
        traceback.print_exc()


def _prepare_data_dir(data_dir: str) -> None:
    """
    Create the user-data directory tree and configure Django environment.
    The Django app source (store, tindahan_project, pysqlcipher3) is already
    importable from Chaquopy's extract dir — we only need to set env vars.
    """
    data = Path(data_dir)
    data.mkdir(parents=True, exist_ok=True)

    # Media upload directories
    (data / "media" / "products").mkdir(parents=True, exist_ok=True)
    (data / "media" / "avatars").mkdir(parents=True, exist_ok=True)

    # Point Django settings at the user-data dir
    os.environ["DJANGO_SETTINGS_MODULE"] = "tindahan_project.settings"
    os.environ["TINDAHAN_BASE_DIR"]       = data_dir


def _start_django(port: int) -> None:
    """Configure Django, run migrations, seed DB, then serve."""
    import django
    django.setup()

    # ── Run migrations for the sessions DB ────────────────────────────────────
    from django.core.management import call_command
    call_command("migrate", "--run-syncdb", verbosity=0)

    # ── Initialise / migrate the encrypted business DB ─────────────────────────
    from store.db import init_db
    init_db()

    print(f"[Tindahan] Django ready — listening on 127.0.0.1:{port}", flush=True)

    # ── Start WSGI HTTP server ─────────────────────────────────────────────────
    from django.core.wsgi import get_wsgi_application
    from wsgiref.simple_server import make_server, WSGIRequestHandler

    class _Silent(WSGIRequestHandler):
        def log_message(self, *_):
            pass  # suppress per-request logs on Android

    httpd = make_server("127.0.0.1", port, get_wsgi_application(),
                        handler_class=_Silent)
    httpd.serve_forever()
